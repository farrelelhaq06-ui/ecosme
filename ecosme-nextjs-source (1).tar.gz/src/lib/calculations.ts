import {
  AlertThresholdConfig,
  EmissionFactor,
  GreenScore,
  GreenScoreDimension,
  GreenScoreMethodology,
  GreenScoreRating,
} from "./types";

export interface ActivePowerInput {
  phaseType: "SINGLE_PHASE" | "THREE_PHASE";
  currentA: number;
  voltageV?: number | null;
  powerFactor?: number | null;
  nominalVoltageV?: number;
  assumedPowerFactor?: number;
}

export interface ActivePowerResult {
  powerWatts: number;
  powerKw: number;
  isTrueActivePower: boolean;
  calculationMethod: "TRUE_SINGLE_PHASE" | "TRUE_THREE_PHASE" | "ESTIMATED_CURRENT_ONLY";
  engineeringNote: string;
}

/**
 * Calculates electrical active power (W and kW).
 * Enforces electrical engineering rules:
 * - Current sensors alone do not provide accurate active-power measurements.
 * - Single-phase active power requires P = V * I * PF.
 * - Balanced three-phase line-to-line active power requires P = sqrt(3) * V_LL * I_L * PF.
 */
export function calculateActivePower(input: ActivePowerInput): ActivePowerResult {
  const current = Math.max(0, Number.isFinite(input.currentA) ? input.currentA : 0);
  const hasMeasuredVoltage =
    typeof input.voltageV === "number" && Number.isFinite(input.voltageV) && input.voltageV > 0;
  const hasMeasuredPf =
    typeof input.powerFactor === "number" &&
    Number.isFinite(input.powerFactor) &&
    input.powerFactor > 0 &&
    input.powerFactor <= 1;

  const phaseMultiplier = input.phaseType === "THREE_PHASE" ? Math.sqrt(3) : 1;

  if (hasMeasuredVoltage && hasMeasuredPf) {
    const v = input.voltageV as number;
    const pf = input.powerFactor as number;
    const watts = phaseMultiplier * v * current * pf;
    return {
      powerWatts: Math.round(watts * 100) / 100,
      powerKw: Math.round((watts / 1000) * 1000) / 1000,
      isTrueActivePower: true,
      calculationMethod:
        input.phaseType === "THREE_PHASE" ? "TRUE_THREE_PHASE" : "TRUE_SINGLE_PHASE",
      engineeringNote:
        input.phaseType === "THREE_PHASE"
          ? "Calculated from 3-phase line voltage, current, and measured power factor (√3 × V × I × PF)."
          : "Calculated from single-phase voltage, current, and measured power factor (V × I × PF).",
    };
  }

  const fallbackV =
    hasMeasuredVoltage
      ? (input.voltageV as number)
      : input.nominalVoltageV && input.nominalVoltageV > 0
      ? input.nominalVoltageV
      : input.phaseType === "THREE_PHASE"
      ? 380
      : 220;
  const fallbackPf =
    hasMeasuredPf
      ? (input.powerFactor as number)
      : input.assumedPowerFactor && input.assumedPowerFactor > 0 && input.assumedPowerFactor <= 1
      ? input.assumedPowerFactor
      : 0.85;

  const approxWatts = phaseMultiplier * fallbackV * current * fallbackPf;
  return {
    powerWatts: Math.round(approxWatts * 100) / 100,
    powerKw: Math.round((approxWatts / 1000) * 1000) / 1000,
    isTrueActivePower: false,
    calculationMethod: "ESTIMATED_CURRENT_ONLY",
    engineeringNote:
      "Estimated active power: current-only sensor lacks live voltage and/or power factor measurement. Assumed nominal V=" +
      fallbackV +
      "V and PF=" +
      fallbackPf +
      ". Not suitable for billing-grade savings verification.",
  };
}

/**
 * Electricity Cost = Energy Consumption (kWh) × Applicable Electricity Tariff (IDR/kWh)
 */
export function calculateElectricityCost(energyKwh: number, tariffIdrPerKwh: number): number {
  if (!Number.isFinite(energyKwh) || !Number.isFinite(tariffIdrPerKwh)) {
    return 0;
  }
  if (energyKwh <= 0 || tariffIdrPerKwh <= 0) {
    return 0;
  }
  return Math.round(energyKwh * tariffIdrPerKwh);
}

export interface EnergySavingsInput {
  rawBaselineKwh: number;
  currentConsumptionKwh: number;
  tariffIdrPerKwh: number;
  baselineOperatingHours?: number;
  actualOperatingHours?: number;
  baselineProductionUnits?: number;
  actualProductionUnits?: number;
  normalizeByOperatingConditions?: boolean;
  hasMeterVerification?: boolean;
}

export interface EnergySavingsResult {
  rawBaselineKwh: number;
  adjustedBaselineKwh: number;
  currentConsumptionKwh: number;
  energySavingsKwh: number;
  savingsPercentage: number;
  baselineCostIdr: number;
  currentCostIdr: number;
  monetarySavingsIdr: number;
  normalizationFactor: number;
  verificationStatus: "ESTIMATED" | "VERIFIED";
  assumptionsNote: string;
}

/**
 * Energy Savings (kWh) = Adjusted Baseline Consumption − Current Consumption
 * Savings (%) = (Energy Savings / Adjusted Baseline Consumption) × 100
 * Monetary Savings = Energy Savings × Applicable Electricity Tariff
 */
export function calculateEnergySavings(input: EnergySavingsInput): EnergySavingsResult {
  const rawBaseline = Math.max(0, Number.isFinite(input.rawBaselineKwh) ? input.rawBaselineKwh : 0);
  const current = Math.max(
    0,
    Number.isFinite(input.currentConsumptionKwh) ? input.currentConsumptionKwh : 0
  );
  const tariff = Math.max(0, Number.isFinite(input.tariffIdrPerKwh) ? input.tariffIdrPerKwh : 0);

  let normalizationFactor = 1;
  const notes: string[] = [];

  if (input.normalizeByOperatingConditions) {
    const baseHours = input.baselineOperatingHours ?? 0;
    const actHours = input.actualOperatingHours ?? 0;
    const baseProd = input.baselineProductionUnits ?? 0;
    const actProd = input.actualProductionUnits ?? 0;

    if (baseHours > 0 && actHours > 0 && baseProd > 0 && actProd > 0) {
      // Weight 50% operating hours, 50% production throughput for industrial normalization
      const hoursRatio = actHours / baseHours;
      const prodRatio = actProd / baseProd;
      normalizationFactor = 0.5 * hoursRatio + 0.5 * prodRatio;
      notes.push(
        `Normalized for operating hours (${actHours}h vs ${baseHours}h baseline) and production volume (${actProd.toLocaleString()} vs ${baseProd.toLocaleString()} units).`
      );
    } else if (baseHours > 0 && actHours > 0) {
      normalizationFactor = actHours / baseHours;
      notes.push(`Normalized for operating hours (${actHours}h vs ${baseHours}h baseline).`);
    } else if (baseProd > 0 && actProd > 0) {
      normalizationFactor = actProd / baseProd;
      notes.push(
        `Normalized for production output (${actProd.toLocaleString()} vs ${baseProd.toLocaleString()} units).`
      );
    }
  } else {
    notes.push("Direct baseline comparison without production-volume adjustment.");
  }

  const adjustedBaselineKwh = Math.round(rawBaseline * normalizationFactor * 100) / 100;

  if (adjustedBaselineKwh <= 0) {
    return {
      rawBaselineKwh: rawBaseline,
      adjustedBaselineKwh: 0,
      currentConsumptionKwh: current,
      energySavingsKwh: 0,
      savingsPercentage: 0,
      baselineCostIdr: 0,
      currentCostIdr: calculateElectricityCost(current, tariff),
      monetarySavingsIdr: 0,
      normalizationFactor: 1,
      verificationStatus: "ESTIMATED",
      assumptionsNote: "Adjusted baseline is zero; savings cannot be computed (division-by-zero prevented).",
    };
  }

  const energySavingsKwh = Math.round((adjustedBaselineKwh - current) * 100) / 100;
  const savingsPercentage =
    Math.round(((energySavingsKwh / adjustedBaselineKwh) * 100) * 100) / 100;

  const baselineCostIdr = calculateElectricityCost(adjustedBaselineKwh, tariff);
  const currentCostIdr = calculateElectricityCost(current, tariff);
  const monetarySavingsIdr = Math.round(energySavingsKwh * tariff);

  const verificationStatus: "ESTIMATED" | "VERIFIED" =
    input.hasMeterVerification === true ? "VERIFIED" : "ESTIMATED";

  notes.push(
    verificationStatus === "VERIFIED"
      ? "Verified via true active-power metering (V, I, PF) and normalized baseline audit."
      : "Estimated figure based on operational baseline model; not yet audited as verified savings."
  );

  return {
    rawBaselineKwh: rawBaseline,
    adjustedBaselineKwh,
    currentConsumptionKwh: current,
    energySavingsKwh,
    savingsPercentage,
    baselineCostIdr,
    currentCostIdr,
    monetarySavingsIdr,
    normalizationFactor: Math.round(normalizationFactor * 1000) / 1000,
    verificationStatus,
    assumptionsNote: notes.join(" "),
  };
}

export interface ESaaSShareResult {
  eligibleForFee: boolean;
  verifiedMonetarySavingsIdr: number;
  ecosmeSharePercentage: number;
  ecosmeFeeIdr: number;
  ikmRetainedSavingsIdr: number;
  policyNote: string;
}

/**
 * Energy Savings-as-a-Service (ESaaS) fee split calculation.
 * Critical Rule: Never charge based on unverified savings.
 */
export function calculateESaaSShare(
  monetarySavingsIdr: number,
  verificationStatus: "ESTIMATED" | "VERIFIED",
  ecosmeSharePct: number = 30
): ESaaSShareResult {
  const clampedShare = Math.min(100, Math.max(0, Number.isFinite(ecosmeSharePct) ? ecosmeSharePct : 30));
  const safeSavings = Number.isFinite(monetarySavingsIdr) ? Math.max(0, monetarySavingsIdr) : 0;

  if (verificationStatus !== "VERIFIED") {
    return {
      eligibleForFee: false,
      verifiedMonetarySavingsIdr: 0,
      ecosmeSharePercentage: clampedShare,
      ecosmeFeeIdr: 0,
      ikmRetainedSavingsIdr: safeSavings,
      policyNote:
        "No ESaaS fee applied: EcoSME policy strictly prohibits charging performance fees on unverified or estimated savings.",
    };
  }

  if (safeSavings <= 0) {
    return {
      eligibleForFee: false,
      verifiedMonetarySavingsIdr: 0,
      ecosmeSharePercentage: clampedShare,
      ecosmeFeeIdr: 0,
      ikmRetainedSavingsIdr: 0,
      policyNote: "No ESaaS fee applied: Net verified savings for this period did not exceed baseline.",
    };
  }

  const ecosmeFeeIdr = Math.round(safeSavings * (clampedShare / 100));
  const ikmRetainedSavingsIdr = safeSavings - ecosmeFeeIdr;

  return {
    eligibleForFee: true,
    verifiedMonetarySavingsIdr: safeSavings,
    ecosmeSharePercentage: clampedShare,
    ecosmeFeeIdr,
    ikmRetainedSavingsIdr,
    policyNote: `Calculated on verified savings of Rp${safeSavings.toLocaleString("id-ID")} at ${clampedShare}% agreed service share.`,
  };
}

export interface CarbonFootprintResult {
  energyConsumedKwh: number;
  electricitySavingsKwh: number;
  grossEmissionsKgCo2e: number;
  grossEmissionsTonnesCo2e: number;
  estimatedReductionKgCo2e: number;
  estimatedReductionTonnesCo2e: number;
  emissionFactor: EmissionFactor;
  disclaimer: string;
}

/**
 * Estimated CO2 Reduction = Electricity Savings (kWh) × Applicable Emission Factor
 */
export function calculateCarbonFootprint(
  energyConsumedKwh: number,
  electricitySavingsKwh: number,
  emissionFactor: EmissionFactor
): CarbonFootprintResult {
  const safeConsumed = Math.max(0, Number.isFinite(energyConsumedKwh) ? energyConsumedKwh : 0);
  const safeSavings = Math.max(0, Number.isFinite(electricitySavingsKwh) ? electricitySavingsKwh : 0);
  const factor = Math.max(
    0,
    Number.isFinite(emissionFactor.factor_kgco2_per_kwh)
      ? emissionFactor.factor_kgco2_per_kwh
      : 0
  );

  const grossKg = Math.round(safeConsumed * factor * 100) / 100;
  const reductionKg = Math.round(safeSavings * factor * 100) / 100;

  return {
    energyConsumedKwh: safeConsumed,
    electricitySavingsKwh: safeSavings,
    grossEmissionsKgCo2e: grossKg,
    grossEmissionsTonnesCo2e: Math.round((grossKg / 1000) * 1000) / 1000,
    estimatedReductionKgCo2e: reductionKg,
    estimatedReductionTonnesCo2e: Math.round((reductionKg / 1000) * 1000) / 1000,
    emissionFactor,
    disclaimer:
      "Operational Scope 2 location-based estimate using published grid emission factor. These figures are indicative environmental performance metrics and do not constitute certified carbon credits or tradeable offsets.",
  };
}

export interface GreenScoreEvaluationInput {
  organizationId: string;
  assessmentPeriod: string;
  savingsPercentage: number; // e.g., 14.2%
  loadVarianceCoefficientPct: number; // lower variance = higher stability, e.g., 8.5%
  dataCompletenessPct: number; // e.g., 96.4%
  truePowerMeterRatioPct: number; // % of devices measuring true V*I*PF
  co2ReductionRatioPct: number; // % reduction vs baseline emissions
  activeMonitoringDaysRatioPct: number; // % of days in period with continuous telemetry
  methodology: GreenScoreMethodology;
}

/**
 * Computes the transparent EcoSME Green Score (0-100) and Rating (A/B/C/D).
 * Evaluates energy and environmental performance only, not financial creditworthiness.
 */
export function calculateGreenScore(input: GreenScoreEvaluationInput): GreenScore {
  const { methodology } = input;
  const w = methodology.weights;

  // 1. Energy Efficiency Improvement (target: 18%+ savings yields 100)
  const rawEfficiency = Math.min(
    100,
    Math.max(0, Math.round((Math.max(0, input.savingsPercentage) / 18) * 100))
  );

  // 2. Energy Consumption Stability (lower load variance coefficient yields higher score)
  const rawStability = Math.min(
    100,
    Math.max(0, Math.round(100 - Math.max(0, input.loadVarianceCoefficientPct - 5) * 2.5))
  );

  // 3. Data Completeness & Reliability (combines transmission completeness + true active power metering)
  const rawCompleteness = Math.min(
    100,
    Math.max(
      0,
      Math.round(input.dataCompletenessPct * 0.65 + input.truePowerMeterRatioPct * 0.35)
    )
  );

  // 4. Sustainability Performance (CO2 reduction relative to 18% benchmark)
  const rawSustainability = Math.min(
    100,
    Math.max(0, Math.round((Math.max(0, input.co2ReductionRatioPct) / 18) * 100))
  );

  // 5. Consistency of Monitoring
  const rawConsistency = Math.min(
    100,
    Math.max(0, Math.round(input.activeMonitoringDaysRatioPct))
  );

  const dimensions: GreenScoreDimension[] = [
    {
      key: "efficiency_improvement",
      label: "Energy Efficiency Improvement",
      weight_pct: w.efficiency_improvement,
      raw_score: rawEfficiency,
      weighted_score: Math.round((rawEfficiency * w.efficiency_improvement) / 100 * 10) / 10,
      explanation:
        "Measures normalized electricity consumption reduction against the established baseline period.",
      metric_evidence: `${input.savingsPercentage.toFixed(1)}% energy reduction vs normalized baseline`,
    },
    {
      key: "consumption_stability",
      label: "Energy Consumption Stability",
      weight_pct: w.consumption_stability,
      raw_score: rawStability,
      weighted_score: Math.round((rawStability * w.consumption_stability) / 100 * 10) / 10,
      explanation:
        "Evaluates load stability, peak demand discipline, and absence of unscheduled power spikes.",
      metric_evidence: `${input.loadVarianceCoefficientPct.toFixed(1)}% daily load variance coefficient`,
    },
    {
      key: "data_completeness",
      label: "Data Completeness & Reliability",
      weight_pct: w.data_completeness,
      raw_score: rawCompleteness,
      weighted_score: Math.round((rawCompleteness * w.data_completeness) / 100 * 10) / 10,
      explanation:
        "Assesses sensor transmission continuity and the proportion of true active-power meters (V, I, PF).",
      metric_evidence: `${input.dataCompletenessPct.toFixed(1)}% telemetry completeness; ${input.truePowerMeterRatioPct.toFixed(0)}% true-power meters`,
    },
    {
      key: "sustainability_performance",
      label: "Sustainability Performance",
      weight_pct: w.sustainability_performance,
      raw_score: rawSustainability,
      weighted_score: Math.round((rawSustainability * w.sustainability_performance) / 100 * 10) / 10,
      explanation:
        "Quantifies Scope 2 location-based CO₂e intensity reduction per unit of industrial output.",
      metric_evidence: `${input.co2ReductionRatioPct.toFixed(1)}% estimated Scope 2 CO₂e intensity reduction`,
    },
    {
      key: "monitoring_consistency",
      label: "Consistency of Monitoring",
      weight_pct: w.monitoring_consistency,
      raw_score: rawConsistency,
      weighted_score: Math.round((rawConsistency * w.monitoring_consistency) / 100 * 10) / 10,
      explanation:
        "Tracks uninterrupted daily device heartbeats and multi-machine coverage across the assessment window.",
      metric_evidence: `${input.activeMonitoringDaysRatioPct.toFixed(1)}% active daily monitoring coverage`,
    },
  ];

  const totalWeight =
    w.efficiency_improvement +
    w.consumption_stability +
    w.data_completeness +
    w.sustainability_performance +
    w.monitoring_consistency;

  const rawWeightedSum = dimensions.reduce((sum, d) => sum + d.weighted_score, 0);
  const overallScore =
    totalWeight > 0 ? Math.round((rawWeightedSum / totalWeight) * 100) : 0;

  let rating: GreenScoreRating = "D";
  if (overallScore >= methodology.thresholds.rating_a_min) {
    rating = "A";
  } else if (overallScore >= methodology.thresholds.rating_b_min) {
    rating = "B";
  } else if (overallScore >= methodology.thresholds.rating_c_min) {
    rating = "C";
  }

  const recommendations: string[] = [];
  if (input.truePowerMeterRatioPct < 100) {
    recommendations.push(
      "Upgrade remaining current-only (CT) sensors to full voltage + power factor meters (e.g., PZEM-004T / Modbus 3-Phase) to qualify all machine lines for verified savings."
    );
  }
  if (rawEfficiency < 85) {
    recommendations.push(
      "Install Variable Frequency Drives (VFDs) on high-load compressor and dyeing pump motors to improve baseline energy savings from current levels toward the 15%+ Grade-A benchmark."
    );
  }
  if (rawStability < 85) {
    recommendations.push(
      "Stagger startup schedules for heavy inductive machinery during the 08:00–09:00 shift transition to reduce peak demand spikes and improve load stability."
    );
  }
  if (recommendations.length === 0) {
    recommendations.push(
      "Maintain current preventive maintenance schedule and continuous telemetry coverage to preserve Grade-A green financing readiness."
    );
  }

  const dataQualityStatus =
    input.dataCompletenessPct >= 90 && input.truePowerMeterRatioPct >= 75
      ? "HIGH_QUALITY"
      : input.dataCompletenessPct >= 75
      ? "MODERATE_QUALITY"
      : "INSUFFICIENT_DATA";

  return {
    id: `gs-${input.organizationId}-${input.assessmentPeriod}`,
    organization_id: input.organizationId,
    assessment_period: input.assessmentPeriod,
    overall_score: overallScore,
    rating,
    is_provisional: !methodology.is_externally_validated,
    status_label: methodology.is_externally_validated
      ? "Validated Green Score"
      : "Provisional Green Score",
    methodology_version: methodology.version,
    data_quality_status: dataQualityStatus,
    data_completeness_pct: input.dataCompletenessPct,
    dimensions,
    recommendations,
    calculated_at: "2026-11-09T06:00:00Z",
  };
}

export interface TelemetryAnomalyCheckInput {
  ratedPowerKw: number;
  rollingAverageKw: number;
  nominalVoltageV: number;
  measuredPowerKw: number;
  measuredVoltageV: number | null;
  measuredPowerFactor: number | null;
  minutesSinceLastHeartbeat: number;
  thresholds: AlertThresholdConfig;
}

export interface DetectedAnomaly {
  severity: "CRITICAL" | "WARNING" | "INFORMATIONAL";
  category:
    | "ABNORMAL_POWER"
    | "ENERGY_SPIKE"
    | "DEVICE_DISCONNECTION"
    | "MISSING_SENSOR_DATA"
    | "UNUSUAL_PATTERN";
  title: string;
  description: string;
  rule_triggered: string;
  threshold_value: string;
  observed_value: string;
}

/**
 * Deterministic, rule-based anomaly evaluation for industrial energy telemetry.
 */
export function evaluateTelemetryAnomalies(
  input: TelemetryAnomalyCheckInput
): DetectedAnomaly[] {
  const anomalies: DetectedAnomaly[] = [];
  const { thresholds } = input;

  if (input.minutesSinceLastHeartbeat > thresholds.heartbeat_timeout_minutes) {
    anomalies.push({
      severity: "CRITICAL",
      category: "DEVICE_DISCONNECTION",
      title: "IoT Device Heartbeat Timeout",
      description: `No telemetry heartbeat received for ${input.minutesSinceLastHeartbeat} minutes.`,
      rule_triggered: `minutes_since_heartbeat > ${thresholds.heartbeat_timeout_minutes}m`,
      threshold_value: `${thresholds.heartbeat_timeout_minutes} min`,
      observed_value: `${input.minutesSinceLastHeartbeat} min`,
    });
  }

  const maxAllowedKw =
    input.ratedPowerKw * (thresholds.over_power_threshold_pct / 100);
  if (input.ratedPowerKw > 0 && input.measuredPowerKw > maxAllowedKw) {
    anomalies.push({
      severity: "CRITICAL",
      category: "ABNORMAL_POWER",
      title: "Over-Rated Power Draw Detected",
      description: `Active power (${input.measuredPowerKw.toFixed(2)} kW) exceeded ${thresholds.over_power_threshold_pct}% of machine rated capacity (${input.ratedPowerKw} kW).`,
      rule_triggered: `power_kw > rated_power_kw * ${thresholds.over_power_threshold_pct}%`,
      threshold_value: `${maxAllowedKw.toFixed(2)} kW`,
      observed_value: `${input.measuredPowerKw.toFixed(2)} kW`,
    });
  } else if (
    input.rollingAverageKw > 0 &&
    input.measuredPowerKw >
      input.rollingAverageKw * (1 + thresholds.spike_deviation_pct / 100)
  ) {
    const spikeLimit =
      input.rollingAverageKw * (1 + thresholds.spike_deviation_pct / 100);
    anomalies.push({
      severity: "WARNING",
      category: "ENERGY_SPIKE",
      title: "Unexpected Energy Consumption Spike",
      description: `Active power exceeded rolling baseline (${input.rollingAverageKw.toFixed(2)} kW) by more than ${thresholds.spike_deviation_pct}%.`,
      rule_triggered: `power_kw > rolling_avg_kw * (1 + ${thresholds.spike_deviation_pct}%)`,
      threshold_value: `${spikeLimit.toFixed(2)} kW`,
      observed_value: `${input.measuredPowerKw.toFixed(2)} kW`,
    });
  }

  if (input.measuredVoltageV === null || input.measuredPowerFactor === null) {
    anomalies.push({
      severity: "INFORMATIONAL",
      category: "MISSING_SENSOR_DATA",
      title: "Partial Telemetry (Voltage / Power Factor Missing)",
      description:
        "Sensor payload lacks voltage or power factor readings; active power is estimated rather than billing-grade.",
      rule_triggered: "voltage_v == null OR power_factor == null",
      threshold_value: "Full V, I, PF telemetry",
      observed_value: `V=${input.measuredVoltageV ?? "null"}, PF=${input.measuredPowerFactor ?? "null"}`,
    });
  } else if (input.measuredPowerFactor < thresholds.min_power_factor) {
    anomalies.push({
      severity: "WARNING",
      category: "UNUSUAL_PATTERN",
      title: "Low Power Factor (Reactive Power Penalty Risk)",
      description: `Measured power factor (${input.measuredPowerFactor.toFixed(2)}) is below the ${thresholds.min_power_factor} threshold (PLN kVArh penalty risk).`,
      rule_triggered: `power_factor < ${thresholds.min_power_factor}`,
      threshold_value: `${thresholds.min_power_factor}`,
      observed_value: `${input.measuredPowerFactor.toFixed(2)}`,
    });
  }

  return anomalies;
}
