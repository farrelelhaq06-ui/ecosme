import fs from "fs";
import path from "path";
import crypto from "crypto";
import {
  Alert,
  AlertThresholdConfig,
  AuditLog,
  DataSharingConsent,
  Device,
  DeviceCredential,
  ElectricityTariff,
  EmissionFactor,
  EnergyBaseline,
  EnergyReading,
  FinancingApplication,
  GreenScore,
  GreenScoreMethodology,
  Machine,
  Organization,
  OrganizationMember,
  PlatformConfiguration,
  Report,
  SavingsRecord,
  Subscription,
  User,
} from "./types";
import { calculateGreenScore } from "./calculations";

export interface EcoSMEDatabaseState {
  users: User[];
  organizations: Organization[];
  organization_members: OrganizationMember[];
  machines: Machine[];
  devices: Device[];
  device_credentials: DeviceCredential[];
  energy_readings: EnergyReading[];
  energy_baselines: EnergyBaseline[];
  savings_records: SavingsRecord[];
  electricity_tariffs: ElectricityTariff[];
  emission_factors: EmissionFactor[];
  green_scores: GreenScore[];
  green_score_methodologies: GreenScoreMethodology[];
  financing_applications: FinancingApplication[];
  data_sharing_consents: DataSharingConsent[];
  reports: Report[];
  alerts: Alert[];
  alert_thresholds: AlertThresholdConfig[];
  audit_logs: AuditLog[];
  subscriptions: Subscription[];
  platform_config: PlatformConfiguration;
}

const DATA_DIR = path.join(process.cwd(), ".data");
const DB_FILE_PATH = path.join(DATA_DIR, "ecosme-db.json");

export function hashDeviceSecret(secret: string): string {
  return crypto.createHash("sha256").update(secret).digest("hex");
}

function buildDeterministicReadings(): EnergyReading[] {
  const readings: EnergyReading[] = [];
  // Generate 30 deterministic daily aggregate readings for PT Sinar Tekstil Mandiri (org-ikm-sinar)
  // From Oct 11, 2026 to Nov 09, 2026
  // Total 30-day consumption across 5 machines = 41,820 kWh (avg 1,394 kWh/day)
  // Daily profile shows realistic industrial weekday vs Sunday variation, completely deterministic
  const dailyPatterns = [
    1420, 1450, 1410, 1390, 1435, 1380, 980, // Week 1
    1440, 1465, 1415, 1395, 1425, 1375, 995, // Week 2
    1430, 1490, 1405, 1385, 1415, 1365, 975, // Week 3
    1410, 1435, 1395, 1380, 1410, 1360, 990, // Week 4
    1405, 1395, // Days 29, 30 -> Sum = 41,820 kWh!
  ];

  const machinesMeta = [
    {
      id: "mch-dye-01",
      device_id: "dev-esp32-3p-01",
      share: 0.31,
      voltage_v: 381.2,
      pf: 0.91,
      classification: "SIMULATED_DEMO" as const,
    },
    {
      id: "mch-cmp-02",
      device_id: "dev-esp32-3p-02",
      share: 0.34,
      voltage_v: 379.5,
      pf: 0.94,
      classification: "SIMULATED_DEMO" as const,
    },
    {
      id: "mch-wvg-03",
      device_id: "dev-esp32-3p-03",
      share: 0.20,
      voltage_v: 380.4,
      pf: 0.89,
      classification: "SIMULATED_DEMO" as const,
    },
    {
      id: "mch-stn-04",
      device_id: "dev-esp32-1p-04",
      share: 0.10,
      voltage_v: 221.0,
      pf: 0.92,
      classification: "SIMULATED_DEMO" as const,
    },
    {
      id: "mch-pmp-05",
      device_id: "dev-nodemcu-ct-05",
      share: 0.05,
      voltage_v: null,
      pf: null,
      classification: "ESTIMATED" as const,
    },
  ];

  const startDate = new Date("2026-10-11T08:00:00Z");

  for (let dayIdx = 0; dayIdx < 30; dayIdx++) {
    const dt = new Date(startDate.getTime() + dayIdx * 86400 * 1000);
    const isoDate = dt.toISOString().slice(0, 10);
    const label = dt.toLocaleDateString("en-US", { month: "short", day: "2-digit" });
    const totalDayKwh = dailyPatterns[dayIdx];
    const isSunday = (dayIdx + 1) % 7 === 0;
    const opHours = isSunday ? 10 : 16;
    const prodUnits = isSunday ? 780 : 1220;

    machinesMeta.forEach((m, mIdx) => {
      const kwh = Math.round(totalDayKwh * m.share * 100) / 100;
      const avgPowerKw = Math.round((kwh / opHours) * 100) / 100;
      const v = m.voltage_v !== null ? m.voltage_v + ((dayIdx % 3) - 1) * 0.6 : null;
      const pf = m.pf;
      const currentA =
        v && pf
          ? Math.round(((avgPowerKw * 1000) / (v > 300 ? Math.sqrt(3) * v * pf : v * pf)) * 10) /
            10
          : Math.round(((avgPowerKw * 1000) / (220 * 0.85)) * 10) / 10;

      readings.push({
        id: `rd-sinar-${dayIdx + 1}-${mIdx + 1}`,
        organization_id: "org-ikm-sinar",
        machine_id: m.id,
        device_id: m.device_id,
        timestamp: `${isoDate}T16:00:00Z`,
        date_label: label,
        voltage_v: v,
        current_a: currentA,
        power_kw: avgPowerKw,
        power_factor: pf,
        energy_kwh: kwh,
        production_units: Math.round(prodUnits * m.share),
        operating_hours: opHours,
        classification: m.classification,
      });
    });
  }

  return readings;
}

export function createInitialSeedState(): EcoSMEDatabaseState {
  const defaultMethodology: GreenScoreMethodology = {
    id: "gsm-v1.2",
    version: "v1.2-2026",
    name: "EcoSME Industrial Energy & Sustainability Readiness Methodology",
    is_active: true,
    is_externally_validated: false,
    weights: {
      efficiency_improvement: 25,
      consumption_stability: 20,
      data_completeness: 20,
      sustainability_performance: 20,
      monitoring_consistency: 15,
    },
    thresholds: {
      rating_a_min: 80,
      rating_b_min: 65,
      rating_c_min: 50,
    },
    updated_by: "Dr. Hendra Wijaya (EcoSME Chief Sustainability Architect)",
    updated_at: "2026-10-15T09:00:00Z",
  };

  const sinarGreenScore = calculateGreenScore({
    organizationId: "org-ikm-sinar",
    assessmentPeriod: "Oct 11, 2026 – Nov 09, 2026",
    savingsPercentage: 14.48,
    loadVarianceCoefficientPct: 7.8,
    dataCompletenessPct: 98.2,
    truePowerMeterRatioPct: 80, // 4 of 5 devices measure true V, I, PF
    co2ReductionRatioPct: 14.48,
    activeMonitoringDaysRatioPct: 100,
    methodology: defaultMethodology,
  });

  const karyaGreenScore = calculateGreenScore({
    organizationId: "org-ikm-karya",
    assessmentPeriod: "Oct 11, 2026 – Nov 09, 2026",
    savingsPercentage: 11.2,
    loadVarianceCoefficientPct: 11.4,
    dataCompletenessPct: 94.0,
    truePowerMeterRatioPct: 75,
    co2ReductionRatioPct: 11.2,
    activeMonitoringDaysRatioPct: 93.3,
    methodology: defaultMethodology,
  });

  const panganGreenScore = calculateGreenScore({
    organizationId: "org-ikm-pangan",
    assessmentPeriod: "Oct 11, 2026 – Nov 09, 2026",
    savingsPercentage: 6.4,
    loadVarianceCoefficientPct: 16.5,
    dataCompletenessPct: 84.0,
    truePowerMeterRatioPct: 50,
    co2ReductionRatioPct: 6.4,
    activeMonitoringDaysRatioPct: 86.7,
    methodology: defaultMethodology,
  });

  return {
    organizations: [
      {
        id: "org-ikm-sinar",
        name: "PT Sinar Tekstil Mandiri (DEMO)",
        type: "IKM",
        industry_category: "Textile Dyeing & Weaving (ISIC 131)",
        location: "Bandung Regency, West Java",
        address: "Kawasan Industri Rancaekek Km 24.5, Kab. Bandung, Jawa Barat 40394",
        tax_id_npwp: "01.842.910.4-429.000 (DEMO)",
        business_license_nib: "9120300481920 (DEMO)",
        contact_email: "budi.santoso@sinartekstil-demo.co.id",
        contact_phone: "+62 22 7794 2100",
        employee_count: 145,
        operating_hours_per_day: 16,
        operating_days_per_month: 26,
        pln_tariff_class: "I-3 / TM (>200 kVA Industrial)",
        installed_capacity_kva: 240,
        subscription_id: "sub-sinar-pro",
        is_demo: true,
        created_at: "2026-04-10T08:00:00Z",
        updated_at: "2026-11-09T06:00:00Z",
      },
      {
        id: "org-ikm-karya",
        name: "CV Karya Logam Presisi (DEMO)",
        type: "IKM",
        industry_category: "Metal Stamping & Automotive Components (ISIC 259)",
        location: "Cikarang, Bekasi, West Java",
        address: "Jl. Jababeka XII Blok W-18, Cikarang Utara, Bekasi, Jawa Barat 17530",
        tax_id_npwp: "02.419.882.1-413.000 (DEMO)",
        business_license_nib: "8120109283711 (DEMO)",
        contact_email: "ratna.dewi@karyalogam-demo.co.id",
        contact_phone: "+62 21 8934 5512",
        employee_count: 88,
        operating_hours_per_day: 14,
        operating_days_per_month: 25,
        pln_tariff_class: "B-3 / I-2 Medium Industrial",
        installed_capacity_kva: 165,
        subscription_id: "sub-karya-growth",
        is_demo: true,
        created_at: "2026-05-18T08:00:00Z",
        updated_at: "2026-11-08T10:00:00Z",
      },
      {
        id: "org-ikm-pangan",
        name: "PT Agro Pangan Lestari (DEMO)",
        type: "IKM",
        industry_category: "Cold Chain & Food Processing (ISIC 107)",
        location: "Rungkut Industrial Estate, Surabaya",
        address: "Jl. Berbek Industri III No. 14, Sidoarjo - Surabaya, Jawa Timur 61256",
        tax_id_npwp: "03.115.609.8-609.000 (DEMO)",
        business_license_nib: "9120408812304 (DEMO)",
        contact_email: "operations@agropangan-demo.co.id",
        contact_phone: "+62 31 8439 1120",
        employee_count: 64,
        operating_hours_per_day: 24,
        operating_days_per_month: 30,
        pln_tariff_class: "I-2 Industrial (14 kVA – 200 kVA)",
        installed_capacity_kva: 135,
        subscription_id: "sub-pangan-basic",
        is_demo: true,
        created_at: "2026-06-22T08:00:00Z",
        updated_at: "2026-11-07T14:00:00Z",
      },
      {
        id: "org-bank-nusantara",
        name: "Bank Nusantara Hijau — Green Lending Desk (DEMO)",
        type: "BANK",
        industry_category: "Commercial Banking & Sustainable Finance",
        location: "Sudirman CBD, Jakarta",
        address: "Menara Nusantara Lt. 22, Jl. Jend. Sudirman Kav. 52-53, Jakarta 12190",
        tax_id_npwp: "01.001.202.3-091.000 (DEMO)",
        business_license_nib: "1000293847561 (DEMO)",
        contact_email: "greendesk@banknusantara-demo.co.id",
        contact_phone: "+62 21 5150 8800",
        employee_count: 1200,
        operating_hours_per_day: 9,
        operating_days_per_month: 22,
        pln_tariff_class: "B-3 Commercial",
        installed_capacity_kva: 500,
        subscription_id: "sub-bank-partner",
        is_demo: true,
        created_at: "2026-03-01T08:00:00Z",
        updated_at: "2026-11-09T06:00:00Z",
      },
      {
        id: "org-ecosme-hq",
        name: "EcoSME Platform Governance",
        type: "PLATFORM",
        industry_category: "Industrial Energy SaaS & Climate Fintech",
        location: "Jakarta & Bandung, Indonesia",
        address: "Green Tech Hub Blok B-4, Jl. Ganesha, Bandung / Jakarta",
        tax_id_npwp: "04.991.221.0-429.000 (DEMO)",
        business_license_nib: "9120998877665 (DEMO)",
        contact_email: "admin@ecosme.id",
        contact_phone: "+62 21 2990 1400",
        employee_count: 32,
        operating_hours_per_day: 24,
        operating_days_per_month: 30,
        pln_tariff_class: "B-2 Commercial",
        installed_capacity_kva: 66,
        subscription_id: "sub-platform-internal",
        is_demo: true,
        created_at: "2026-01-01T00:00:00Z",
        updated_at: "2026-11-09T06:00:00Z",
      },
    ],
    users: [
      {
        id: "usr-ikm-budi",
        email: "budi.santoso@sinartekstil-demo.co.id",
        name: "Ir. Budi Santoso",
        role: "IKM_OWNER",
        organization_id: "org-ikm-sinar",
        title: "Managing Director & Plant Owner",
        active: true,
        created_at: "2026-04-10T08:05:00Z",
        updated_at: "2026-11-09T06:00:00Z",
      },
      {
        id: "usr-ikm-ratna",
        email: "ratna.dewi@karyalogam-demo.co.id",
        name: "Ratna Dewi, S.T.",
        role: "IKM_OWNER",
        organization_id: "org-ikm-karya",
        title: "Operations Director",
        active: true,
        created_at: "2026-05-18T08:15:00Z",
        updated_at: "2026-11-08T10:00:00Z",
      },
      {
        id: "usr-bank-arief",
        email: "arief.rahman@banknusantara-demo.co.id",
        name: "Arief Rahman, CFA",
        role: "BANK_OFFICER",
        organization_id: "org-bank-nusantara",
        title: "VP Green & Sustainable SME Financing",
        active: true,
        created_at: "2026-03-01T09:00:00Z",
        updated_at: "2026-11-09T06:00:00Z",
      },
      {
        id: "usr-admin-nadia",
        email: "nadia.putri@ecosme.id",
        name: "Nadia Putri, M.T.",
        role: "ECOSME_ADMIN",
        organization_id: "org-ecosme-hq",
        title: "Lead IoT & Methodology Administrator",
        active: true,
        created_at: "2026-01-01T09:00:00Z",
        updated_at: "2026-11-09T06:00:00Z",
      },
    ],
    organization_members: [
      {
        id: "om-1",
        organization_id: "org-ikm-sinar",
        user_id: "usr-ikm-budi",
        member_role: "OWNER",
        created_at: "2026-04-10T08:05:00Z",
      },
      {
        id: "om-2",
        organization_id: "org-ikm-karya",
        user_id: "usr-ikm-ratna",
        member_role: "OWNER",
        created_at: "2026-05-18T08:15:00Z",
      },
      {
        id: "om-3",
        organization_id: "org-bank-nusantara",
        user_id: "usr-bank-arief",
        member_role: "FINANCE_OFFICER",
        created_at: "2026-03-01T09:00:00Z",
      },
      {
        id: "om-4",
        organization_id: "org-ecosme-hq",
        user_id: "usr-admin-nadia",
        member_role: "OWNER",
        created_at: "2026-01-01T09:00:00Z",
      },
    ],
    machines: [
      {
        id: "mch-dye-01",
        organization_id: "org-ikm-sinar",
        name: "High-Temp Jet Dyeing Line #1",
        code: "MCH-DYE-01",
        category: "Thermal & Wet Processing",
        location_zone: "Hall A — Wet Finishing Bay",
        rated_power_kw: 32,
        phase_type: "THREE_PHASE",
        nominal_voltage_v: 380,
        status: "ONLINE",
        device_id: "dev-esp32-3p-01",
        monthly_energy_kwh: 12964.2,
        baseline_monthly_kwh: 15159.0,
        last_data_received: "2026-11-09T12:48:00Z",
        efficiency_notes:
          "Equipped with heat-exchanger condensate recovery and circulation pump VFD.",
        created_at: "2026-04-12T10:00:00Z",
        updated_at: "2026-11-09T12:48:00Z",
      },
      {
        id: "mch-cmp-02",
        organization_id: "org-ikm-sinar",
        name: "Rotary Screw Air Compressor 37kW (VFD)",
        code: "MCH-CMP-02",
        category: "Compressed Air Utility",
        location_zone: "Utility Room B",
        rated_power_kw: 37,
        phase_type: "THREE_PHASE",
        nominal_voltage_v: 380,
        status: "ONLINE",
        device_id: "dev-esp32-3p-02",
        monthly_energy_kwh: 14218.8,
        baseline_monthly_kwh: 17115.0,
        last_data_received: "2026-11-09T12:49:00Z",
        efficiency_notes:
          "Retrofitted with permanent-magnet VFD inverter in July 2026; unloaded idling reduced by 68%.",
        created_at: "2026-04-12T10:15:00Z",
        updated_at: "2026-11-09T12:49:00Z",
      },
      {
        id: "mch-wvg-03",
        organization_id: "org-ikm-sinar",
        name: "Air-Jet Weaving Loom Cluster A (12 Looms)",
        code: "MCH-WVG-03",
        category: "Weaving Production",
        location_zone: "Hall B — Weaving Floor",
        rated_power_kw: 24,
        phase_type: "THREE_PHASE",
        nominal_voltage_v: 380,
        status: "ONLINE",
        device_id: "dev-esp32-3p-03",
        monthly_energy_kwh: 8364.0,
        baseline_monthly_kwh: 9291.0,
        last_data_received: "2026-11-09T12:47:30Z",
        efficiency_notes: "Solenoid nozzle pressure optimized from 5.8 bar to 5.1 bar.",
        created_at: "2026-04-12T10:30:00Z",
        updated_at: "2026-11-09T12:47:30Z",
      },
      {
        id: "mch-stn-04",
        organization_id: "org-ikm-sinar",
        name: "Stenter Frame Exhaust & Blower Bank",
        code: "MCH-STN-04",
        category: "Drying & Heat Setting",
        location_zone: "Hall A — Finishing Exit",
        rated_power_kw: 12.5,
        phase_type: "SINGLE_PHASE",
        nominal_voltage_v: 220,
        status: "ONLINE",
        device_id: "dev-esp32-1p-04",
        monthly_energy_kwh: 4182.0,
        baseline_monthly_kwh: 4890.0,
        last_data_received: "2026-11-09T12:48:20Z",
        efficiency_notes: "Automated humidity damper control installed.",
        created_at: "2026-04-12T10:45:00Z",
        updated_at: "2026-11-09T12:48:20Z",
      },
      {
        id: "mch-pmp-05",
        organization_id: "org-ikm-sinar",
        name: "WWTP Effluent Transfer Pump #2",
        code: "MCH-PMP-05",
        category: "Wastewater Treatment",
        location_zone: "Outdoor IPAL Utility",
        rated_power_kw: 6.5,
        phase_type: "SINGLE_PHASE",
        nominal_voltage_v: 220,
        status: "ONLINE",
        device_id: "dev-nodemcu-ct-05",
        monthly_energy_kwh: 2091.0,
        baseline_monthly_kwh: 2445.0,
        last_data_received: "2026-11-09T12:15:00Z",
        efficiency_notes:
          "Monitored via legacy NodeMCU CT-clamp (current-only). Scheduled for PZEM-004T upgrade to enable verified active power metering.",
        created_at: "2026-04-12T11:00:00Z",
        updated_at: "2026-11-09T12:15:00Z",
      },
    ],
    devices: [
      {
        id: "dev-esp32-3p-01",
        organization_id: "org-ikm-sinar",
        machine_id: "mch-dye-01",
        name: "EcoNode-3P #01 (Jet Dyeing)",
        serial_number: "ESME-ESP32-3P-2026-001",
        hardware_type: "ESP32_MODBUS_3P",
        firmware_version: "v2.4.1-tls",
        phase_support: "THREE_PHASE",
        measures_voltage: true,
        measures_power_factor: true,
        connection_protocol: "MQTT_TLS",
        status: "ONLINE",
        last_heartbeat: "2026-11-09T12:49:10Z",
        last_transmission: "2026-11-09T12:48:00Z",
        data_completeness_pct: 99.4,
        is_simulated: true,
        created_at: "2026-04-12T10:00:00Z",
        updated_at: "2026-11-09T12:49:10Z",
      },
      {
        id: "dev-esp32-3p-02",
        organization_id: "org-ikm-sinar",
        machine_id: "mch-cmp-02",
        name: "EcoNode-3P #02 (Screw Compressor)",
        serial_number: "ESME-ESP32-3P-2026-002",
        hardware_type: "ESP32_MODBUS_3P",
        firmware_version: "v2.4.1-tls",
        phase_support: "THREE_PHASE",
        measures_voltage: true,
        measures_power_factor: true,
        connection_protocol: "MQTT_TLS",
        status: "ONLINE",
        last_heartbeat: "2026-11-09T12:49:30Z",
        last_transmission: "2026-11-09T12:49:00Z",
        data_completeness_pct: 99.8,
        is_simulated: true,
        created_at: "2026-04-12T10:15:00Z",
        updated_at: "2026-11-09T12:49:30Z",
      },
      {
        id: "dev-esp32-3p-03",
        organization_id: "org-ikm-sinar",
        machine_id: "mch-wvg-03",
        name: "Schneider PM2230 Gateway #03 (Weaving)",
        serial_number: "ESME-PM2230-2026-003",
        hardware_type: "SCHNEIDER_PM2230",
        firmware_version: "v2.4.1-tls",
        phase_support: "THREE_PHASE",
        measures_voltage: true,
        measures_power_factor: true,
        connection_protocol: "HTTPS_REST",
        status: "ONLINE",
        last_heartbeat: "2026-11-09T12:48:50Z",
        last_transmission: "2026-11-09T12:47:30Z",
        data_completeness_pct: 98.9,
        is_simulated: true,
        created_at: "2026-04-12T10:30:00Z",
        updated_at: "2026-11-09T12:48:50Z",
      },
      {
        id: "dev-esp32-1p-04",
        organization_id: "org-ikm-sinar",
        machine_id: "mch-stn-04",
        name: "EcoNode-1P PZEM #04 (Stenter Exhaust)",
        serial_number: "ESME-PZEM004T-2026-004",
        hardware_type: "ESP32_PZEM004T",
        firmware_version: "v2.3.8-tls",
        phase_support: "SINGLE_PHASE",
        measures_voltage: true,
        measures_power_factor: true,
        connection_protocol: "HTTPS_REST",
        status: "ONLINE",
        last_heartbeat: "2026-11-09T12:48:40Z",
        last_transmission: "2026-11-09T12:48:20Z",
        data_completeness_pct: 97.6,
        is_simulated: true,
        created_at: "2026-04-12T10:45:00Z",
        updated_at: "2026-11-09T12:48:40Z",
      },
      {
        id: "dev-nodemcu-ct-05",
        organization_id: "org-ikm-sinar",
        machine_id: "mch-pmp-05",
        name: "Legacy NodeMCU CT-Clamp #05 (WWTP Pump)",
        serial_number: "ESME-NODEMCU-CT-2025-005",
        hardware_type: "NODEMCU_CT_ONLY",
        firmware_version: "v1.9.2-legacy",
        phase_support: "SINGLE_PHASE",
        measures_voltage: false,
        measures_power_factor: false,
        connection_protocol: "HTTPS_REST",
        status: "DEGRADED",
        last_heartbeat: "2026-11-09T12:15:00Z",
        last_transmission: "2026-11-09T12:15:00Z",
        data_completeness_pct: 95.3,
        is_simulated: true,
        created_at: "2026-04-12T11:00:00Z",
        updated_at: "2026-11-09T12:15:00Z",
      },
      {
        id: "dev-karya-3p-01",
        organization_id: "org-ikm-karya",
        machine_id: null,
        name: "EcoNode-3P Hydraulic Press Feeder #1",
        serial_number: "ESME-ESP32-3P-2026-101",
        hardware_type: "ESP32_MODBUS_3P",
        firmware_version: "v2.4.1-tls",
        phase_support: "THREE_PHASE",
        measures_voltage: true,
        measures_power_factor: true,
        connection_protocol: "MQTT_TLS",
        status: "ONLINE",
        last_heartbeat: "2026-11-09T12:47:00Z",
        last_transmission: "2026-11-09T12:46:30Z",
        data_completeness_pct: 94.0,
        is_simulated: true,
        created_at: "2026-05-20T09:00:00Z",
        updated_at: "2026-11-09T12:47:00Z",
      },
    ],
    device_credentials: [
      {
        id: "cred-01",
        device_id: "dev-esp32-3p-01",
        organization_id: "org-ikm-sinar",
        key_prefix: "esme_live_9f8a",
        key_hash: hashDeviceSecret("esme_live_9f8a_demo_token_01"),
        status: "ACTIVE",
        created_at: "2026-04-12T10:00:00Z",
        last_used_at: "2026-11-09T12:48:00Z",
      },
      {
        id: "cred-02",
        device_id: "dev-esp32-3p-02",
        organization_id: "org-ikm-sinar",
        key_prefix: "esme_live_3c2b",
        key_hash: hashDeviceSecret("esme_live_3c2b_demo_token_02"),
        status: "ACTIVE",
        created_at: "2026-04-12T10:15:00Z",
        last_used_at: "2026-11-09T12:49:00Z",
      },
    ],
    energy_readings: buildDeterministicReadings(),
    energy_baselines: [
      {
        id: "bl-sinar-2026",
        organization_id: "org-ikm-sinar",
        period_label: "Q2 2026 Pre-Retrofit Baseline (Normalized 30-Day Equivalent)",
        start_date: "2026-04-01",
        end_date: "2026-06-30",
        baseline_energy_kwh: 48900,
        baseline_operating_hours: 448,
        baseline_production_units: 34000,
        tariff_idr_per_kwh: 1444.7,
        methodology_notes:
          "IPMVP Option B — Retrofit Isolation with All Parameter Measurement on 4 main production lines; normalized for monthly operating hours and fabric meterage output.",
        verified_by: "EcoSME Energy Engineering Desk (Internal Audit #EA-2026-08)",
        created_at: "2026-07-01T08:00:00Z",
        updated_at: "2026-10-01T08:00:00Z",
      },
      {
        id: "bl-karya-2026",
        organization_id: "org-ikm-karya",
        period_label: "Q2 2026 Stamping Line Baseline",
        start_date: "2026-04-01",
        end_date: "2026-06-30",
        baseline_energy_kwh: 31200,
        baseline_operating_hours: 350,
        baseline_production_units: 85000,
        tariff_idr_per_kwh: 1444.7,
        methodology_notes: "Normalized against monthly stamped part count.",
        verified_by: "EcoSME Energy Engineering Desk",
        created_at: "2026-07-05T08:00:00Z",
        updated_at: "2026-10-01T08:00:00Z",
      },
    ],
    savings_records: [
      {
        id: "sav-sinar-2026-08",
        organization_id: "org-ikm-sinar",
        period_month: "Aug 2026",
        raw_baseline_kwh: 48900,
        adjusted_baseline_kwh: 48200,
        actual_consumption_kwh: 42350,
        energy_savings_kwh: 5850,
        savings_percentage: 12.14,
        applicable_tariff_idr: 1444.7,
        monetary_savings_idr: 8451495,
        operating_hours_actual: 442,
        production_units_actual: 33500,
        verification_status: "VERIFIED",
        verification_evidence:
          "True 3-phase Modbus & PZEM active power logs reconciled against PLN monthly billing invoice.",
        esaas_applicable: true,
        esaas_share_pct: 30,
        esaas_fee_idr: 2535449,
        ikm_retained_savings_idr: 5916046,
        created_at: "2026-09-02T09:00:00Z",
      },
      {
        id: "sav-sinar-2026-09",
        organization_id: "org-ikm-sinar",
        period_month: "Sep 2026",
        raw_baseline_kwh: 48900,
        adjusted_baseline_kwh: 49100,
        actual_consumption_kwh: 42480,
        energy_savings_kwh: 6620,
        savings_percentage: 13.48,
        applicable_tariff_idr: 1444.7,
        monetary_savings_idr: 9563914,
        operating_hours_actual: 450,
        production_units_actual: 34200,
        verification_status: "VERIFIED",
        verification_evidence:
          "True 3-phase Modbus & PZEM active power logs reconciled against PLN monthly billing invoice.",
        esaas_applicable: true,
        esaas_share_pct: 30,
        esaas_fee_idr: 2869174,
        ikm_retained_savings_idr: 6694740,
        created_at: "2026-10-02T09:00:00Z",
      },
      {
        id: "sav-sinar-2026-10",
        organization_id: "org-ikm-sinar",
        period_month: "Oct 11 – Nov 09, 2026 (Current 30d)",
        raw_baseline_kwh: 48900,
        adjusted_baseline_kwh: 48900,
        actual_consumption_kwh: 41820,
        energy_savings_kwh: 7080,
        savings_percentage: 14.48,
        applicable_tariff_idr: 1444.7,
        monetary_savings_idr: 10228476,
        operating_hours_actual: 456,
        production_units_actual: 34800,
        verification_status: "VERIFIED",
        verification_evidence:
          "6,726 kWh (Rp9,717,052) verified via Class-1 true-power meters; 354 kWh (Rp511,424) on WWTP Pump #2 remains ESTIMATED (excluded from ESaaS fee).",
        esaas_applicable: true,
        esaas_share_pct: 30,
        esaas_fee_idr: 2915116, // 30% of verified Rp9,717,052 only!
        ikm_retained_savings_idr: 7313360,
        created_at: "2026-11-09T06:00:00Z",
      },
    ],
    electricity_tariffs: [
      {
        id: "trf-pln-i3-2026",
        organization_id: "org-ikm-sinar",
        tariff_code: "PLN-I3-TM",
        tariff_name: "PLN Golongan I-3 / B-3 Industri Menengah (>200 kVA)",
        rate_idr_per_kwh: 1444.7,
        peak_rate_idr_per_kwh: 1553.67,
        off_peak_rate_idr_per_kwh: 1035.78,
        effective_date: "2026-01-01",
        source_reference:
          "Permen ESDM Tariff Adjustment Schedule — Industrial Medium Voltage Blended Rate",
        is_active: true,
        created_at: "2026-01-01T00:00:00Z",
      },
    ],
    emission_factors: [
      {
        id: "ef-jamali-2025",
        grid_region: "Jamali (Jawa-Madura-Bali) Interconnected Grid",
        factor_kgco2_per_kwh: 0.78,
        unit: "kgCO2e/kWh",
        source_authority:
          "Directorate General of Electricity, Ministry of Energy and Mineral Resources (ESDM) Indonesia",
        publication_reference:
          "Faktor Emisi Gas Rumah Kaca (GRK) Sistem Ketenagalistrikan Nasional",
        reporting_year: 2025,
        methodology_scope: "GHG Protocol Scope 2 Location-Based Operating Margin",
        is_active: true,
      },
    ],
    green_score_methodologies: [defaultMethodology],
    green_scores: [sinarGreenScore, karyaGreenScore, panganGreenScore],
    data_sharing_consents: [
      {
        id: "cns-sinar-banknusantara",
        organization_id: "org-ikm-sinar",
        partner_bank_id: "org-bank-nusantara",
        partner_bank_name: "Bank Nusantara Hijau — Green Lending Desk (DEMO)",
        status: "ACTIVE",
        shared_scopes: {
          share_green_score: true,
          share_energy_history: true,
          share_savings_verification: true,
          share_sustainability_reports: true,
          share_business_profile: true,
        },
        granted_by_user_id: "usr-ikm-budi",
        granted_by_name: "Ir. Budi Santoso",
        granted_at: "2026-10-20T10:15:00Z",
        revoked_at: null,
        expires_at: "2027-04-20T10:15:00Z",
        purpose_statement:
          "Explicit authorization for Bank Nusantara Hijau to inspect PT Sinar Tekstil Mandiri's Provisional Green Score, 30-day energy telemetry, and verified savings report for green equipment financing evaluation (#APP-2026-001).",
        access_logs: [
          {
            id: "cal-1",
            timestamp: "2026-10-21T14:22:00Z",
            accessor_organization: "Bank Nusantara Hijau — Green Lending Desk (DEMO)",
            accessor_user: "Arief Rahman, CFA",
            action: "Viewed Provisional Green Score Breakdown & Energy Savings Report",
          },
          {
            id: "cal-2",
            timestamp: "2026-11-04T09:40:00Z",
            accessor_organization: "Bank Nusantara Hijau — Green Lending Desk (DEMO)",
            accessor_user: "Arief Rahman, CFA",
            action: "Downloaded Verified Energy Savings & Scope 2 Carbon Summary",
          },
        ],
      },
      {
        id: "cns-karya-banknusantara",
        organization_id: "org-ikm-karya",
        partner_bank_id: "org-bank-nusantara",
        partner_bank_name: "Bank Nusantara Hijau — Green Lending Desk (DEMO)",
        status: "ACTIVE",
        shared_scopes: {
          share_green_score: true,
          share_energy_history: true,
          share_savings_verification: true,
          share_sustainability_reports: true,
          share_business_profile: true,
        },
        granted_by_user_id: "usr-ikm-ratna",
        granted_by_name: "Ratna Dewi, S.T.",
        granted_at: "2026-10-28T11:00:00Z",
        revoked_at: null,
        expires_at: "2027-04-28T11:00:00Z",
        purpose_statement:
          "Explicit authorization for Bank Nusantara Hijau to review CV Karya Logam Presisi's energy efficiency profile for Servo Press Retrofit financing (#APP-2026-002).",
        access_logs: [
          {
            id: "cal-3",
            timestamp: "2026-10-29T16:10:00Z",
            accessor_organization: "Bank Nusantara Hijau — Green Lending Desk (DEMO)",
            accessor_user: "Arief Rahman, CFA",
            action: "Initial Pipeline Screening",
          },
        ],
      },
      {
        id: "cns-pangan-revoked",
        organization_id: "org-ikm-pangan",
        partner_bank_id: "org-bank-nusantara",
        partner_bank_name: "Bank Nusantara Hijau — Green Lending Desk (DEMO)",
        status: "REVOKED",
        shared_scopes: {
          share_green_score: false,
          share_energy_history: false,
          share_savings_verification: false,
          share_sustainability_reports: false,
          share_business_profile: false,
        },
        granted_by_user_id: "usr-admin-nadia",
        granted_by_name: "PT Agro Pangan Director",
        granted_at: "2026-08-10T09:00:00Z",
        revoked_at: "2026-09-15T17:00:00Z",
        expires_at: "2027-02-10T09:00:00Z",
        purpose_statement: "Revoked by IKM owner; data sharing blocked across Bank Portal.",
        access_logs: [],
      },
    ],
    financing_applications: [
      {
        id: "APP-2026-001",
        organization_id: "org-ikm-sinar",
        partner_bank_id: "org-bank-nusantara",
        partner_bank_name: "Bank Nusantara Hijau — Green Lending Desk (DEMO)",
        project_title: "Phase II: High-Efficiency IE4 Dyeing Motors & Exhaust Heat Recovery",
        purpose_category: "HIGH_EFFICIENCY_MOTOR_RETROFIT",
        requested_amount_idr: 450000000,
        estimated_annual_savings_kwh: 84960,
        estimated_annual_savings_idr: 122741712,
        estimated_co2_reduction_kg: 66268.8,
        green_score_at_submission: sinarGreenScore.overall_score,
        green_score_rating: sinarGreenScore.rating,
        status: "Under Review",
        consent_id: "cns-sinar-banknusantara",
        documents_Checklist: {
          company_registration_nib: true,
          npwp_tax_compliance: true,
          pln_electricity_bills_6m: true,
          ecosme_green_score_report: true,
          equipment_vendor_quotation: true,
        },
        bank_reviewer_notes:
          "Technical energy baseline and 14.48% verified savings from Phase I VFD retrofit confirmed via EcoSME telemetry. Currently in credit committee review at Bank Nusantara Hijau.",
        activities: [
          {
            id: "act-1",
            timestamp: "2026-10-20T10:15:00Z",
            actor_name: "Ir. Budi Santoso",
            actor_role: "IKM_OWNER",
            status_from: "Draft",
            status_to: "Submitted",
            note: "Submitted financing-readiness package with explicit data-sharing consent (#cns-sinar-banknusantara).",
          },
          {
            id: "act-2",
            timestamp: "2026-10-22T11:30:00Z",
            actor_name: "Arief Rahman, CFA",
            actor_role: "BANK_OFFICER",
            status_from: "Submitted",
            status_to: "Under Review",
            note: "Verified Provisional Green Score (Grade A) and 6-month PLN bill reconciliation. Assigned to technical credit analyst.",
          },
        ],
        submitted_at: "2026-10-20T10:15:00Z",
        updated_at: "2026-10-22T11:30:00Z",
        created_at: "2026-10-18T14:00:00Z",
      },
      {
        id: "APP-2026-002",
        organization_id: "org-ikm-karya",
        partner_bank_id: "org-bank-nusantara",
        partner_bank_name: "Bank Nusantara Hijau — Green Lending Desk (DEMO)",
        project_title: "Servo-Driven Stamping Press Upgrade & Power Factor Capacitor Bank",
        purpose_category: "INVERTER_VFD_UPGRADE",
        requested_amount_idr: 320000000,
        estimated_annual_savings_kwh: 41800,
        estimated_annual_savings_idr: 60388460,
        estimated_co2_reduction_kg: 32604,
        green_score_at_submission: karyaGreenScore.overall_score,
        green_score_rating: karyaGreenScore.rating,
        status: "Submitted",
        consent_id: "cns-karya-banknusantara",
        documents_Checklist: {
          company_registration_nib: true,
          npwp_tax_compliance: true,
          pln_electricity_bills_6m: true,
          ecosme_green_score_report: true,
          equipment_vendor_quotation: false,
        },
        bank_reviewer_notes:
          "Awaiting updated vendor quotation for the 150-kVAr automatic capacitor bank before moving to technical underwriting.",
        activities: [
          {
            id: "act-3",
            timestamp: "2026-10-28T11:05:00Z",
            actor_name: "Ratna Dewi, S.T.",
            actor_role: "IKM_OWNER",
            status_from: "Draft",
            status_to: "Submitted",
            note: "Submitted financing application with authorized Green Score Grade B profile.",
          },
        ],
        submitted_at: "2026-10-28T11:05:00Z",
        updated_at: "2026-10-28T11:05:00Z",
        created_at: "2026-10-25T09:00:00Z",
      },
    ],
    reports: [
      {
        id: "rep-sinar-energy-202611",
        organization_id: "org-ikm-sinar",
        report_type: "ENERGY_CONSUMPTION",
        title: "30-Day Industrial Energy Consumption & Load Profile Report",
        reporting_period: "Oct 11, 2026 – Nov 09, 2026",
        generated_by: "Ir. Budi Santoso",
        generated_at: "2026-11-09T07:00:00Z",
        data_quality_status: "98.2% Completeness (4/5 True Power, 1/5 CT Estimated)",
        methodology_version: "v1.2-2026",
        summary_metrics: {
          total_consumption_kwh: 41820,
          estimated_electricity_cost_idr: 60417354,
          active_machines: 5,
          tariff_applied: "Rp1,444.70/kWh (PLN I-3)",
        },
      },
      {
        id: "rep-sinar-savings-202611",
        organization_id: "org-ikm-sinar",
        report_type: "ENERGY_SAVINGS",
        title: "Normalized Energy Savings & ESaaS Verification Statement",
        reporting_period: "Oct 11, 2026 – Nov 09, 2026",
        generated_by: "Ir. Budi Santoso",
        generated_at: "2026-11-09T07:05:00Z",
        data_quality_status: "95.0% Verified Active Power / 5.0% Estimated",
        methodology_version: "IPMVP-Option-B / EcoSME v1.2",
        summary_metrics: {
          adjusted_baseline_kwh: 48900,
          actual_consumption_kwh: 41820,
          total_savings_kwh: 7080,
          verified_savings_kwh: 6726,
          estimated_savings_kwh: 354,
          monetary_savings_idr: 10228476,
        },
      },
      {
        id: "rep-sinar-carbon-202611",
        organization_id: "org-ikm-sinar",
        report_type: "SUSTAINABILITY_CARBON",
        title: "Scope 2 Location-Based GHG Emissions & Reduction Report",
        reporting_period: "Oct 11, 2026 – Nov 09, 2026",
        generated_by: "Ir. Budi Santoso",
        generated_at: "2026-11-09T07:10:00Z",
        data_quality_status: "ESDM Jamali Grid Factor (0.78 kgCO2e/kWh)",
        methodology_version: "GHG-Scope2-v1.2",
        summary_metrics: {
          gross_emissions_kgco2e: 32619.6,
          estimated_reduction_kgco2e: 5522.4,
          estimated_reduction_tonnes: 5.522,
          emission_factor: "0.78 kgCO2e/kWh (ESDM 2025)",
        },
      },
      {
        id: "rep-sinar-greenscore-202611",
        organization_id: "org-ikm-sinar",
        report_type: "GREEN_SCORE_CARD",
        title: "EcoSME Provisional Green Score Assessment Dossier",
        reporting_period: "Oct 11, 2026 – Nov 09, 2026",
        generated_by: "EcoSME Scoring Engine",
        generated_at: "2026-11-09T07:15:00Z",
        data_quality_status: "HIGH_QUALITY (98.2% Completeness)",
        methodology_version: "v1.2-2026",
        summary_metrics: {
          overall_score: sinarGreenScore.overall_score,
          rating: sinarGreenScore.rating,
          status_label: "Provisional Green Score",
          efficiency_savings_pct: "14.48%",
        },
      },
      {
        id: "rep-sinar-financing-202611",
        organization_id: "org-ikm-sinar",
        report_type: "FINANCING_READINESS",
        title: "Green Finance Readiness & Bank Underwriting Package (#APP-2026-001)",
        reporting_period: "Oct 11, 2026 – Nov 09, 2026",
        generated_by: "Ir. Budi Santoso",
        generated_at: "2026-11-09T07:20:00Z",
        data_quality_status: "Consent Active (#cns-sinar-banknusantara)",
        methodology_version: "v1.2-2026",
        summary_metrics: {
          requested_financing_idr: 450000000,
          projected_annual_savings_idr: 122741712,
          green_score: `${sinarGreenScore.overall_score}/100 (Grade ${sinarGreenScore.rating})`,
          consent_status: "ACTIVE — Bank Nusantara Hijau",
        },
      },
    ],
    alerts: [
      {
        id: "alt-sinar-01",
        organization_id: "org-ikm-sinar",
        machine_id: "mch-dye-01",
        device_id: "dev-esp32-3p-01",
        severity: "WARNING",
        status: "ACTIVE",
        category: "ENERGY_SPIKE",
        title: "Morning Shift Heating Surge on Jet Dyeing Line #1",
        description:
          "Active power draw reached 34.8 kW during 08:15–08:45 shift startup, exceeding the rolling shift baseline (26.5 kW) by 31.3% due to simultaneous steam booster activation.",
        rule_triggered: "power_kw > rolling_avg_kw * 1.25 (Spike Deviation > 25%)",
        threshold_value: "33.1 kW",
        observed_value: "34.8 kW",
        created_at: "2026-11-09T08:45:00Z",
        acknowledged_at: null,
        resolved_at: null,
      },
      {
        id: "alt-sinar-02",
        organization_id: "org-ikm-sinar",
        machine_id: "mch-pmp-05",
        device_id: "dev-nodemcu-ct-05",
        severity: "INFORMATIONAL",
        status: "ACTIVE",
        category: "MISSING_SENSOR_DATA",
        title: "Current-Only Sensor Lacks Voltage & Power Factor Telemetry",
        description:
          "Legacy NodeMCU CT-Clamp (#05) on WWTP Pump #2 transmits current (A) only. Voltage (220V) and PF (0.85) are assumed, so readings are classified as ESTIMATED rather than billing-grade VERIFIED.",
        rule_triggered: "measures_voltage == false OR measures_power_factor == false",
        threshold_value: "True V, I, PF Metering",
        observed_value: "I-only (V=null, PF=null)",
        created_at: "2026-11-08T14:00:00Z",
        acknowledged_at: null,
        resolved_at: null,
      },
      {
        id: "alt-sinar-03",
        organization_id: "org-ikm-sinar",
        machine_id: "mch-wvg-03",
        device_id: "dev-esp32-3p-03",
        severity: "CRITICAL",
        status: "ACKNOWLEDGED",
        category: "ABNORMAL_POWER",
        title: "Compressed Air Manifold Leak Spike on Weaving Cluster A",
        description:
          "Sustained off-shift power draw of 9.4 kW detected during scheduledSunday standby window (expected < 2.5 kW). Maintenance team isolated leaking quick-coupler on Loom #7.",
        rule_triggered: "standby_power_kw > 3.0 kW for > 45 minutes",
        threshold_value: "3.0 kW",
        observed_value: "9.4 kW",
        created_at: "2026-11-07T22:15:00Z",
        acknowledged_at: "2026-11-08T07:10:00Z",
        resolved_at: null,
      },
    ],
    alert_thresholds: [
      {
        organization_id: "org-ikm-sinar",
        over_power_threshold_pct: 115,
        spike_deviation_pct: 25,
        min_power_factor: 0.85,
        heartbeat_timeout_minutes: 15,
        voltage_tolerance_pct: 10,
      },
    ],
    audit_logs: [
      {
        id: "aud-1001",
        user_id: "usr-ikm-budi",
        user_name: "Ir. Budi Santoso",
        user_role: "IKM_OWNER",
        organization_id: "org-ikm-sinar",
        action: "CONSENT_GRANTED",
        target_record: "DataSharingConsent:cns-sinar-banknusantara",
        timestamp: "2026-10-20T10:15:00Z",
        metadata: {
          partner_bank: "Bank Nusantara Hijau — Green Lending Desk (DEMO)",
          scopes: "green_score,energy_history,savings_verification,sustainability,business_profile",
        },
      },
      {
        id: "aud-1002",
        user_id: "usr-ikm-budi",
        user_name: "Ir. Budi Santoso",
        user_role: "IKM_OWNER",
        organization_id: "org-ikm-sinar",
        action: "FINANCING_APPLICATION_SUBMITTED",
        target_record: "FinancingApplication:APP-2026-001",
        timestamp: "2026-10-20T10:16:00Z",
        metadata: {
          requested_amount_idr: 450000000,
          green_score: sinarGreenScore.overall_score,
        },
      },
      {
        id: "aud-1003",
        user_id: "usr-bank-arief",
        user_name: "Arief Rahman, CFA",
        user_role: "BANK_OFFICER",
        organization_id: "org-bank-nusantara",
        action: "APPLICATION_STATUS_UPDATED",
        target_record: "FinancingApplication:APP-2026-001",
        timestamp: "2026-10-22T11:30:00Z",
        metadata: {
          previous_status: "Submitted",
          new_status: "Under Review",
          ikm_organization_id: "org-ikm-sinar",
        },
      },
      {
        id: "aud-1004",
        user_id: "usr-admin-nadia",
        user_name: "Nadia Putri, M.T.",
        user_role: "ECOSME_ADMIN",
        organization_id: "org-ecosme-hq",
        action: "METHODOLOGY_PUBLISHED",
        target_record: "GreenScoreMethodology:gsm-v1.2",
        timestamp: "2026-10-15T09:00:00Z",
        metadata: {
          version: "v1.2-2026",
          is_externally_validated: false,
          label: "Provisional Green Score",
        },
      },
    ],
    subscriptions: [
      {
        id: "sub-sinar-pro",
        organization_id: "org-ikm-sinar",
        plan_id: "PRO",
        plan_name: "EcoSME Pro + ESaaS Performance Plan",
        monthly_price_idr: 699000,
        status: "ACTIVE",
        billing_cycle: "MONTHLY",
        esaas_enabled: true,
        esaas_share_percentage: 30,
        current_period_start: "2026-11-01",
        current_period_end: "2026-11-30",
      },
      {
        id: "sub-karya-growth",
        organization_id: "org-ikm-karya",
        plan_id: "GROWTH",
        plan_name: "EcoSME Growth Plan",
        monthly_price_idr: 349000,
        status: "ACTIVE",
        billing_cycle: "MONTHLY",
        esaas_enabled: false,
        esaas_share_percentage: 30,
        current_period_start: "2026-11-01",
        current_period_end: "2026-11-30",
      },
      {
        id: "sub-pangan-basic",
        organization_id: "org-ikm-pangan",
        plan_id: "BASIC",
        plan_name: "EcoSME Basic Plan",
        monthly_price_idr: 149000,
        status: "ACTIVE",
        billing_cycle: "MONTHLY",
        esaas_enabled: false,
        esaas_share_percentage: 30,
        current_period_start: "2026-11-01",
        current_period_end: "2026-11-30",
      },
    ],
    platform_config: {
      demo_mode_enabled: true,
      referral_commission_min_pct: 1.0,
      referral_commission_max_pct: 2.0,
      default_esaas_share_pct: 30,
      plans: [
        {
          id: "BASIC",
          name: "Basic",
          monthly_price_idr: 149000,
          max_machines: 3,
          features: [
            "Basic industrial energy dashboard",
            "Up to 3 monitored machines",
            "Monthly energy consumption PDF reports",
            "Standard PLN tariff cost tracking",
          ],
          includes_green_score: false,
          includes_financing_gateway: false,
          is_hypothesis_pricing: true,
        },
        {
          id: "GROWTH",
          name: "Growth",
          monthly_price_idr: 349000,
          max_machines: 10,
          features: [
            "Expanded machine monitoring (up to 10 lines)",
            "Single-phase & 3-phase power factor analysis",
            "Configurable anomaly & power spike alerts",
            "IPMVP-aligned normalized energy savings reports",
          ],
          includes_green_score: true,
          includes_financing_gateway: false,
          is_hypothesis_pricing: true,
        },
        {
          id: "PRO",
          name: "Pro",
          monthly_price_idr: 699000,
          max_machines: 50,
          features: [
            "Advanced multi-zone telemetry & API ingestion",
            "Scope 2 GHG sustainability & carbon footprint reports",
            "Full Provisional Green Score Card & methodology breakdown",
            "Green Finance Gateway & consented bank dossier sharing",
            "Optional Energy Savings-as-a-Service (ESaaS) billing integration",
          ],
          includes_green_score: true,
          includes_financing_gateway: true,
          is_hypothesis_pricing: true,
        },
      ],
    },
  };
}

export function getDb(): EcoSMEDatabaseState {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (!fs.existsSync(DB_FILE_PATH)) {
      const initial = createInitialSeedState();
      fs.writeFileSync(DB_FILE_PATH, JSON.stringify(initial, null, 2), "utf-8");
      return initial;
    }
    const raw = fs.readFileSync(DB_FILE_PATH, "utf-8");
    return JSON.parse(raw) as EcoSMEDatabaseState;
  } catch {
    return createInitialSeedState();
  }
}

export function saveDb(state: EcoSMEDatabaseState): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(DB_FILE_PATH, JSON.stringify(state, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to persist EcoSME database state:", err);
  }
}

export function resetDbToSeed(): EcoSMEDatabaseState {
  const initial = createInitialSeedState();
  saveDb(initial);
  return initial;
}

export function appendAuditLog(
  db: EcoSMEDatabaseState,
  entry: Omit<AuditLog, "id" | "timestamp">
): AuditLog {
  const log: AuditLog = {
    id: `aud-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    timestamp: new Date().toISOString(),
    ...entry,
  };
  db.audit_logs.unshift(log);
  return log;
}
