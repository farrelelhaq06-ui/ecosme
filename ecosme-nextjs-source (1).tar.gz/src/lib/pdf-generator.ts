import { jsPDF } from "jspdf";
import {
  EmissionFactor,
  FinancingApplication,
  GreenScore,
  Machine,
  Organization,
  ReportType,
  SavingsRecord,
} from "./types";
import { formatIdr, formatNumber } from "./formatters";

export interface GenerateReportPdfPayload {
  reportType: ReportType;
  organization: Organization;
  reportingPeriod: string;
  tariffIdrPerKwh: number;
  totalEnergyKwh: number;
  baselineEnergyKwh: number;
  verifiedSavingsKwh: number;
  estimatedSavingsKwh: number;
  greenScore: GreenScore;
  emissionFactor: EmissionFactor;
  machines: Machine[];
  latestSavingsRecord?: SavingsRecord;
  financingApplication?: FinancingApplication;
}

export function downloadEcoSMEReportPdf(payload: GenerateReportPdfPayload): void {
  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const nowStr = new Date().toISOString().replace("T", " ").slice(0, 19) + " UTC";

  // Header Banner (#123B2A Forest Green)
  doc.setFillColor(18, 59, 42);
  doc.rect(0, 0, 210, 34, "F");

  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.text("EcoSME — Industrial Energy & Green Finance Readiness", 14, 14);

  const reportTitles: Record<ReportType, string> = {
    ENERGY_CONSUMPTION: "1. INDUSTRIAL ENERGY CONSUMPTION REPORT",
    ENERGY_SAVINGS: "2. NORMALIZED ENERGY SAVINGS & VERIFICATION REPORT",
    SUSTAINABILITY_CARBON: "3. SUSTAINABILITY & SCOPE 2 CARBON FOOTPRINT REPORT",
    GREEN_SCORE_CARD: "4. ECOSME PROVISIONAL GREEN SCORE ASSESSMENT CARD",
    FINANCING_READINESS: "5. GREEN FINANCE READINESS & UNDERWRITING DOSSIER",
  };

  doc.setFontSize(11);
  doc.text(reportTitles[payload.reportType], 14, 22);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.text(
    `Generated: ${nowStr}   |   Data Classification: DEMO DATA (Deterministic Fixture)`,
    14,
    29
  );

  let y = 43;

  // Section 1: Organization & Reporting Period
  doc.setTextColor(18, 59, 42);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.text("1. Organization & Assessment Metadata", 14, y);
  y += 5;

  doc.setDrawColor(210, 220, 214);
  doc.line(14, y, 196, y);
  y += 6;

  doc.setTextColor(30, 41, 59);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9.5);

  const metaRows: Array<[string, string]> = [
    ["Organization Name", payload.organization.name],
    ["Industry Sector", payload.organization.industry_category],
    ["Facility Location", payload.organization.address],
    ["Tax ID (NPWP) / NIB", `${payload.organization.tax_id_npwp} / ${payload.organization.business_license_nib}`],
    ["PLN Tariff Category", `${payload.organization.pln_tariff_class} (${formatIdr(payload.tariffIdrPerKwh)}/kWh)`],
    ["Reporting Period", payload.reportingPeriod],
    [
      "Data Quality Status",
      `${payload.greenScore.data_quality_status} (${payload.greenScore.data_completeness_pct}% Telemetry Completeness)`,
    ],
  ];

  for (const [label, value] of metaRows) {
    doc.setFont("helvetica", "bold");
    doc.text(`${label}:`, 14, y);
    doc.setFont("helvetica", "normal");
    doc.text(value, 68, y);
    y += 5.5;
  }

  y += 4;

  // Section 2: Core Measurements & Specific Report Body
  doc.setTextColor(18, 59, 42);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.text("2. Verified & Estimated Performance Measurements", 14, y);
  y += 5;
  doc.line(14, y, 196, y);
  y += 6;

  doc.setTextColor(30, 41, 59);
  doc.setFontSize(9.5);

  const totalCostIdr = Math.round(payload.totalEnergyKwh * payload.tariffIdrPerKwh);
  const totalSavingsKwh = payload.verifiedSavingsKwh + payload.estimatedSavingsKwh;
  const totalSavingsIdr = Math.round(totalSavingsKwh * payload.tariffIdrPerKwh);
  const verifiedSavingsIdr = Math.round(payload.verifiedSavingsKwh * payload.tariffIdrPerKwh);
  const estimatedSavingsIdr = Math.round(payload.estimatedSavingsKwh * payload.tariffIdrPerKwh);
  const grossCo2Kg = payload.totalEnergyKwh * payload.emissionFactor.factor_kgco2_per_kwh;
  const reducedCo2Kg = totalSavingsKwh * payload.emissionFactor.factor_kgco2_per_kwh;

  if (payload.reportType === "ENERGY_CONSUMPTION") {
    const rows: Array<[string, string]> = [
      ["Total Energy Consumed (30d)", `${formatNumber(payload.totalEnergyKwh, 1)} kWh`],
      ["Applicable PLN Electricity Tariff", `${formatIdr(payload.tariffIdrPerKwh)} / kWh`],
      ["Estimated Electricity Cost", formatIdr(totalCostIdr)],
      ["Monitored Industrial Machines", `${payload.machines.length} lines (4 True Active Power, 1 CT-Only)`],
    ];
    for (const [k, v] of rows) {
      doc.setFont("helvetica", "bold");
      doc.text(k, 14, y);
      doc.setFont("helvetica", "normal");
      doc.text(v, 95, y);
      y += 5.5;
    }
    y += 3;
    doc.setFont("helvetica", "bold");
    doc.text("Machine-Level Breakdown:", 14, y);
    y += 5.5;
    for (const m of payload.machines) {
      doc.setFont("helvetica", "normal");
      const modeTag =
        m.code === "MCH-PMP-05"
          ? "[ESTIMATED - CT Only]"
          : "[MEASURED (DEMO) - True V*I*PF]";
      doc.text(
        `• ${m.code} — ${m.name}: ${formatNumber(m.monthly_energy_kwh, 1)} kWh (${m.phase_type}) ${modeTag}`,
        16,
        y
      );
      y += 5;
    }
  } else if (payload.reportType === "ENERGY_SAVINGS") {
    const savingsPct =
      payload.baselineEnergyKwh > 0
        ? ((totalSavingsKwh / payload.baselineEnergyKwh) * 100).toFixed(2)
        : "0.00";
    const rows: Array<[string, string]> = [
      ["Normalized Baseline Consumption", `${formatNumber(payload.baselineEnergyKwh, 1)} kWh`],
      ["Current Period Consumption", `${formatNumber(payload.totalEnergyKwh, 1)} kWh`],
      ["Total Energy Savings", `${formatNumber(totalSavingsKwh, 1)} kWh (${savingsPct}% reduction)`],
      ["  - Verified Energy Savings (True Power Meters)", `${formatNumber(payload.verifiedSavingsKwh, 1)} kWh (${formatIdr(verifiedSavingsIdr)})`],
      ["  - Estimated Energy Savings (CT-Only Sensor)", `${formatNumber(payload.estimatedSavingsKwh, 1)} kWh (${formatIdr(estimatedSavingsIdr)})`],
      ["Total Monetary Savings", formatIdr(totalSavingsIdr)],
      [
        "ESaaS Service Fee (30% on Verified Savings Only)",
        formatIdr(Math.round(verifiedSavingsIdr * 0.3)),
      ],
      [
        "Net Savings Retained by IKM",
        formatIdr(totalSavingsIdr - Math.round(verifiedSavingsIdr * 0.3)),
      ],
    ];
    for (const [k, v] of rows) {
      doc.setFont("helvetica", "bold");
      doc.text(k, 14, y);
      doc.setFont("helvetica", "normal");
      doc.text(v, 102, y);
      y += 5.5;
    }
  } else if (payload.reportType === "SUSTAINABILITY_CARBON") {
    const rows: Array<[string, string]> = [
      ["Total Electricity Consumption", `${formatNumber(payload.totalEnergyKwh, 1)} kWh`],
      ["Total Electricity Saved vs Baseline", `${formatNumber(totalSavingsKwh, 1)} kWh`],
      ["Gross Scope 2 Emissions", `${formatNumber(grossCo2Kg, 1)} kgCO2e (${(grossCo2Kg / 1000).toFixed(2)} tCO2e)`],
      ["Estimated Scope 2 CO2e Reduction", `${formatNumber(reducedCo2Kg, 1)} kgCO2e (${(reducedCo2Kg / 1000).toFixed(2)} tCO2e)`],
      ["Grid Emission Factor Applied", `${payload.emissionFactor.factor_kgco2_per_kwh} ${payload.emissionFactor.unit}`],
      ["Emission Factor Authority & Year", `${payload.emissionFactor.source_authority} (${payload.emissionFactor.reporting_year})`],
      ["Geographic Grid Applicability", payload.emissionFactor.grid_region],
      ["Methodology Scope", payload.emissionFactor.methodology_scope],
    ];
    for (const [k, v] of rows) {
      doc.setFont("helvetica", "bold");
      doc.text(k, 14, y);
      doc.setFont("helvetica", "normal");
      doc.text(v, 90, y);
      y += 5.5;
    }
  } else if (payload.reportType === "GREEN_SCORE_CARD") {
    doc.setFont("helvetica", "bold");
    doc.text(
      `Overall Score: ${payload.greenScore.overall_score} / 100   |   Grade Rating: ${payload.greenScore.rating}   |   Status: ${payload.greenScore.status_label}`,
      14,
      y
    );
    y += 6;
    doc.setFont("helvetica", "normal");
    doc.text(`Methodology Version: ${payload.greenScore.methodology_version}`, 14, y);
    y += 6;
    for (const dim of payload.greenScore.dimensions) {
      doc.setFont("helvetica", "bold");
      doc.text(
        `• ${dim.label} (Weight ${dim.weight_pct}%): Score ${dim.raw_score}/100 (Weighted: ${dim.weighted_score})`,
        14,
        y
      );
      y += 4.8;
      doc.setFont("helvetica", "normal");
      doc.text(`  Evidence: ${dim.metric_evidence}`, 16, y);
      y += 5.5;
    }
  } else if (payload.reportType === "FINANCING_READINESS") {
    const app = payload.financingApplication;
    const rows: Array<[string, string]> = [
      ["Green Score Readiness Status", `${payload.greenScore.overall_score}/100 (Grade ${payload.greenScore.rating} — ${payload.greenScore.status_label})`],
      ["Application Reference", app ? `${app.id} — ${app.project_title}` : "Ready for Submission"],
      ["Target Partner Institution", app ? app.partner_bank_name : "Authorized Partner Bank"],
      ["Requested Green Financing Amount", app ? formatIdr(app.requested_amount_idr) : "Rp450,000,000"],
      ["Projected Annual Energy Savings", app ? `${formatNumber(app.estimated_annual_savings_kwh, 0)} kWh (${formatIdr(app.estimated_annual_savings_idr)}/yr)` : "84,960 kWh"],
      ["Current Application Status", app ? app.status : "Under Review"],
    ];
    for (const [k, v] of rows) {
      doc.setFont("helvetica", "bold");
      doc.text(k, 14, y);
      doc.setFont("helvetica", "normal");
      doc.text(v, 90, y);
      y += 5.5;
    }
  }

  y += 5;

  // Section 3: Calculation Methodology
  doc.setTextColor(18, 59, 42);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.text("3. Calculation Methodology & Engineering Standards", 14, y);
  y += 5;
  doc.line(14, y, 196, y);
  y += 6;

  doc.setTextColor(55, 65, 81);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.8);
  const methodologyLines = [
    "• Electricity Cost = Energy Consumption (kWh) × Applicable PLN Tariff (IDR/kWh).",
    "• Energy Savings (kWh) = Adjusted Baseline Consumption − Current Consumption (normalized for operating hours & output).",
    "• Active Power Measurement: True active power requires Voltage (V), Current (A), and Power Factor (PF). Current-only (CT)",
    "  readings on auxiliary lines are segregated as ESTIMATED and excluded from ESaaS performance fees.",
    "• Carbon Reduction: Electricity Savings (kWh) × ESDM Published Grid Emission Factor (0.78 kgCO2e/kWh for Jamali Grid).",
  ];
  for (const line of methodologyLines) {
    doc.text(line, 14, y);
    y += 4.8;
  }

  y += 4;

  // Section 4: Assumptions, Limitations & Regulatory Disclaimers
  doc.setTextColor(18, 59, 42);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.text("4. Assumptions, Limitations & Regulatory Disclaimers", 14, y);
  y += 5;
  doc.line(14, y, 196, y);
  y += 6;

  doc.setTextColor(75, 85, 99);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  const disclaimerLines = [
    "1. DEMO MODE DISCLOSURE: This report is generated from EcoSME's deterministic demo dataset for evaluation purposes.",
    "2. PROVISIONAL GREEN SCORE: The EcoSME Green Score evaluates operational energy efficiency and telemetry reliability.",
    "   It is labeled 'Provisional Green Score' pending external third-party validation and does not constitute a credit rating.",
    "3. CARBON DISCLAIMER: Scope 2 CO2e reductions are operational estimates and do not represent certified carbon credits.",
    "4. BANK CREDIT AUTHORITY: EcoSME provides technical energy-readiness profiles only. All financing approvals, credit risk",
    "   underwriting, and loan terms remain the sole decision of the partner financial institution.",
  ];
  for (const line of disclaimerLines) {
    doc.text(line, 14, y);
    y += 4.6;
  }

  const fileSlug = payload.reportType.toLowerCase().replace(/_/g, "-");
  doc.save(`ecosme-${fileSlug}-${payload.organization.id}.pdf`);
}
