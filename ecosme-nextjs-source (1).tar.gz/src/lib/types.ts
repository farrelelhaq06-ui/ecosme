export type UserRole = "IKM_OWNER" | "BANK_OFFICER" | "ECOSME_ADMIN";

export type DataClassification = "MEASURED_IOT" | "SIMULATED_DEMO" | "ESTIMATED" | "VERIFIED";

export type AlertSeverity = "CRITICAL" | "WARNING" | "INFORMATIONAL";

export type AlertStatus = "ACTIVE" | "ACKNOWLEDGED" | "RESOLVED";

export type GreenScoreRating = "A" | "B" | "C" | "D";

export type ApplicationStatus =
  | "Draft"
  | "Submitted"
  | "Under Review"
  | "Additional Information Required"
  | "Approved by Bank"
  | "Rejected by Bank"
  | "Disbursed";

export type SubscriptionPlanId = "BASIC" | "GROWTH" | "PRO";

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  organization_id: string;
  title: string;
  active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Organization {
  id: string;
  name: string;
  type: "IKM" | "BANK" | "PLATFORM";
  industry_category: string;
  location: string;
  address: string;
  tax_id_npwp: string;
  business_license_nib: string;
  contact_email: string;
  contact_phone: string;
  employee_count: number;
  operating_hours_per_day: number;
  operating_days_per_month: number;
  pln_tariff_class: string;
  installed_capacity_kva: number;
  subscription_id: string;
  is_demo: boolean;
  created_at: string;
  updated_at: string;
}

export interface OrganizationMember {
  id: string;
  organization_id: string;
  user_id: string;
  member_role: "OWNER" | "ENERGY_MANAGER" | "FINANCE_OFFICER" | "AUDITOR";
  created_at: string;
}

export interface Machine {
  id: string;
  organization_id: string;
  name: string;
  code: string;
  category: string;
  location_zone: string;
  rated_power_kw: number;
  phase_type: "SINGLE_PHASE" | "THREE_PHASE";
  nominal_voltage_v: number;
  status: "ONLINE" | "OFFLINE" | "MAINTENANCE" | "DEACTIVATED";
  device_id: string | null;
  monthly_energy_kwh: number;
  baseline_monthly_kwh: number;
  last_data_received: string | null;
  efficiency_notes: string;
  created_at: string;
  updated_at: string;
}

export interface Device {
  id: string;
  organization_id: string;
  machine_id: string | null;
  name: string;
  serial_number: string;
  hardware_type: "ESP32_PZEM004T" | "ESP32_MODBUS_3P" | "NODEMCU_CT_ONLY" | "SCHNEIDER_PM2230";
  firmware_version: string;
  phase_support: "SINGLE_PHASE" | "THREE_PHASE";
  measures_voltage: boolean;
  measures_power_factor: boolean;
  connection_protocol: "HTTPS_REST" | "MQTT_TLS";
  status: "ONLINE" | "OFFLINE" | "DEGRADED";
  last_heartbeat: string;
  last_transmission: string;
  data_completeness_pct: number;
  is_simulated: boolean;
  created_at: string;
  updated_at: string;
}

export interface DeviceCredential {
  id: string;
  device_id: string;
  organization_id: string;
  key_prefix: string;
  key_hash: string;
  status: "ACTIVE" | "REVOKED";
  created_at: string;
  last_used_at: string | null;
}

export interface EnergyReading {
  id: string;
  organization_id: string;
  machine_id: string;
  device_id: string;
  timestamp: string;
  date_label: string;
  voltage_v: number | null;
  current_a: number;
  power_kw: number;
  power_factor: number | null;
  energy_kwh: number;
  production_units: number;
  operating_hours: number;
  classification: DataClassification;
}

export interface EnergyBaseline {
  id: string;
  organization_id: string;
  period_label: string;
  start_date: string;
  end_date: string;
  baseline_energy_kwh: number;
  baseline_operating_hours: number;
  baseline_production_units: number;
  tariff_idr_per_kwh: number;
  methodology_notes: string;
  verified_by: string;
  created_at: string;
  updated_at: string;
}

export interface SavingsRecord {
  id: string;
  organization_id: string;
  period_month: string;
  raw_baseline_kwh: number;
  adjusted_baseline_kwh: number;
  actual_consumption_kwh: number;
  energy_savings_kwh: number;
  savings_percentage: number;
  applicable_tariff_idr: number;
  monetary_savings_idr: number;
  operating_hours_actual: number;
  production_units_actual: number;
  verification_status: "ESTIMATED" | "VERIFIED";
  verification_evidence: string;
  esaas_applicable: boolean;
  esaas_share_pct: number;
  esaas_fee_idr: number;
  ikm_retained_savings_idr: number;
  created_at: string;
}

export interface ElectricityTariff {
  id: string;
  organization_id: string;
  tariff_code: string;
  tariff_name: string;
  rate_idr_per_kwh: number;
  peak_rate_idr_per_kwh: number;
  off_peak_rate_idr_per_kwh: number;
  effective_date: string;
  source_reference: string;
  is_active: boolean;
  created_at: string;
}

export interface EmissionFactor {
  id: string;
  grid_region: string;
  factor_kgco2_per_kwh: number;
  unit: "kgCO2e/kWh";
  source_authority: string;
  publication_reference: string;
  reporting_year: number;
  methodology_scope: string;
  is_active: boolean;
}

export interface GreenScoreDimension {
  key:
    | "efficiency_improvement"
    | "consumption_stability"
    | "data_completeness"
    | "sustainability_performance"
    | "monitoring_consistency";
  label: string;
  weight_pct: number;
  raw_score: number; // 0 - 100
  weighted_score: number;
  explanation: string;
  metric_evidence: string;
}

export interface GreenScore {
  id: string;
  organization_id: string;
  assessment_period: string;
  overall_score: number;
  rating: GreenScoreRating;
  is_provisional: boolean;
  status_label: "Provisional Green Score" | "Validated Green Score";
  methodology_version: string;
  data_quality_status: "HIGH_QUALITY" | "MODERATE_QUALITY" | "INSUFFICIENT_DATA";
  data_completeness_pct: number;
  dimensions: GreenScoreDimension[];
  recommendations: string[];
  calculated_at: string;
}

export interface GreenScoreMethodology {
  id: string;
  version: string;
  name: string;
  is_active: boolean;
  is_externally_validated: boolean;
  weights: {
    efficiency_improvement: number;
    consumption_stability: number;
    data_completeness: number;
    sustainability_performance: number;
    monitoring_consistency: number;
  };
  thresholds: {
    rating_a_min: number;
    rating_b_min: number;
    rating_c_min: number;
  };
  updated_by: string;
  updated_at: string;
}

export interface ApplicationActivity {
  id: string;
  timestamp: string;
  actor_name: string;
  actor_role: UserRole;
  status_from: ApplicationStatus | null;
  status_to: ApplicationStatus;
  note: string;
}

export interface FinancingApplication {
  id: string;
  organization_id: string;
  partner_bank_id: string;
  partner_bank_name: string;
  project_title: string;
  purpose_category: "HIGH_EFFICIENCY_MOTOR_RETROFIT" | "INVERTER_VFD_UPGRADE" | "SOLAR_ROOFTOP_HYBRID" | "COMPRESSED_AIR_OPTIMIZATION" | "BOILER_HEAT_RECOVERY";
  requested_amount_idr: number;
  estimated_annual_savings_kwh: number;
  estimated_annual_savings_idr: number;
  estimated_co2_reduction_kg: number;
  green_score_at_submission: number;
  green_score_rating: GreenScoreRating;
  status: ApplicationStatus;
  consent_id: string;
  documents_Checklist: {
    company_registration_nib: boolean;
    npwp_tax_compliance: boolean;
    pln_electricity_bills_6m: boolean;
    ecosme_green_score_report: boolean;
    equipment_vendor_quotation: boolean;
  };
  bank_reviewer_notes: string;
  activities: ApplicationActivity[];
  submitted_at: string | null;
  updated_at: string;
  created_at: string;
}

export interface ConsentAccessLog {
  id: string;
  timestamp: string;
  accessor_organization: string;
  accessor_user: string;
  action: string;
}

export interface DataSharingConsent {
  id: string;
  organization_id: string;
  partner_bank_id: string;
  partner_bank_name: string;
  status: "ACTIVE" | "REVOKED" | "EXPIRED";
  shared_scopes: {
    share_green_score: boolean;
    share_energy_history: boolean;
    share_savings_verification: boolean;
    share_sustainability_reports: boolean;
    share_business_profile: boolean;
  };
  granted_by_user_id: string;
  granted_by_name: string;
  granted_at: string;
  revoked_at: string | null;
  expires_at: string;
  purpose_statement: string;
  access_logs: ConsentAccessLog[];
}

export type ReportType =
  | "ENERGY_CONSUMPTION"
  | "ENERGY_SAVINGS"
  | "SUSTAINABILITY_CARBON"
  | "GREEN_SCORE_CARD"
  | "FINANCING_READINESS";

export interface Report {
  id: string;
  organization_id: string;
  report_type: ReportType;
  title: string;
  reporting_period: string;
  generated_by: string;
  generated_at: string;
  data_quality_status: string;
  methodology_version: string;
  summary_metrics: Record<string, string | number>;
}

export interface Alert {
  id: string;
  organization_id: string;
  machine_id: string | null;
  device_id: string | null;
  severity: AlertSeverity;
  status: AlertStatus;
  category:
    | "ABNORMAL_POWER"
    | "ENERGY_SPIKE"
    | "DEVICE_DISCONNECTION"
    | "MISSING_SENSOR_DATA"
    | "UNUSUAL_PATTERN";
  title: string;
  description: string;
  rule_triggered: string;
  threshold_value: string;
  observed_value: string;
  created_at: string;
  acknowledged_at: string | null;
  resolved_at: string | null;
}

export interface AuditLog {
  id: string;
  user_id: string;
  user_name: string;
  user_role: UserRole;
  organization_id: string;
  action: string;
  target_record: string;
  timestamp: string;
  metadata: Record<string, string | number | boolean | null>;
}

export interface SubscriptionPlanConfig {
  id: SubscriptionPlanId;
  name: string;
  monthly_price_idr: number;
  max_machines: number;
  features: string[];
  includes_green_score: boolean;
  includes_financing_gateway: boolean;
  is_hypothesis_pricing: boolean;
}

export interface Subscription {
  id: string;
  organization_id: string;
  plan_id: SubscriptionPlanId;
  plan_name: string;
  monthly_price_idr: number;
  status: "ACTIVE" | "TRIAL" | "PAST_DUE";
  billing_cycle: "MONTHLY" | "ANNUAL";
  esaas_enabled: boolean;
  esaas_share_percentage: number;
  current_period_start: string;
  current_period_end: string;
}

export interface AlertThresholdConfig {
  organization_id: string;
  over_power_threshold_pct: number; // e.g., 115% of rated kW
  spike_deviation_pct: number; // e.g., 25% above rolling baseline
  min_power_factor: number; // e.g., 0.85 PLN penalty threshold
  heartbeat_timeout_minutes: number; // e.g., 15 minutes
  voltage_tolerance_pct: number; // e.g., +/- 10% of nominal 220V/380V
}

export interface PlatformConfiguration {
  demo_mode_enabled: boolean;
  referral_commission_min_pct: number;
  referral_commission_max_pct: number;
  default_esaas_share_pct: number;
  plans: SubscriptionPlanConfig[];
}
