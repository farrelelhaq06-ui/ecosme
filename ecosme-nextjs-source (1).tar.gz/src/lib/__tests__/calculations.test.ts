import { describe, expect, it } from "vitest";
import {
  calculateActivePower,
  calculateCarbonFootprint,
  calculateElectricityCost,
  calculateEnergySavings,
  calculateESaaSShare,
  calculateGreenScore,
  evaluateTelemetryAnomalies,
} from "../calculations";
import { EmissionFactor, GreenScoreMethodology } from "../types";

describe("EcoSME Core Calculation Engine", () => {
  describe("calculateActivePower", () => {
    it("calculates true single-phase active power when V, I, and PF are present", () => {
      const res = calculateActivePower({
        phaseType: "SINGLE_PHASE",
        voltageV: 220,
        currentA: 10,
        powerFactor: 0.9,
      });
      expect(res.isTrueActivePower).toBe(true);
      expect(res.calculationMethod).toBe("TRUE_SINGLE_PHASE");
      expect(res.powerWatts).toBe(1980);
      expect(res.powerKw).toBe(1.98);
    });

    it("calculates true three-phase active power using sqrt(3) * V * I * PF", () => {
      const res = calculateActivePower({
        phaseType: "THREE_PHASE",
        voltageV: 380,
        currentA: 25,
        powerFactor: 0.88,
      });
      expect(res.isTrueActivePower).toBe(true);
      expect(res.calculationMethod).toBe("TRUE_THREE_PHASE");
      expect(res.powerKw).toBeCloseTo(14.48, 2);
    });

    it("flags current-only sensor measurements as estimated and non-billing-grade", () => {
      const res = calculateActivePower({
        phaseType: "SINGLE_PHASE",
        currentA: 15,
        voltageV: null,
        powerFactor: null,
      });
      expect(res.isTrueActivePower).toBe(false);
      expect(res.calculationMethod).toBe("ESTIMATED_CURRENT_ONLY");
      expect(res.engineeringNote).toContain("current-only sensor");
    });
  });

  describe("calculateElectricityCost", () => {
    it("computes kWh * tariff accurately and guards against negative inputs", () => {
      expect(calculateElectricityCost(1000, 1444.7)).toBe(1444700);
      expect(calculateElectricityCost(-50, 1444.7)).toBe(0);
      expect(calculateElectricityCost(1000, 0)).toBe(0);
    });
  });

  describe("calculateEnergySavings", () => {
    it("computes unadjusted baseline savings and percentage accurately", () => {
      const res = calculateEnergySavings({
        rawBaselineKwh: 20000,
        currentConsumptionKwh: 17000,
        tariffIdrPerKwh: 1444.7,
        normalizeByOperatingConditions: false,
        hasMeterVerification: true,
      });
      expect(res.energySavingsKwh).toBe(3000);
      expect(res.savingsPercentage).toBe(15);
      expect(res.monetarySavingsIdr).toBe(4334100);
      expect(res.verificationStatus).toBe("VERIFIED");
    });

    it("normalizes baseline by operating hours and production output when enabled", () => {
      const res = calculateEnergySavings({
        rawBaselineKwh: 20000,
        currentConsumptionKwh: 18500,
        tariffIdrPerKwh: 1500,
        baselineOperatingHours: 200,
        actualOperatingHours: 220, // +10%
        baselineProductionUnits: 10000,
        actualProductionUnits: 11000, // +10%
        normalizeByOperatingConditions: true,
        hasMeterVerification: false,
      });
      expect(res.adjustedBaselineKwh).toBe(22000);
      expect(res.energySavingsKwh).toBe(3500);
      expect(res.verificationStatus).toBe("ESTIMATED");
    });

    it("prevents division by zero when baseline is 0", () => {
      const res = calculateEnergySavings({
        rawBaselineKwh: 0,
        currentConsumptionKwh: 500,
        tariffIdrPerKwh: 1444.7,
      });
      expect(res.savingsPercentage).toBe(0);
      expect(res.energySavingsKwh).toBe(0);
    });
  });

  describe("calculateESaaSShare", () => {
    it("calculates 30% EcoSME fee and 70% IKM retention for VERIFIED savings (Rp2,000,000 example)", () => {
      const res = calculateESaaSShare(2000000, "VERIFIED", 30);
      expect(res.eligibleForFee).toBe(true);
      expect(res.ecosmeFeeIdr).toBe(600000);
      expect(res.ikmRetainedSavingsIdr).toBe(1400000);
    });

    it("never charges ESaaS fee on ESTIMATED (unverified) savings", () => {
      const res = calculateESaaSShare(2000000, "ESTIMATED", 30);
      expect(res.eligibleForFee).toBe(false);
      expect(res.ecosmeFeeIdr).toBe(0);
      expect(res.ikmRetainedSavingsIdr).toBe(2000000);
    });
  });

  describe("calculateCarbonFootprint", () => {
    const mockFactor: EmissionFactor = {
      id: "ef-jamali-2025",
      grid_region: "Jamali (Jawa-Madura-Bali) Grid",
      factor_kgco2_per_kwh: 0.78,
      unit: "kgCO2e/kWh",
      source_authority: "Ministry of Energy and Mineral Resources (ESDM) Indonesia",
      publication_reference: "Faktor Emisi GRK Sistem Ketenagalistrikan Nasional",
      reporting_year: 2025,
      methodology_scope: "Scope 2 Location-Based Grid Average",
      is_active: true,
    };

    it("calculates CO2 reduction and retains full emission factor provenance", () => {
      const res = calculateCarbonFootprint(15000, 3000, mockFactor);
      expect(res.estimatedReductionKgCo2e).toBe(2340);
      expect(res.estimatedReductionTonnesCo2e).toBe(2.34);
      expect(res.disclaimer).toContain("do not constitute certified carbon credits");
    });
  });

  describe("calculateGreenScore", () => {
    const methodology: GreenScoreMethodology = {
      id: "gsm-v1.2",
      version: "v1.2-2026",
      name: "EcoSME Industrial Energy Readiness Methodology",
      is_active: true,
      is_externally_validated: false,
      weights: {
        efficiency_improvement: 25,
        consumption_stability: 20,
        data_completeness: 20,
        sustainability_performance: 20,
        monitoring_consistency: 15,
      },
      thresholds: {
        rating_a_min: 80,
        rating_b_min: 65,
        rating_c_min: 50,
      },
      updated_by: "EcoSME Admin",
      updated_at: "2026-10-01T00:00:00Z",
    };

    it("computes Provisional Green Score and assigns Grade A for strong metrics", () => {
      const score = calculateGreenScore({
        organizationId: "org-ikm-1",
        assessmentPeriod: "Oct 2026",
        savingsPercentage: 15.8,
        loadVarianceCoefficientPct: 8.0,
        dataCompletenessPct: 97.5,
        truePowerMeterRatioPct: 80,
        co2ReductionRatioPct: 15.8,
        activeMonitoringDaysRatioPct: 98,
        methodology,
      });
      expect(score.overall_score).toBeGreaterThanOrEqual(80);
      expect(score.rating).toBe("A");
      expect(score.is_provisional).toBe(true);
      expect(score.status_label).toBe("Provisional Green Score");
      expect(score.dimensions).toHaveLength(5);
    });
  });

  describe("evaluateTelemetryAnomalies", () => {
    it("detects over-power spikes and missing voltage/PF data transparently", () => {
      const anomalies = evaluateTelemetryAnomalies({
        ratedPowerKw: 15,
        rollingAverageKw: 11,
        nominalVoltageV: 380,
        measuredPowerKw: 18.5,
        measuredVoltageV: null,
        measuredPowerFactor: null,
        minutesSinceLastHeartbeat: 2,
        thresholds: {
          organization_id: "org-ikm-1",
          over_power_threshold_pct: 115,
          spike_deviation_pct: 25,
          min_power_factor: 0.85,
          heartbeat_timeout_minutes: 15,
          voltage_tolerance_pct: 10,
        },
      });
      expect(anomalies.some((a) => a.category === "ABNORMAL_POWER")).toBe(true);
      expect(anomalies.some((a) => a.category === "MISSING_SENSOR_DATA")).toBe(true);
    });
  });
});
