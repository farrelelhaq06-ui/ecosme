import { describe, expect, it } from "vitest";
import { createInitialSeedState } from "../db";
import {
  canAccessOrganizationData,
  getAuthorizedIkmOrganizationsForBank,
  hasRolePermission,
} from "../auth";

describe("EcoSME Server-Side RBAC, Organization Isolation & Consent Enforcement", () => {
  const db = createInitialSeedState();
  const ikmSinarUser = db.users.find((u) => u.id === "usr-ikm-budi")!;
  const ikmKaryaUser = db.users.find((u) => u.id === "usr-ikm-ratna")!;
  const bankUser = db.users.find((u) => u.id === "usr-bank-arief")!;
  const adminUser = db.users.find((u) => u.id === "usr-admin-nadia")!;

  it("enforces role permissions accurately", () => {
    expect(hasRolePermission(ikmSinarUser, ["IKM_OWNER"])).toBe(true);
    expect(hasRolePermission(ikmSinarUser, ["BANK_OFFICER", "ECOSME_ADMIN"])).toBe(false);
    expect(hasRolePermission(bankUser, ["BANK_OFFICER"])).toBe(true);
    expect(hasRolePermission(adminUser, ["ECOSME_ADMIN"])).toBe(true);
  });

  it("enforces strict organization isolation between IKM accounts", () => {
    const ownAccess = canAccessOrganizationData(ikmSinarUser, "org-ikm-sinar", db);
    expect(ownAccess.allowed).toBe(true);

    const crossOrgAccess = canAccessOrganizationData(ikmSinarUser, "org-ikm-karya", db);
    expect(crossOrgAccess.allowed).toBe(false);
    expect(crossOrgAccess.reason).toContain("Organization Isolation Violation");

    const crossOrgAccess2 = canAccessOrganizationData(ikmKaryaUser, "org-ikm-sinar", db);
    expect(crossOrgAccess2.allowed).toBe(false);
  });

  it("allows Bank Officer to view ONLY IKMs with ACTIVE data-sharing consent", () => {
    const consentedAccess = canAccessOrganizationData(bankUser, "org-ikm-sinar", db);
    expect(consentedAccess.allowed).toBe(true);
    expect(consentedAccess.consent?.status).toBe("ACTIVE");

    const revokedAccess = canAccessOrganizationData(bankUser, "org-ikm-pangan", db);
    expect(revokedAccess.allowed).toBe(false);
    expect(revokedAccess.reason).toContain("Consent Violation");
  });

  it("filters bank pipeline to strictly exclude non-consented or revoked IKMs", () => {
    const authorizedList = getAuthorizedIkmOrganizationsForBank("org-bank-nusantara", db);
    const orgIds = authorizedList.map((item) => item.organization.id);
    expect(orgIds).toContain("org-ikm-sinar");
    expect(orgIds).toContain("org-ikm-karya");
    expect(orgIds).not.toContain("org-ikm-pangan");
  });
});
