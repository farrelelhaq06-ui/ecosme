export function formatIdr(amount: number): string {
  if (!Number.isFinite(amount)) return "Rp0";
  return "Rp" + Math.round(amount).toLocaleString("id-ID");
}

export function formatNumber(val: number, decimals: number = 0): string {
  if (!Number.isFinite(val)) return "0";
  return val.toLocaleString("id-ID", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

export function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return "—";
  try {
    const dt = new Date(iso);
    return dt.toLocaleString("en-US", {
      year: "numeric",
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}
