import { cookies } from "next/headers";
import { EcoSMEDatabaseState, getDb } from "./db";
import { DataSharingConsent, Organization, User, UserRole } from "./types";

export const SESSION_COOKIE_NAME = "ecosme_session_user_id";

export interface SessionContext {
  user: User;
  organization: Organization;
}

export function resolveSessionFromUserId(
  userId: string | undefined,
  db?: EcoSMEDatabaseState
): SessionContext {
  const state = db ?? getDb();
  const user =
    state.users.find((u) => u.id === userId && u.active) ??
    state.users.find((u) => u.id === "usr-ikm-budi") ??
    state.users[0];

  const organization =
    state.organizations.find((o) => o.id === user.organization_id) ??
    state.organizations[0];

  return { user, organization };
}

export async function getServerSession(): Promise<SessionContext> {
  try {
    const cookieStore = await cookies();
    const userId = cookieStore.get(SESSION_COOKIE_NAME)?.value;
    return resolveSessionFromUserId(userId);
  } catch {
    return resolveSessionFromUserId("usr-ikm-budi");
  }
}

/**
 * Enforces server-side Role-Based Access Control (RBAC).
 */
export function hasRolePermission(user: User, allowedRoles: UserRole[]): boolean {
  if (!user || !user.active) return false;
  return allowedRoles.includes(user.role);
}

/**
 * Enforces strict organization-level data isolation and explicit bank consent.
 * - IKM_OWNER: Can only access their own organization_id.
 * - BANK_OFFICER: Can only access an IKM organization if an ACTIVE, non-revoked
 *   DataSharingConsent exists for that bank.
 * - ECOSME_ADMIN: Can access organization records for platform administration.
 */
export function canAccessOrganizationData(
  user: User,
  targetOrganizationId: string,
  db: EcoSMEDatabaseState
): { allowed: boolean; reason: string; consent?: DataSharingConsent } {
  if (!user || !user.active) {
    return { allowed: false, reason: "Inactive or unauthenticated user session." };
  }

  if (user.role === "ECOSME_ADMIN") {
    return { allowed: true, reason: "Authorized via EcoSME Administrator role." };
  }

  if (user.role === "IKM_OWNER") {
    if (user.organization_id === targetOrganizationId) {
      return { allowed: true, reason: "Authorized as member of target IKM organization." };
    }
    return {
      allowed: false,
      reason:
        "Organization Isolation Violation: IKM accounts cannot access another organization's confidential telemetry or financial records.",
    };
  }

  if (user.role === "BANK_OFFICER") {
    const activeConsent = db.data_sharing_consents.find(
      (c) =>
        c.organization_id === targetOrganizationId &&
        c.partner_bank_id === user.organization_id &&
        c.status === "ACTIVE"
    );

    if (!activeConsent) {
      return {
        allowed: false,
        reason:
          "Consent Violation: The target IKM has not granted active data-sharing consent to your financial institution (or consent has been revoked).",
      };
    }

    return {
      allowed: true,
      reason: `Authorized via explicit IKM consent (${activeConsent.id}).`,
      consent: activeConsent,
    };
  }

  return { allowed: false, reason: "Unrecognized role." };
}

/**
 * Returns only IKM organizations that have explicitly granted ACTIVE consent to the specified bank.
 */
export function getAuthorizedIkmOrganizationsForBank(
  bankOrganizationId: string,
  db: EcoSMEDatabaseState
): Array<{ organization: Organization; consent: DataSharingConsent }> {
  const activeConsents = db.data_sharing_consents.filter(
    (c) => c.partner_bank_id === bankOrganizationId && c.status === "ACTIVE"
  );

  const results: Array<{ organization: Organization; consent: DataSharingConsent }> = [];
  for (const consent of activeConsents) {
    const org = db.organizations.find(
      (o) => o.id === consent.organization_id && o.type === "IKM"
    );
    if (org) {
      results.push({ organization: org, consent });
    }
  }
  return results;
}
