"use client";

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import {
  Alert,
  AlertThresholdConfig,
  AuditLog,
  DataSharingConsent,
  Device,
  ElectricityTariff,
  EmissionFactor,
  EnergyBaseline,
  EnergyReading,
  FinancingApplication,
  GreenScore,
  GreenScoreMethodology,
  Machine,
  Organization,
  PlatformConfiguration,
  Report,
  SavingsRecord,
  Subscription,
  User,
} from "@/lib/types";

export interface ConsentedBankPipelineItem {
  organization: Organization;
  consent: DataSharingConsent;
  greenScore: GreenScore | null;
  application: FinancingApplication | null;
  machines: Machine[];
  savingsRecords: SavingsRecord[];
  reports: Report[];
}

export interface EcoSMEClientState {
  loading: boolean;
  error: string | null;
  session: {
    user: User;
    organization: Organization;
  };
  organization: Organization;
  machines: Machine[];
  devices: Device[];
  deviceCredentials: Array<{
    id: string;
    device_id: string;
    key_prefix: string;
    status: "ACTIVE" | "REVOKED";
    created_at: string;
    last_used_at: string | null;
  }>;
  readings: EnergyReading[];
  baselines: EnergyBaseline[];
  savingsRecords: SavingsRecord[];
  tariffs: ElectricityTariff[];
  emissionFactors: EmissionFactor[];
  greenScore: GreenScore;
  methodology: GreenScoreMethodology;
  consents: DataSharingConsent[];
  applications: FinancingApplication[];
  reports: Report[];
  alerts: Alert[];
  alertThresholds: AlertThresholdConfig;
  subscription: Subscription;
  platformConfig: PlatformConfiguration;
  consentedBankPipeline: ConsentedBankPipelineItem[];
  adminData: {
    allOrganizations: Organization[];
    allUsers: User[];
    allDevices: Device[];
    allGreenScores: GreenScore[];
    allConsents: DataSharingConsent[];
    allApplications: FinancingApplication[];
    auditLogs: AuditLog[];
  } | null;
  refreshState: () => Promise<void>;
  mutateState: (action: string, payload?: Record<string, unknown>) => Promise<{ ok: boolean; data?: Record<string, unknown>; error?: string }>;
  switchUserRole: (userId: string) => Promise<void>;
}

const EcoSMEContext = createContext<EcoSMEClientState | null>(null);

export function EcoSMEProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<Omit<
    EcoSMEClientState,
    "loading" | "error" | "refreshState" | "mutateState" | "switchUserRole"
  > | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchState = useCallback(async () => {
    try {
      setError(null);
      const res = await fetch("/api/state", { cache: "no-store" });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || "Failed to load platform state");
      }
      const data = await res.json();
      setState(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unexpected error");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchState();
  }, [fetchState]);

  const mutateState = useCallback(
    async (action: string, payload: Record<string, unknown> = {}) => {
      try {
        const res = await fetch("/api/state", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action, payload }),
        });
        const data = await res.json();
        if (!res.ok) {
          return { ok: false, error: data.error || "Operation failed" };
        }
        await fetchState();
        return { ok: true, data };
      } catch (err) {
        return {
          ok: false,
          error: err instanceof Error ? err.message : "Network error",
        };
      }
    },
    [fetchState]
  );

  const switchUserRole = useCallback(
    async (userId: string) => {
      setLoading(true);
      await fetch("/api/auth/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId }),
      });
      await fetchState();
    },
    [fetchState]
  );

  if (!state) {
    return (
      <div className="min-h-screen bg-[#F5F8F6] flex items-center justify-center p-6">
        <div className="ecosme-card p-8 max-w-md w-full text-center space-y-3">
          <div className="h-10 w-10 rounded-lg bg-[#123B2A] text-white flex items-center justify-center mx-auto font-bold">
            E
          </div>
          <p className="text-sm font-semibold text-[#123B2A]">
            Loading EcoSME Enterprise Telemetry &amp; Governance Context...
          </p>
          <p className="text-xs text-slate-500">
            Verifying organization-isolated session and deterministic fixtures.
          </p>
        </div>
      </div>
    );
  }

  return (
    <EcoSMEContext.Provider
      value={{
        ...state,
        loading,
        error,
        refreshState: fetchState,
        mutateState,
        switchUserRole,
      }}
    >
      {children}
    </EcoSMEContext.Provider>
  );
}

export function useEcoSME(): EcoSMEClientState {
  const ctx = useContext(EcoSMEContext);
  if (!ctx) {
    throw new Error("useEcoSME must be used within an EcoSMEProvider");
  }
  return ctx;
}
