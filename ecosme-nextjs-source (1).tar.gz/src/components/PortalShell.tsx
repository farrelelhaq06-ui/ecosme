"use client";

import React, { useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  Activity,
  AlertTriangle,
  Award,
  BarChart3,
  Building2,
  Cpu,
  FileSpreadsheet,
  FileText,
  Gauge,
  Landmark,
  LayoutDashboard,
  Leaf,
  Lock,
  PiggyBank,
  Radio,
  RotateCcw,
  Settings,
  ShieldAlert,
  ShieldCheck,
  Sliders,
  UserCircle2,
  Users,
} from "lucide-react";
import { useEcoSME } from "./EcoSMEProvider";
import { LandingLoginSidebar } from "./LandingLoginSidebar";

interface NavItem {
  href: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
}

const ikmNavItems: NavItem[] = [
  { href: "/app/overview", label: "Overview", icon: LayoutDashboard },
  { href: "/app/energy", label: "Energy Monitoring", icon: Gauge },
  { href: "/app/machines", label: "Machines", icon: Cpu },
  { href: "/app/alerts", label: "Alerts & Anomalies", icon: AlertTriangle },
  { href: "/app/savings", label: "Energy Savings", icon: PiggyBank },
  { href: "/app/sustainability", label: "Sustainability & CO₂", icon: Leaf },
  { href: "/app/green-score", label: "Green Score Card", icon: Award },
  { href: "/app/financing", label: "Green Finance Gateway", icon: Landmark },
  { href: "/app/reports", label: "PDF Reports", icon: FileText },
  { href: "/app/devices", label: "IoT Devices", icon: Radio },
  { href: "/app/settings", label: "Settings & Tariffs", icon: Settings },
];

const bankNavItems: NavItem[] = [
  { href: "/bank/overview", label: "Bank Overview", icon: LayoutDashboard },
  { href: "/bank/pipeline", label: "Authorized IKM Pipeline", icon: Building2 },
  { href: "/bank/applications", label: "Financing Applications", icon: Landmark },
  { href: "/bank/reports", label: "Consented Reports", icon: FileSpreadsheet },
];

const adminNavItems: NavItem[] = [
  { href: "/admin/overview", label: "Admin Overview", icon: LayoutDashboard },
  { href: "/admin/users", label: "Users & Organizations", icon: Users },
  { href: "/admin/devices", label: "IoT Fleet Monitor", icon: Radio },
  { href: "/admin/data-quality", label: "Data Quality Audit", icon: BarChart3 },
  { href: "/admin/green-score", label: "Methodology & Config", icon: Sliders },
  { href: "/admin/audit-logs", label: "System Audit Logs", icon: ShieldCheck },
];

export function PortalShell({
  portalType,
  title,
  subtitle,
  children,
}: {
  portalType: "IKM" | "BANK" | "ADMIN";
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const { session, alerts, switchUserRole, mutateState } = useEcoSME();
  const [switchingRole, setSwitchingRole] = useState(false);
  const [rightProfileOpen, setRightProfileOpen] = useState(false);

  const activeAlertsCount = alerts.filter((a) => a.status === "ACTIVE").length;

  const navList =
    portalType === "IKM"
      ? ikmNavItems
      : portalType === "BANK"
      ? bankNavItems
      : adminNavItems;

  const handlePortalRoleSwitch = async (
    targetUserId: string,
    targetRoute?: string
  ) => {
    setSwitchingRole(true);
    await switchUserRole(targetUserId);
    setSwitchingRole(false);
    if (targetRoute) {
      router.push(targetRoute);
    }
  };

  // Server-enforced RBAC banner check when browsing a portal with a mismatched role
  const isRoleAuthorized =
    (portalType === "IKM" &&
      (session.user.role === "IKM_OWNER" ||
        session.user.role === "ECOSME_ADMIN")) ||
    (portalType === "BANK" &&
      (session.user.role === "BANK_OFFICER" ||
        session.user.role === "ECOSME_ADMIN")) ||
    (portalType === "ADMIN" && session.user.role === "ECOSME_ADMIN");

  return (
    <div className="min-h-screen flex flex-col bg-[#F5F8F6]">
      {/* Top Enterprise Governance Bar */}
      <header className="sticky top-0 z-30 bg-[#123B2A] text-white border-b border-emerald-900">
        <div className="px-4 sm:px-6 h-14 flex items-center justify-between gap-3">
          <div className="flex items-center gap-4">
            <Link href="/" className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-[#16A36A] flex items-center justify-center text-white font-bold">
                <Activity className="h-4 w-4" />
              </div>
              <div>
                <span className="font-bold tracking-tight text-base">EcoSME</span>
                <span className="hidden sm:inline-block ml-2 rounded bg-emerald-900/90 border border-emerald-600/40 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-emerald-200">
                  {portalType === "IKM"
                    ? "IKM Factory Workspace"
                    : portalType === "BANK"
                    ? "Partner Bank Underwriting Portal"
                    : "Platform Admin Console"}
                </span>
              </div>
            </Link>

            {/* Portal Switcher Pills */}
            <div className="hidden lg:flex items-center bg-[#0D2B1E] rounded-lg p-0.5 border border-emerald-800/60 text-xs">
              <button
                type="button"
                onClick={() =>
                  handlePortalRoleSwitch("usr-ikm-budi", "/app/overview")
                }
                className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                  portalType === "IKM"
                    ? "bg-[#16A36A] text-white"
                    : "text-emerald-200 hover:text-white"
                }`}
              >
                1. IKM Dashboard
              </button>
              <button
                type="button"
                onClick={() =>
                  handlePortalRoleSwitch("usr-bank-arief", "/bank/overview")
                }
                className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                  portalType === "BANK"
                    ? "bg-[#16A36A] text-white"
                    : "text-emerald-200 hover:text-white"
                }`}
              >
                2. Bank Portal
              </button>
              <button
                type="button"
                onClick={() =>
                  handlePortalRoleSwitch("usr-admin-nadia", "/admin/overview")
                }
                className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                  portalType === "ADMIN"
                    ? "bg-[#16A36A] text-white"
                    : "text-emerald-200 hover:text-white"
                }`}
              >
                3. Admin Portal
              </button>
            </div>
          </div>

          {/* Right: Active Role & Top-Right Personal/Company Profile Trigger */}
          <div className="flex items-center gap-2.5">
            <div className="hidden xl:flex items-center gap-1.5">
              <label htmlFor="role-switcher-select" className="sr-only">
                Active Role Session
              </label>
              <select
                id="role-switcher-select"
                disabled={switchingRole}
                value={session.user.id}
                onChange={(e) => handlePortalRoleSwitch(e.target.value)}
                className="rounded-lg bg-[#0D2B1E] border border-emerald-700 px-2.5 py-1.5 text-xs font-medium text-white focus:outline-none focus:ring-2 focus:ring-[#16A36A]"
              >
                <option value="usr-ikm-budi">
                  Role: IKM Owner — Ir. Budi Santoso (PT Sinar Tekstil)
                </option>
                <option value="usr-ikm-ratna">
                  Role: IKM Owner — Ratna Dewi (CV Karya Logam)
                </option>
                <option value="usr-bank-arief">
                  Role: Partner Bank — Arief Rahman (Bank Nusantara Hijau)
                </option>
                <option value="usr-admin-nadia">
                  Role: EcoSME Admin — Nadia Putri (Platform Governance)
                </option>
              </select>
            </div>

            <button
              type="button"
              onClick={() => setRightProfileOpen(!rightProfileOpen)}
              className="inline-flex items-center gap-2 rounded-lg bg-[#16A36A] hover:bg-emerald-500 text-white px-3 py-1.5 text-xs font-bold shadow-xs transition-colors"
            >
              <UserCircle2 className="h-4 w-4" />
              <span className="hidden sm:inline">
                {session.user.name} • {session.organization.name.split(" (")[0]}
              </span>
              <span className="rounded bg-[#123B2A] px-1.5 py-0.5 text-[10px] font-bold">
                Data Diri &amp; Perusahaan ☰
              </span>
            </button>

            <button
              type="button"
              onClick={() => mutateState("RESET_DEMO_DATA")}
              title="Reset deterministic demo dataset to initial seed state"
              className="hidden md:inline-flex items-center gap-1 rounded-lg bg-[#0D2B1E] hover:bg-emerald-950 border border-emerald-700/80 px-2.5 py-1.5 text-xs text-emerald-200"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Reset
            </button>
          </div>
        </div>
      </header>

      {/* Right-Hand Slide-Over Sidebar for Personal & Company Data */}
      {rightProfileOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/40 backdrop-blur-xs">
          <div className="relative h-full w-full max-w-md bg-white shadow-2xl overflow-y-auto flex flex-col">
            <div className="sticky top-0 z-10 flex items-center justify-between bg-[#123B2A] text-white px-4 py-3 border-b border-emerald-800">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-300">
                Sidebar Data Personal Diri &amp; Perusahaan
              </span>
              <button
                type="button"
                onClick={() => setRightProfileOpen(false)}
                className="rounded-lg bg-white/10 hover:bg-white/20 px-2.5 py-1 text-xs font-bold text-white"
              >
                Tutup ✕
              </button>
            </div>
            <LandingLoginSidebar />
          </div>
        </div>
      )}

      <div className="flex-1 flex flex-col lg:flex-row">
        {/* Sidebar Navigation */}
        <aside className="w-full lg:w-64 shrink-0 bg-white border-b lg:border-b-0 lg:border-r border-[#DDE5DF] flex flex-col justify-between">
          <div className="p-4">
            <div className="rounded-lg bg-[#F5F8F6] border border-[#DDE5DF] p-3 mb-4">
              <p className="text-[10px] font-bold uppercase tracking-wider text-[#16A36A]">
                Active Organization Context
              </p>
              <p className="text-xs font-bold text-[#123B2A] truncate mt-0.5">
                {session.organization.name}
              </p>
              <p className="text-[11px] text-slate-600 truncate">
                {session.user.name} •{" "}
                <span className="font-semibold">{session.user.role}</span>
              </p>
            </div>

            <nav className="flex lg:flex-col gap-1 overflow-x-auto pb-2 lg:pb-0">
              {navList.map((item) => {
                const Icon = item.icon;
                const active =
                  pathname === item.href ||
                  (item.href !== "/app/overview" &&
                    item.href !== "/bank/overview" &&
                    item.href !== "/admin/overview" &&
                    pathname.startsWith(item.href));
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`flex items-center justify-between gap-2.5 px-3 py-2 rounded-lg text-xs sm:text-sm font-medium whitespace-nowrap transition-colors ${
                      active
                        ? "bg-[#123B2A] text-white font-semibold shadow-xs"
                        : "text-slate-700 hover:bg-[#E8F7F0] hover:text-[#123B2A]"
                    }`}
                  >
                    <span className="flex items-center gap-2.5">
                      <Icon
                        className={`h-4 w-4 shrink-0 ${
                          active ? "text-[#16A36A]" : "text-slate-500"
                        }`}
                      />
                      <span>{item.label}</span>
                    </span>
                    {item.href === "/app/alerts" && activeAlertsCount > 0 && (
                      <span
                        className={`rounded-full px-1.5 py-0.5 text-[10px] font-bold ${
                          active
                            ? "bg-amber-400 text-slate-950"
                            : "bg-amber-100 text-amber-900"
                        }`}
                      >
                        {activeAlertsCount}
                      </span>
                    )}
                  </Link>
                );
              })}
            </nav>
          </div>

          <div className="hidden lg:block p-4 border-t border-[#DDE5DF] space-y-2 text-[11px] text-slate-500">
            <div className="flex items-center gap-1.5 font-semibold text-[#123B2A]">
              <ShieldAlert className="h-3.5 w-3.5 text-[#16A36A]" />
              <span>Data Isolation &amp; Consent</span>
            </div>
            <p className="leading-relaxed">
              Organization data is isolated on the server. Partner banks can only view IKM profiles with an{" "}
              <strong className="text-slate-700">ACTIVE</strong> data-sharing consent.
            </p>
            <Link
              href="/"
              className="inline-block text-[#16A36A] font-semibold hover:underline pt-1"
            >
              ← Return to Public Website
            </Link>
          </div>
        </aside>

        {/* Main Workspace Content */}
        <main className="flex-1 min-w-0 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
          {/* Page Header */}
          <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-[#DDE5DF]">
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-[#123B2A] tracking-tight">
                {title}
              </h1>
              {subtitle && (
                <p className="text-sm text-[#4B5563] mt-1">{subtitle}</p>
              )}
            </div>
            <div className="flex flex-wrap items-center gap-2 text-xs">
              <span className="inline-flex items-center gap-1.5 rounded-lg bg-white border border-[#DDE5DF] px-3 py-1.5 font-medium text-slate-700">
                <span className="h-2 w-2 rounded-full bg-[#16A36A]" />
                Org: <strong>{session.organization.name}</strong>
              </span>
            </div>
          </div>

          {!isRoleAuthorized ? (
            <div className="ecosme-card p-8 border-red-300 bg-red-50/40 max-w-2xl mx-auto my-8 space-y-4">
              <div className="flex items-center gap-3 text-red-800">
                <Lock className="h-6 w-6 shrink-0" />
                <h2 className="text-lg font-bold">
                  Server-Side Role-Based Access Control (RBAC) Restriction
                </h2>
              </div>
              <p className="text-sm text-slate-700 leading-relaxed">
                Your current active session (
                <strong>{session.user.name}</strong> — Role:{" "}
                <code className="bg-white px-1.5 py-0.5 rounded border">
                  {session.user.role}
                </code>
                ) is not authorized to access the{" "}
                <strong>{portalType} Portal</strong>. EcoSME enforces strict role
                and organization boundaries on the server rather than merely hiding
                frontend menu items.
              </p>
              <div className="pt-2 flex flex-wrap gap-3">
                {portalType === "IKM" && (
                  <button
                    type="button"
                    onClick={() => handlePortalRoleSwitch("usr-ikm-budi")}
                    className="px-4 py-2 rounded-lg bg-[#123B2A] text-white text-xs font-semibold hover:bg-[#0D2B1E]"
                  >
                    Switch to IKM Owner Role (Ir. Budi Santoso)
                  </button>
                )}
                {portalType === "BANK" && (
                  <button
                    type="button"
                    onClick={() => handlePortalRoleSwitch("usr-bank-arief")}
                    className="px-4 py-2 rounded-lg bg-[#14243A] text-white text-xs font-semibold hover:bg-slate-800"
                  >
                    Switch to Partner Bank Officer Role (Arief Rahman, CFA)
                  </button>
                )}
                {portalType === "ADMIN" && (
                  <button
                    type="button"
                    onClick={() => handlePortalRoleSwitch("usr-admin-nadia")}
                    className="px-4 py-2 rounded-lg bg-[#123B2A] text-white text-xs font-semibold hover:bg-[#0D2B1E]"
                  >
                    Switch to EcoSME Administrator Role (Nadia Putri, M.T.)
                  </button>
                )}
              </div>
            </div>
          ) : (
            children
          )}
        </main>
      </div>
    </div>
  );
}
