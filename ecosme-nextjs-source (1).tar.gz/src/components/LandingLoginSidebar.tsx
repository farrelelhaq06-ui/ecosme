"use client";

import React, { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  ArrowRight,
  Building2,
  CheckCircle2,
  Factory,
  KeyRound,
  Lock,
  Save,
  ShieldCheck,
  UserCheck,
  UserCircle2,
} from "lucide-react";
import { useEcoSME } from "./EcoSMEProvider";

export function LandingLoginSidebar() {
  const router = useRouter();
  const { session, switchUserRole, mutateState } = useEcoSME();

  const [activeTab, setActiveTab] = useState<"personal" | "company" | "login">(
    "personal"
  );
  const [selectedUserId, setSelectedUserId] = useState(session.user.id);
  const [submitting, setSubmitting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  // Personal Data Fields
  const [personalName, setPersonalName] = useState(session.user.name);
  const [personalTitle, setPersonalTitle] = useState(session.user.title);
  const [personalEmail, setPersonalEmail] = useState(session.user.email);
  const [personalPhone, setPersonalPhone] = useState("+62 812-2345-6789");
  const [personalNik, setPersonalNik] = useState("3273-0819-0478-0001");

  // Company Data Fields
  const [companyName, setCompanyName] = useState(session.organization.name);
  const [industryCategory, setIndustryCategory] = useState(
    session.organization.industry_category
  );
  const [taxIdNpwp, setTaxIdNpwp] = useState(session.organization.tax_id_npwp);
  const [businessLicenseNib, setBusinessLicenseNib] = useState(
    session.organization.business_license_nib
  );
  const [address, setAddress] = useState(session.organization.address);
  const [plnTariffClass, setPlnTariffClass] = useState(
    session.organization.pln_tariff_class
  );
  const [installedCapacityKva, setInstalledCapacityKva] = useState(
    String(session.organization.installed_capacity_kva)
  );

  useEffect(() => {
    setSelectedUserId(session.user.id);
    setPersonalName(session.user.name);
    setPersonalTitle(session.user.title);
    setPersonalEmail(session.user.email);
    setCompanyName(session.organization.name);
    setIndustryCategory(session.organization.industry_category);
    setTaxIdNpwp(session.organization.tax_id_npwp);
    setBusinessLicenseNib(session.organization.business_license_nib);
    setAddress(session.organization.address);
    setPlnTariffClass(session.organization.pln_tariff_class);
    setInstalledCapacityKva(String(session.organization.installed_capacity_kva));
  }, [session]);

  const demoAccounts = [
    {
      id: "usr-ikm-budi",
      roleLabel: "IKM / Factory Owner",
      name: "Ir. Budi Santoso",
      email: "budi.santoso@sinartekstil-demo.co.id",
      org: "PT Sinar Tekstil Mandiri (DEMO)",
      metrics: "41.820 kWh • Green Score 83 (Grade A)",
      targetRoute: "/app/overview",
      icon: Factory,
    },
    {
      id: "usr-ikm-ratna",
      roleLabel: "IKM / Factory Owner",
      name: "Ratna Dewi, S.T.",
      email: "ratna.dewi@karyalogam-demo.co.id",
      org: "CV Karya Logam Presisi (DEMO)",
      metrics: "31.200 kWh • Green Score 74 (Grade B)",
      targetRoute: "/app/overview",
      icon: Factory,
    },
    {
      id: "usr-bank-arief",
      roleLabel: "Bank / Financial Institution",
      name: "Arief Rahman, CFA",
      email: "arief.rahman@banknusantara-demo.co.id",
      org: "Bank Nusantara Hijau (DEMO)",
      metrics: "2 Consented IKM • Pipeline Rp770 Jt",
      targetRoute: "/bank/overview",
      icon: Building2,
    },
    {
      id: "usr-admin-nadia",
      roleLabel: "EcoSME Administrator",
      name: "Nadia Putri, M.T.",
      email: "nadia.putri@ecosme.id",
      org: "EcoSME Platform Governance",
      metrics: "6 IoT Gateways • Methodology v1.2",
      targetRoute: "/admin/overview",
      icon: ShieldCheck,
    },
  ];

  const handlePresetSwitch = async (userId: string) => {
    setSelectedUserId(userId);
    setSubmitting(true);
    await switchUserRole(userId);
    setSubmitting(false);
    setStatusMessage("Profil akun & data perusahaan berhasil dimuat.");
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setStatusMessage(null);
    await mutateState("UPDATE_PERSONAL_COMPANY_PROFILE", {
      personal_name: personalName,
      personal_title: personalTitle,
      personal_email: personalEmail,
      company_name: companyName,
      industry_category: industryCategory,
      tax_id_npwp: taxIdNpwp,
      business_license_nib: businessLicenseNib,
      address,
      pln_tariff_class: plnTariffClass,
      installed_capacity_kva: Number(installedCapacityKva),
    });
    setSubmitting(false);
    setStatusMessage(
      `Data Diri (${personalName}) & Perusahaan (${companyName}) berhasil disimpan!`
    );
  };

  const handleOpenDashboard = () => {
    const found =
      demoAccounts.find((a) => a.id === selectedUserId) ?? demoAccounts[0];
    router.push(found.targetRoute);
  };

  return (
    <aside
      id="personal-company-sidebar"
      className="w-full lg:w-96 shrink-0 bg-white border-b lg:border-b-0 lg:border-r border-[#DDE5DF] flex flex-col justify-between"
    >
      <div className="p-5 space-y-4">
        {/* Sidebar Header */}
        <div className="rounded-xl bg-[#123B2A] text-white p-4 space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-emerald-300">
              <UserCircle2 className="h-3.5 w-3.5" />
              Sidebar Profil &amp; Login
            </span>
            <span className="rounded bg-[#16A36A] px-2 py-0.5 text-[10px] font-bold text-white">
              RBAC Aktif
            </span>
          </div>
          <h2 className="text-base font-bold leading-snug">
            Data Personal Diri &amp; Perusahaan
          </h2>
          <p className="text-xs text-emerald-100/90 leading-relaxed">
            Kelola identitas personal penanggung jawab, profil legal perusahaan/pabrik IKM, serta akses portal.
          </p>
        </div>

        {/* Active Profile Card */}
        <div className="rounded-lg bg-[#E8F7F0] border border-[#16A36A]/40 p-3 text-xs space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="font-bold text-[#123B2A] flex items-center gap-1.5">
              <UserCheck className="h-3.5 w-3.5 text-[#16A36A]" />
              {session.user.name}
            </span>
            <span className="rounded bg-[#123B2A] text-white px-1.5 py-0.5 text-[10px] font-bold">
              {session.user.role}
            </span>
          </div>
          <p className="text-[11px] text-slate-700 font-semibold">
            {session.user.title} — {session.organization.name}
          </p>
          <p className="text-[11px] text-emerald-900">
            Tarif PLN {session.organization.pln_tariff_class} •{" "}
            {session.organization.installed_capacity_kva} kVA
          </p>
        </div>

        {/* Preset Selector */}
        <div className="text-xs">
          <label
            htmlFor="sidebar-preset-select"
            className="block font-bold text-[#123B2A] mb-1"
          >
            Pilih Akun Demo (Otomatis Isi Data Diri &amp; Perusahaan)
          </label>
          <select
            id="sidebar-preset-select"
            value={selectedUserId}
            disabled={submitting}
            onChange={(e) => handlePresetSwitch(e.target.value)}
            className="w-full rounded-lg border border-slate-300 bg-[#F5F8F6] px-3 py-2 font-semibold text-[#123B2A] focus:outline-none focus:ring-2 focus:ring-[#16A36A]"
          >
            {demoAccounts.map((acc) => (
              <option key={acc.id} value={acc.id}>
                {acc.name} — {acc.org}
              </option>
            ))}
          </select>
        </div>

        {/* Tabs: 1. Data Personal Diri | 2. Data Perusahaan | 3. Akses Cepat */}
        <div className="grid grid-cols-3 gap-1 rounded-lg bg-[#F5F8F6] p-1 border border-[#DDE5DF] text-xs">
          <button
            type="button"
            onClick={() => setActiveTab("personal")}
            className={`py-1.5 px-2 rounded-md font-bold transition-colors ${
              activeTab === "personal"
                ? "bg-[#123B2A] text-white"
                : "text-slate-700 hover:bg-white"
            }`}
          >
            1. Data Diri
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("company")}
            className={`py-1.5 px-2 rounded-md font-bold transition-colors ${
              activeTab === "company"
                ? "bg-[#123B2A] text-white"
                : "text-slate-700 hover:bg-white"
            }`}
          >
            2. Perusahaan
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("login")}
            className={`py-1.5 px-2 rounded-md font-bold transition-colors ${
              activeTab === "login"
                ? "bg-[#123B2A] text-white"
                : "text-slate-700 hover:bg-white"
            }`}
          >
            3. Akun Demo
          </button>
        </div>

        {activeTab === "personal" && (
          <form onSubmit={handleSaveProfile} className="space-y-2.5 text-xs">
            <div className="font-bold text-[#123B2A] uppercase tracking-wider text-[11px] border-b border-slate-200 pb-1">
              Identitas Personal Penanggung Jawab
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Nama Lengkap Personal
              </label>
              <input
                type="text"
                required
                value={personalName}
                onChange={(e) => setPersonalName(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-1.5 font-semibold text-slate-900"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Jabatan / Posisi di Perusahaan
              </label>
              <input
                type="text"
                required
                value={personalTitle}
                onChange={(e) => setPersonalTitle(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-slate-900"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  NIK / ID Pegawai
                </label>
                <input
                  type="text"
                  value={personalNik}
                  onChange={(e) => setPersonalNik(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 font-mono text-[11px] text-slate-900"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  No. WhatsApp / HP
                </label>
                <input
                  type="text"
                  value={personalPhone}
                  onChange={(e) => setPersonalPhone(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 font-mono text-[11px] text-slate-900"
                />
              </div>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Email Kerja Personal
              </label>
              <input
                type="email"
                required
                value={personalEmail}
                onChange={(e) => setPersonalEmail(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-1.5 font-mono text-[11px] text-slate-900"
              />
            </div>
            <div className="pt-1 flex flex-col gap-2">
              <button
                type="submit"
                disabled={submitting}
                className="w-full inline-flex items-center justify-center gap-1.5 rounded-lg bg-[#16A36A] hover:bg-emerald-600 text-white py-2 text-xs font-bold transition-colors"
              >
                <Save className="h-3.5 w-3.5" />
                Simpan Data Personal &amp; Perusahaan
              </button>
              <button
                type="button"
                onClick={handleOpenDashboard}
                className="w-full inline-flex items-center justify-center gap-1.5 rounded-lg bg-[#123B2A] hover:bg-[#0D2B1E] text-white py-2 text-xs font-bold transition-colors"
              >
                Buka Dashboard Sesuai Peran
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </form>
        )}

        {activeTab === "company" && (
          <form onSubmit={handleSaveProfile} className="space-y-2.5 text-xs">
            <div className="font-bold text-[#123B2A] uppercase tracking-wider text-[11px] border-b border-slate-200 pb-1">
              Profil Legal Perusahaan &amp; Parameter PLN
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Nama Perusahaan / Entitas IKM
              </label>
              <input
                type="text"
                required
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-1.5 font-semibold text-slate-900"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Sektor Industri (KBLI)
              </label>
              <input
                type="text"
                required
                value={industryCategory}
                onChange={(e) => setIndustryCategory(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-slate-900"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  NPWP Perusahaan
                </label>
                <input
                  type="text"
                  value={taxIdNpwp}
                  onChange={(e) => setTaxIdNpwp(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 font-mono text-[11px] text-slate-900"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nomor Induk Berusaha (NIB)
                </label>
                <input
                  type="text"
                  value={businessLicenseNib}
                  onChange={(e) => setBusinessLicenseNib(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 font-mono text-[11px] text-slate-900"
                />
              </div>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Lokasi Pabrik / Alamat Operasional
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-slate-900"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Golongan Tarif PLN
                </label>
                <input
                  type="text"
                  value={plnTariffClass}
                  onChange={(e) => setPlnTariffClass(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 font-semibold text-slate-900"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Daya Terpasang (kVA)
                </label>
                <input
                  type="number"
                  value={installedCapacityKva}
                  onChange={(e) => setInstalledCapacityKva(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 font-mono text-slate-900"
                />
              </div>
            </div>
            <div className="pt-1 flex flex-col gap-2">
              <button
                type="submit"
                disabled={submitting}
                className="w-full inline-flex items-center justify-center gap-1.5 rounded-lg bg-[#16A36A] hover:bg-emerald-600 text-white py-2 text-xs font-bold transition-colors"
              >
                <Save className="h-3.5 w-3.5" />
                Simpan Profil Perusahaan
              </button>
            </div>
          </form>
        )}

        {activeTab === "login" && (
          <div className="space-y-2 text-xs">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block">
              Pilih Akun Peran &amp; Buka Portal:
            </span>
            {demoAccounts.map((acc) => {
              const Icon = acc.icon;
              const isSelected = selectedUserId === acc.id;
              return (
                <div
                  key={acc.id}
                  onClick={() => handlePresetSwitch(acc.id)}
                  className={`cursor-pointer rounded-lg border p-3 transition-all space-y-1.5 ${
                    isSelected
                      ? "border-[#16A36A] bg-[#E8F7F0]/60"
                      : "border-[#DDE5DF] bg-[#F5F8F6] hover:bg-slate-100"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[#123B2A] flex items-center gap-1.5">
                      <Icon className="h-3.5 w-3.5 text-[#16A36A]" />
                      {acc.name}
                    </span>
                    <span className="text-[10px] font-bold uppercase px-1.5 py-0.5 rounded bg-white border border-slate-200 text-slate-700">
                      {acc.roleLabel.split(" ")[0]}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-700 font-medium">
                    {acc.org}
                  </p>
                  <div className="flex items-center justify-between pt-1">
                    <span className="text-[10px] font-semibold text-emerald-800">
                      {acc.metrics}
                    </span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handlePresetSwitch(acc.id).then(() =>
                          router.push(acc.targetRoute)
                        );
                      }}
                      className="inline-flex items-center gap-1 rounded bg-[#123B2A] hover:bg-[#0D2B1E] text-white px-2.5 py-1 text-[10px] font-bold"
                    >
                      Buka Portal →
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {statusMessage && (
          <div className="rounded-lg bg-emerald-50 border border-emerald-300 p-2.5 text-xs text-emerald-950 font-medium flex items-center gap-1.5">
            <CheckCircle2 className="h-4 w-4 text-[#16A36A] shrink-0" />
            <span>{statusMessage}</span>
          </div>
        )}
      </div>

      {/* Bottom Registration Link */}
      <div className="p-4 border-t border-[#DDE5DF] bg-[#F5F8F6] text-xs flex items-center justify-between">
        <span className="text-slate-600">Pabrik IKM Baru?</span>
        <Link
          href="/register"
          className="font-bold text-[#123B2A] hover:text-[#16A36A] underline"
        >
          Registrasi IKM →
        </Link>
      </div>
    </aside>
  );
}
