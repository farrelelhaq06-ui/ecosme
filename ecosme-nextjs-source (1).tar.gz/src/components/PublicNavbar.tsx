"use client";

import React, { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Activity,
  Building2,
  ShieldCheck,
  Menu,
  X,
  ArrowRight,
  UserCircle2,
} from "lucide-react";
import { useEcoSME } from "./EcoSMEProvider";
import { LandingLoginSidebar } from "./LandingLoginSidebar";

const navItems = [
  { href: "/", label: "Overview" },
  { href: "/solutions", label: "Solutions" },
  { href: "/how-it-works", label: "How It Works" },
  { href: "/pricing", label: "Pricing" },
  { href: "/about", label: "About EcoSME" },
];

export function PublicNavbar() {
  const pathname = usePathname();
  const { session } = useEcoSME();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [rightProfileOpen, setRightProfileOpen] = useState(false);

  return (
    <>
      <header className="sticky top-0 z-40 border-b border-[#DDE5DF] bg-white/95 backdrop-blur">
        {/* Top Demo & Positioning Ribbon (Dark Green #123B2A with Top-Right Personal/Company Sidebar Trigger) */}
        <div className="bg-[#123B2A] text-white text-xs py-1.5 px-4">
          <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="inline-block rounded bg-[#16A36A] px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-white">
                DEMO DATA MODE
              </span>
              <span className="text-emerald-100 hidden sm:inline">
                Digital Energy Efficiency &amp; Green Finance Readiness Platform for SMEs
              </span>
            </div>
            <div className="flex items-center gap-3 text-emerald-100 font-medium">
              <Link
                href="/app/overview"
                className="hidden md:inline hover:text-white underline underline-offset-2"
              >
                1. IKM Dashboard
              </Link>
              <Link
                href="/bank/overview"
                className="hidden md:inline hover:text-white underline underline-offset-2"
              >
                2. Bank Portal
              </Link>
              <Link
                href="/admin/overview"
                className="hidden md:inline hover:text-white underline underline-offset-2"
              >
                3. Admin Portal
              </Link>
              <button
                type="button"
                onClick={() => setRightProfileOpen(!rightProfileOpen)}
                className="inline-flex items-center gap-2 rounded-lg bg-[#16A36A] hover:bg-emerald-500 text-white px-2.5 py-1 text-xs font-bold shadow-xs transition-colors"
              >
                <UserCircle2 className="h-3.5 w-3.5" />
                <span>
                  {session.user.name} • {session.organization.name.split(" (")[0]}
                </span>
                <span className="rounded bg-[#123B2A] px-1.5 py-0.5 text-[10px] font-bold">
                  Data Diri &amp; Perusahaan ☰
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Main Nav */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5 group">
            <div className="h-9 w-9 rounded-lg bg-[#123B2A] flex items-center justify-center text-white shadow-xs">
              <Activity className="h-5 w-5 text-[#16A36A]" />
            </div>
            <div>
              <span className="text-lg font-bold tracking-tight text-[#123B2A]">
                EcoSME
              </span>
              <span className="block text-[10px] font-medium uppercase tracking-widest text-[#4B5563] -mt-1">
                Industrial Energy &amp; Green Finance
              </span>
            </div>
          </Link>

          <nav className="hidden md:flex items-center gap-1">
            {navItems.map((item) => {
              const active = pathname === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${
                    active
                      ? "bg-[#E8F7F0] text-[#123B2A] font-semibold"
                      : "text-[#4B5563] hover:text-[#123B2A] hover:bg-slate-50"
                  }`}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="hidden md:flex items-center gap-3">
            <button
              type="button"
              onClick={() => setRightProfileOpen(true)}
              className="px-3.5 py-2 rounded-lg text-sm font-semibold text-[#123B2A] bg-[#E8F7F0] hover:bg-emerald-100 transition-colors"
            >
              Profil Diri &amp; Perusahaan
            </button>
            <Link
              href="/app/overview"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold bg-[#123B2A] text-white hover:bg-[#0D2B1E] transition-colors shadow-xs"
            >
              Explore Platform
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          <button
            type="button"
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden p-2 rounded-lg text-slate-700 hover:bg-slate-100"
            aria-label="Toggle Menu"
          >
            {mobileOpen ? (
              <X className="h-5 w-5" />
            ) : (
              <Menu className="h-5 w-5" />
            )}
          </button>
        </div>

        {mobileOpen && (
          <div className="md:hidden border-t border-[#DDE5DF] bg-white px-4 py-4 space-y-2">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setMobileOpen(false)}
                className="block px-3 py-2 rounded-lg text-sm font-medium text-slate-800 hover:bg-[#E8F7F0]"
              >
                {item.label}
              </Link>
            ))}
            <div className="pt-2 border-t border-slate-200 grid grid-cols-1 gap-2">
              <Link
                href="/app/overview"
                className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold bg-[#123B2A] text-white"
              >
                <Activity className="h-4 w-4" /> IKM Dashboard
              </Link>
              <Link
                href="/bank/overview"
                className="flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-sm font-medium bg-[#14243A] text-white"
              >
                <Building2 className="h-4 w-4" /> Partner Bank Portal
              </Link>
              <Link
                href="/admin/overview"
                className="flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-sm font-medium border border-slate-300 text-slate-700"
              >
                <ShieldCheck className="h-4 w-4" /> Admin Portal
              </Link>
            </div>
          </div>
        )}
      </header>

      {/* Right-Hand Drawer for Personal & Company Profile */}
      {rightProfileOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/40 backdrop-blur-xs">
          <div className="relative h-full w-full max-w-md bg-white shadow-2xl overflow-y-auto flex flex-col">
            <div className="sticky top-0 z-10 flex items-center justify-between bg-[#123B2A] text-white px-4 py-3 border-b border-emerald-800">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-300">
                Sidebar Data Personal Diri &amp; Perusahaan
              </span>
              <button
                type="button"
                onClick={() => setRightProfileOpen(false)}
                className="rounded-lg bg-white/10 hover:bg-white/20 px-2.5 py-1 text-xs font-bold text-white"
              >
                Tutup ✕
              </button>
            </div>
            <LandingLoginSidebar />
          </div>
        </div>
      )}
    </>
  );
}
