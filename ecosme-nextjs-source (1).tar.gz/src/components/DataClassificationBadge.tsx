import React from "react";
import { CheckCircle2, Cpu, AlertTriangle, Info } from "lucide-react";

export type BadgeClassification =
  | "MEASURED_DEMO"
  | "ESTIMATED"
  | "VERIFIED"
  | "PROVISIONAL"
  | "DEMO_FIXTURE";

interface Props {
  type: BadgeClassification;
  customLabel?: string;
}

export function DataClassificationBadge({ type, customLabel }: Props) {
  if (type === "VERIFIED") {
    return (
      <span
        className="inline-flex items-center gap-1 rounded-md bg-[#E8F7F0] px-2 py-0.5 text-[11px] font-semibold tracking-wide text-[#123B2A] border border-[#16A36A]/30"
        title="Verified via true active-power metering (V, I, PF) and normalized baseline reconciliation"
      >
        <CheckCircle2 className="h-3 w-3 text-[#16A36A]" />
        {customLabel ?? "VERIFIED"}
      </span>
    );
  }

  if (type === "MEASURED_DEMO") {
    return (
      <span
        className="inline-flex items-center gap-1 rounded-md bg-slate-100 px-2 py-0.5 text-[11px] font-semibold tracking-wide text-[#14243A] border border-slate-300"
        title="Simulated class-1 meter reading from deterministic demo fixture"
      >
        <Cpu className="h-3 w-3 text-[#14243A]" />
        {customLabel ?? "MEASURED (DEMO)"}
      </span>
    );
  }

  if (type === "ESTIMATED") {
    return (
      <span
        className="inline-flex items-center gap-1 rounded-md bg-amber-50 px-2 py-0.5 text-[11px] font-semibold tracking-wide text-amber-900 border border-amber-300"
        title="Estimated value (e.g., tariff projection, emission factor calculation, or current-only CT sensor)"
      >
        <AlertTriangle className="h-3 w-3 text-amber-600" />
        {customLabel ?? "ESTIMATED"}
      </span>
    );
  }

  if (type === "PROVISIONAL") {
    return (
      <span
        className="inline-flex items-center gap-1 rounded-md bg-blue-50 px-2 py-0.5 text-[11px] font-semibold tracking-wide text-blue-900 border border-blue-200"
        title="Provisional Green Score methodology — evaluates energy & sustainability performance only"
      >
        <Info className="h-3 w-3 text-blue-700" />
        {customLabel ?? "PROVISIONAL GREEN SCORE"}
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1 rounded-md bg-amber-100/80 px-2 py-0.5 text-[11px] font-semibold tracking-wide text-amber-900 border border-amber-300">
      {customLabel ?? "DEMO DATA"}
    </span>
  );
}
