import React from "react";
import Link from "next/link";
import { Activity, ShieldAlert } from "lucide-react";

export function PublicFooter() {
  return (
    <footer className="bg-[#14243A] text-slate-300 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          <div className="space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="h-8 w-8 rounded-lg bg-[#123B2A] border border-[#16A36A]/40 flex items-center justify-center">
                <Activity className="h-4 w-4 text-[#16A36A]" />
              </div>
              <span className="text-lg font-bold text-white tracking-tight">
                EcoSME
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Digital Energy Efficiency and Green Finance Readiness Platform for
              Small and Medium Industries (IKM).
            </p>
            <p className="text-[11px] text-emerald-400 font-medium">
              Measure Energy → Analyze Consumption → Identify Inefficiencies →
              Validate Savings → Generate Green Score → Prepare Green Financing Profile.
            </p>
          </div>

          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-white mb-3">
              Public Platform
            </h3>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>
                <Link href="/solutions" className="hover:text-white transition-colors">
                  EcoSME Solutions
                </Link>
              </li>
              <li>
                <Link href="/how-it-works" className="hover:text-white transition-colors">
                  Platform Workflow &amp; IoT
                </Link>
              </li>
              <li>
                <Link href="/pricing" className="hover:text-white transition-colors">
                  Subscription &amp; ESaaS Plans
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-white transition-colors">
                  About &amp; Governance
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-white mb-3">
              Role-Based Portals
            </h3>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>
                <Link href="/app/overview" className="hover:text-white transition-colors">
                  IKM Factory Dashboard
                </Link>
              </li>
              <li>
                <Link href="/app/green-score" className="hover:text-white transition-colors">
                  Provisional Green Score Card
                </Link>
              </li>
              <li>
                <Link href="/bank/overview" className="hover:text-white transition-colors">
                  Partner Bank Underwriting Portal
                </Link>
              </li>
              <li>
                <Link href="/admin/overview" className="hover:text-white transition-colors">
                  EcoSME Administrator Console
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-white mb-3">
              Account &amp; Access
            </h3>
            <ul className="space-y-2 text-sm text-slate-400">
              <li>
                <Link href="/login" className="hover:text-white transition-colors">
                  Role Login &amp; Demo Switcher
                </Link>
              </li>
              <li>
                <Link href="/register" className="hover:text-white transition-colors">
                  Register IKM Organization
                </Link>
              </li>
              <li>
                <Link href="/app/reports" className="hover:text-white transition-colors">
                  Download Standardized PDF Reports
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Mandatory Regulatory & Product Positioning Notice */}
        <div className="rounded-xl bg-slate-900/90 border border-slate-700/80 p-4 mb-6">
          <div className="flex items-start gap-3">
            <ShieldAlert className="h-5 w-5 text-[#16A36A] shrink-0 mt-0.5" />
            <div className="text-xs text-slate-300 space-y-1 leading-relaxed">
              <p className="font-semibold text-white">
                Important Positioning, Data Integrity &amp; Financial Services Disclosure
              </p>
              <p>
                EcoSME provides industrial energy-performance analytics, Scope 2 emissions estimates, and standardized{" "}
                <strong>Provisional Green Score</strong> readiness profiles. EcoSME is not a bank or licensed credit rating agency, does not independently approve or reject loans, and does not replace a partner financial institution&apos;s independent credit underwriting assessment. All Scope 2 CO₂e reductions are operational estimates based on published ESDM grid factors and do not constitute certified carbon credits.
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 pt-4 border-t border-slate-800">
          <p>© 2026 EcoSME Platform. Built with Next.js, TypeScript &amp; Tailwind CSS.</p>
          <p className="mt-2 sm:mt-0">
            Operating in Controlled Deterministic Demo Mode • Organization-Isolated RBAC Active
          </p>
        </div>
      </div>
    </footer>
  );
}
