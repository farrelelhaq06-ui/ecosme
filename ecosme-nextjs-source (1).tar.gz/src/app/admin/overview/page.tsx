"use client";

import React from "react";
import Link from "next/link";
import {
  Activity,
  ArrowRight,
  BarChart3,
  Radio,
  ShieldCheck,
  Sliders,
  Users,
} from "lucide-react";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";
import { formatDateTime } from "@/lib/formatters";

export default function AdminOverviewPage() {
  const { adminData, methodology } = useEcoSME();

  const orgs = adminData?.allOrganizations ?? [];
  const users = adminData?.allUsers ?? [];
  const devices = adminData?.allDevices ?? [];
  const logs = adminData?.auditLogs ?? [];

  const avgCompleteness =
    devices.length > 0
      ? (
          devices.reduce((sum, d) => sum + d.data_completeness_pct, 0) /
          devices.length
        ).toFixed(1)
      : "98.0";

  return (
    <PortalShell
      portalType="ADMIN"
      title="EcoSME Platform Governance & Operations Overview"
      subtitle="Monitor tenant organizations, IoT fleet telemetry health, Green Score methodology versions, and immutable audit logs."
    >
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="ecosme-card p-5 space-y-1">
          <span className="text-xs font-semibold text-slate-500">
            Organizations &amp; Users
          </span>
          <p className="text-2xl font-bold text-[#123B2A]">
            {orgs.length} Orgs / {users.length} Users
          </p>
          <p className="text-[11px] text-emerald-700 font-medium">
            3 IKMs • 1 Partner Bank • 1 Admin HQ
          </p>
        </div>

        <div className="ecosme-card p-5 space-y-1">
          <span className="text-xs font-semibold text-slate-500">
            IoT Telemetry Gateways
          </span>
          <p className="text-2xl font-bold text-[#123B2A]">
            {devices.filter((d) => d.status === "ONLINE").length} /{" "}
            {devices.length} Online
          </p>
          <p className="text-[11px] text-slate-500">
            1 Legacy CT Sensor Degraded
          </p>
        </div>

        <div className="ecosme-card p-5 space-y-1">
          <span className="text-xs font-semibold text-slate-500">
            Fleet Data Completeness
          </span>
          <p className="text-2xl font-bold text-[#16A36A]">
            {avgCompleteness}%
          </p>
          <p className="text-[11px] text-slate-500">
            5/6 Gateways Measure True V*I*PF
          </p>
        </div>

        <div className="ecosme-card p-5 space-y-1">
          <span className="text-xs font-semibold text-slate-500">
            Active Methodology
          </span>
          <p className="text-2xl font-bold text-[#14243A]">
            {methodology.version}
          </p>
          <p className="text-[11px] text-amber-800 font-medium">
            Label: Provisional Green Score
          </p>
        </div>
      </div>

      {/* Quick Admin Modules + Recent Audit Log Stream */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 space-y-3">
          {[
            {
              href: "/admin/users",
              title: "User & Organization Management",
              desc: "Inspect tenant organizations, NPWP/NIB metadata, and role assignments.",
              icon: Users,
            },
            {
              href: "/admin/devices",
              title: "Fleet-Wide IoT Device Monitor",
              desc: "Track ESP32/Modbus gateway connectivity, firmware versions, and heartbeats.",
              icon: Radio,
            },
            {
              href: "/admin/data-quality",
              title: "Data Quality & Sensor Audit",
              desc: "Audit telemetry completeness and true active-power vs. CT-only compliance.",
              icon: BarChart3,
            },
            {
              href: "/admin/green-score",
              title: "Green Score Methodology & Config",
              desc: "Configure the 5 dimension weights, grade thresholds, and SaaS pricing.",
              icon: Sliders,
            },
          ].map((mod) => {
            const Icon = mod.icon;
            return (
              <Link
                key={mod.href}
                href={mod.href}
                className="ecosme-card-interactive p-4 flex items-center justify-between gap-3 block"
              >
                <div className="flex items-start gap-3">
                  <div className="h-9 w-9 rounded-lg bg-[#E8F7F0] flex items-center justify-center text-[#123B2A] shrink-0">
                    <Icon className="h-4 w-4 text-[#16A36A]" />
                  </div>
                  <div>
                    <h2 className="text-sm font-bold text-[#123B2A]">
                      {mod.title}
                    </h2>
                    <p className="text-xs text-slate-600">{mod.desc}</p>
                  </div>
                </div>
                <ArrowRight className="h-4 w-4 text-slate-400 shrink-0" />
              </Link>
            );
          })}
        </div>

        <div className="lg:col-span-7 ecosme-card p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <h2 className="text-base font-bold text-[#123B2A] flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-[#16A36A]" />
              Recent Platform Audit Logs ({logs.length} total)
            </h2>
            <Link
              href="/admin/audit-logs"
              className="text-xs font-semibold text-[#16A36A] hover:underline"
            >
              View Full Audit Trail →
            </Link>
          </div>

          <div className="space-y-2.5 text-xs">
            {logs.slice(0, 6).map((log) => (
              <div
                key={log.id}
                className="rounded-lg bg-[#F5F8F6] border border-[#DDE5DF] p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div>
                  <span className="font-mono font-bold text-[#123B2A]">
                    {log.action}
                  </span>
                  <span className="mx-1.5 text-slate-400">•</span>
                  <span className="text-slate-700 font-medium">
                    {log.user_name} ({log.user_role})
                  </span>
                  <p className="text-[11px] font-mono text-slate-500 mt-0.5">
                    Target: {log.target_record}
                  </p>
                </div>
                <span className="font-mono text-[11px] text-slate-500 shrink-0">
                  {formatDateTime(log.timestamp)}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </PortalShell>
  );
}
