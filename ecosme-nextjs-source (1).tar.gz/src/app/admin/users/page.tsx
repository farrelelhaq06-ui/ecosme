"use client";

import React from "react";
import { Building2, ShieldCheck, Users } from "lucide-react";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";

export default function AdminUsersPage() {
  const { adminData } = useEcoSME();
  const orgs = adminData?.allOrganizations ?? [];
  const users = adminData?.allUsers ?? [];
  const consents = adminData?.allConsents ?? [];

  return (
    <PortalShell
      portalType="ADMIN"
      title="User, Organization & Isolation Governance"
      subtitle="Manage tenant organizations, inspect RBAC role bindings, and audit data-sharing consent states across the platform."
    >
      {/* Organizations Table */}
      <div className="ecosme-card overflow-hidden mb-6">
        <div className="p-4 border-b border-[#DDE5DF] flex items-center justify-between">
          <h2 className="text-sm font-bold text-[#123B2A] flex items-center gap-2">
            <Building2 className="h-4 w-4 text-[#16A36A]" />
            Registered Organizations ({orgs.length})
          </h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#F5F8F6] text-slate-600 border-b border-[#DDE5DF]">
                <th className="py-3 px-4 font-semibold">Organization Name &amp; ID</th>
                <th className="py-3 px-4 font-semibold">Type</th>
                <th className="py-3 px-4 font-semibold">Industry &amp; Location</th>
                <th className="py-3 px-4 font-semibold">PLN Class &amp; Capacity</th>
                <th className="py-3 px-4 font-semibold">Bank Data Consent Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {orgs.map((o) => {
                const orgConsent = consents.find(
                  (c) => c.organization_id === o.id
                );
                return (
                  <tr key={o.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4">
                      <span className="font-bold text-[#123B2A] block">
                        {o.name}
                      </span>
                      <span className="font-mono text-[11px] text-slate-500">
                        {o.id}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="rounded bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-800">
                        {o.type}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-medium text-slate-800 block">
                        {o.industry_category}
                      </span>
                      <span className="text-[11px] text-slate-500">
                        {o.location}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      {o.pln_tariff_class} ({o.installed_capacity_kva} kVA)
                    </td>
                    <td className="py-3 px-4">
                      {orgConsent ? (
                        <span
                          className={`rounded px-2 py-0.5 text-[10px] font-bold uppercase ${
                            orgConsent.status === "ACTIVE"
                              ? "bg-emerald-100 text-emerald-900"
                              : "bg-red-100 text-red-900"
                          }`}
                        >
                          {orgConsent.status} ({orgConsent.partner_bank_name.slice(0, 20)})
                        </span>
                      ) : (
                        <span className="text-slate-400">N/A</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Users Table */}
      <div className="ecosme-card overflow-hidden">
        <div className="p-4 border-b border-[#DDE5DF] flex items-center justify-between">
          <h2 className="text-sm font-bold text-[#123B2A] flex items-center gap-2">
            <Users className="h-4 w-4 text-[#16A36A]" />
            Directory of Role-Bound Users ({users.length})
          </h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#F5F8F6] text-slate-600 border-b border-[#DDE5DF]">
                <th className="py-3 px-4 font-semibold">User Name &amp; ID</th>
                <th className="py-3 px-4 font-semibold">Email</th>
                <th className="py-3 px-4 font-semibold">RBAC Role</th>
                <th className="py-3 px-4 font-semibold">Organization</th>
                <th className="py-3 px-4 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {users.map((u) => {
                const org = orgs.find((o) => o.id === u.organization_id);
                return (
                  <tr key={u.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4">
                      <span className="font-bold text-[#123B2A] block">
                        {u.name}
                      </span>
                      <span className="text-[11px] text-slate-500">
                        {u.title} ({u.id})
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-700">
                      {u.email}
                    </td>
                    <td className="py-3 px-4">
                      <span className="rounded bg-[#E8F7F0] text-[#123B2A] px-2 py-0.5 text-[10px] font-bold">
                        {u.role}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-800">
                      {org?.name ?? u.organization_id}
                    </td>
                    <td className="py-3 px-4">
                      <span className="rounded bg-emerald-100 text-emerald-900 px-2 py-0.5 text-[10px] font-bold">
                        ACTIVE
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </PortalShell>
  );
}
