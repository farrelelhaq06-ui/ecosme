"use client";

import React from "react";
import { AlertTriangle, BarChart3, CheckCircle2 } from "lucide-react";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";

export default function AdminDataQualityPage() {
  const { adminData } = useEcoSME();
  const scores = adminData?.allGreenScores ?? [];
  const orgs = adminData?.allOrganizations ?? [];
  const devices = adminData?.allDevices ?? [];

  return (
    <PortalShell
      portalType="ADMIN"
      title="Telemetry Data Quality & Metering Integrity Audit"
      subtitle="Audit transmission completeness, true active-power metering ratios, and baseline verification readiness across IKM organizations."
    >
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {scores.map((gs) => {
          const org = orgs.find((o) => o.id === gs.organization_id);
          const orgDevices = devices.filter(
            (d) => d.organization_id === gs.organization_id
          );
          const truePowerCount = orgDevices.filter(
            (d) => d.measures_voltage && d.measures_power_factor
          ).length;

          return (
            <div key={gs.id} className="ecosme-card p-5 space-y-3 text-xs">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                <h2 className="text-sm font-bold text-[#123B2A]">
                  {org?.name ?? gs.organization_id}
                </h2>
                <span
                  className={`rounded px-2 py-0.5 text-[10px] font-bold ${
                    gs.data_quality_status === "HIGH_QUALITY"
                      ? "bg-emerald-100 text-emerald-900"
                      : "bg-amber-100 text-amber-900"
                  }`}
                >
                  {gs.data_quality_status}
                </span>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Telemetry Completeness:</span>
                  <span className="font-bold text-[#123B2A]">
                    {gs.data_completeness_pct}%
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">True Power Meters:</span>
                  <span className="font-semibold text-slate-800">
                    {truePowerCount} / {orgDevices.length || 1} Gateways
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Green Score Impact:</span>
                  <span className="font-bold text-[#16A36A]">
                    {gs.overall_score}/100 (Grade {gs.rating})
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="ecosme-card p-6 space-y-3 text-xs">
        <h2 className="text-base font-bold text-[#123B2A] flex items-center gap-2">
          <BarChart3 className="h-5 w-5 text-[#16A36A]" />
          Data Quality Governance Rules
        </h2>
        <ul className="space-y-2 text-slate-700">
          <li className="flex items-start gap-2">
            <CheckCircle2 className="h-4 w-4 text-[#16A36A] shrink-0" />
            <span>
              <strong>HIGH_QUALITY Threshold:</strong> Requires ≥90% daily telemetry transmission completeness AND ≥75% of monitored machine lines equipped with true active-power meters (Voltage, Current, Power Factor).
            </span>
          </li>
          <li className="flex items-start gap-2">
            <AlertTriangle className="h-4 w-4 text-amber-600 shrink-0" />
            <span>
              <strong>Current-Only Sensor Segregation:</strong> Any measurement originating from a CT-only device without live voltage/PF is flagged as <code className="font-mono">ESTIMATED</code> and excluded from ESaaS performance billing.
            </span>
          </li>
        </ul>
      </div>
    </PortalShell>
  );
}
