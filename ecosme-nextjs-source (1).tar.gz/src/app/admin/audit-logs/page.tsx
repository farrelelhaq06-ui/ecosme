"use client";

import React from "react";
import { ShieldCheck } from "lucide-react";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";
import { formatDateTime } from "@/lib/formatters";

export default function AdminAuditLogsPage() {
  const { adminData } = useEcoSME();
  const logs = adminData?.auditLogs ?? [];

  return (
    <PortalShell
      portalType="ADMIN"
      title="Immutable System Activity & Governance Audit Logs"
      subtitle="Every administrative, IoT provisioning, data-sharing consent, and bank underwriting action is recorded with User ID, Action, Target Record, Timestamp, and Metadata."
    >
      <div className="ecosme-card overflow-hidden">
        <div className="p-4 border-b border-[#DDE5DF] flex items-center justify-between">
          <h2 className="text-sm font-bold text-[#123B2A] flex items-center gap-2">
            <ShieldCheck className="h-4 w-4 text-[#16A36A]" />
            Platform Audit Trail ({logs.length} Events)
          </h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#F5F8F6] text-slate-600 border-b border-[#DDE5DF]">
                <th className="py-3 px-4 font-semibold">Timestamp</th>
                <th className="py-3 px-4 font-semibold">User ID &amp; Role</th>
                <th className="py-3 px-4 font-semibold">Action</th>
                <th className="py-3 px-4 font-semibold">Target Record</th>
                <th className="py-3 px-4 font-semibold">Relevant Metadata</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {logs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50">
                  <td className="py-3 px-4 font-mono text-[11px] text-slate-600 whitespace-nowrap">
                    {formatDateTime(log.timestamp)}
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-bold text-[#123B2A] block">
                      {log.user_name} ({log.user_id})
                    </span>
                    <span className="text-[10px] font-mono text-slate-500">
                      {log.user_role} • Org: {log.organization_id}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="rounded bg-[#E8F7F0] text-[#123B2A] font-mono px-2 py-0.5 text-[11px] font-bold">
                      {log.action}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-slate-800">
                    {log.target_record}
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-slate-600">
                    {JSON.stringify(log.metadata)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </PortalShell>
  );
}
