"use client";

import React from "react";
import { Radio, RefreshCw, WifiOff } from "lucide-react";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";
import { formatDateTime } from "@/lib/formatters";

export default function AdminDevicesPage() {
  const { adminData, mutateState } = useEcoSME();
  const devices = adminData?.allDevices ?? [];
  const orgs = adminData?.allOrganizations ?? [];

  return (
    <PortalShell
      portalType="ADMIN"
      title="Fleet-Wide IoT Device & Heartbeat Monitoring"
      subtitle="Supervise all connected ESP32, NodeMCU, and Schneider Modbus energy gateways across tenant organizations."
    >
      <div className="ecosme-card overflow-hidden">
        <div className="p-4 border-b border-[#DDE5DF] flex items-center justify-between">
          <h2 className="text-sm font-bold text-[#123B2A] flex items-center gap-2">
            <Radio className="h-4 w-4 text-[#16A36A]" />
            Cross-Organization IoT Gateway Inventory ({devices.length})
          </h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#F5F8F6] text-slate-600 border-b border-[#DDE5DF]">
                <th className="py-3 px-4 font-semibold">Device &amp; Serial</th>
                <th className="py-3 px-4 font-semibold">Tenant Organization</th>
                <th className="py-3 px-4 font-semibold">Hardware / Protocol</th>
                <th className="py-3 px-4 font-semibold">Active Power Support</th>
                <th className="py-3 px-4 font-semibold">Last Heartbeat</th>
                <th className="py-3 px-4 font-semibold">Status</th>
                <th className="py-3 px-4 font-semibold text-right">Admin Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {devices.map((d) => {
                const org = orgs.find((o) => o.id === d.organization_id);
                return (
                  <tr key={d.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4">
                      <span className="font-bold text-[#123B2A] block">
                        {d.name}
                      </span>
                      <span className="font-mono text-[11px] text-slate-500">
                        {d.serial_number}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-800">
                      {org?.name ?? d.organization_id}
                    </td>
                    <td className="py-3 px-4">
                      {d.hardware_type} ({d.connection_protocol})
                    </td>
                    <td className="py-3 px-4">
                      {d.measures_voltage && d.measures_power_factor ? (
                        <span className="rounded bg-emerald-100 text-emerald-900 px-2 py-0.5 text-[10px] font-bold">
                          True V × I × PF
                        </span>
                      ) : (
                        <span className="rounded bg-amber-100 text-amber-900 px-2 py-0.5 text-[10px] font-bold">
                          CT Current-Only (Estimated)
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-slate-600">
                      {formatDateTime(d.last_heartbeat)}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`rounded px-2 py-0.5 text-[10px] font-bold uppercase ${
                          d.status === "ONLINE"
                            ? "bg-emerald-100 text-emerald-900"
                            : d.status === "DEGRADED"
                            ? "bg-amber-100 text-amber-900"
                            : "bg-red-100 text-red-900"
                        }`}
                      >
                        {d.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right space-x-1.5">
                      <button
                        type="button"
                        onClick={() =>
                          mutateState("SIMULATE_HEARTBEAT", {
                            device_id: d.id,
                            mode: "PING",
                          })
                        }
                        className="inline-flex items-center gap-1 rounded border border-slate-300 bg-white hover:bg-slate-100 px-2 py-1 text-[11px] font-medium"
                      >
                        <RefreshCw className="h-3 w-3" /> Ping
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          mutateState("SIMULATE_HEARTBEAT", {
                            device_id: d.id,
                            mode: "DISCONNECT",
                          })
                        }
                        className="inline-flex items-center gap-1 rounded border border-red-200 bg-red-50 hover:bg-red-100 px-2 py-1 text-[11px] font-medium text-red-800"
                      >
                        <WifiOff className="h-3 w-3" /> Drop
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </PortalShell>
  );
}
