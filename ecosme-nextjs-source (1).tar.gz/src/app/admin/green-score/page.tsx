"use client";

import React, { useState } from "react";
import { CheckCircle2, Sliders } from "lucide-react";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";

export default function AdminGreenScorePage() {
  const { methodology, mutateState } = useEcoSME();

  const [version, setVersion] = useState(methodology.version);
  const [wEff, setWEff] = useState(methodology.weights.efficiency_improvement);
  const [wStab, setWStab] = useState(methodology.weights.consumption_stability);
  const [wComp, setWComp] = useState(methodology.weights.data_completeness);
  const [wSust, setWSust] = useState(
    methodology.weights.sustainability_performance
  );
  const [wCons, setWCons] = useState(methodology.weights.monitoring_consistency);

  const [threshA, setThreshA] = useState(methodology.thresholds.rating_a_min);
  const [threshB, setThreshB] = useState(methodology.thresholds.rating_b_min);
  const [threshC, setThreshC] = useState(methodology.thresholds.rating_c_min);
  const [savedMsg, setSavedMsg] = useState<string | null>(null);

  const totalWeight = wEff + wStab + wComp + wSust + wCons;

  const handleSaveMethodology = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await mutateState("ADMIN_UPDATE_METHODOLOGY", {
      version,
      weights: {
        efficiency_improvement: wEff,
        consumption_stability: wStab,
        data_completeness: wComp,
        sustainability_performance: wSust,
        monitoring_consistency: wCons,
      },
      thresholds: {
        rating_a_min: threshA,
        rating_b_min: threshB,
        rating_c_min: threshC,
      },
    });
    if (res.ok) {
      setSavedMsg(
        "Green Score methodology updated, scores recalculated, and action logged to Audit Trail."
      );
      setTimeout(() => setSavedMsg(null), 3500);
    }
  };

  return (
    <PortalShell
      portalType="ADMIN"
      title="Green Score Methodology & Weighting Governance"
      subtitle="Configure the 5 component weights, rating grade thresholds (A/B/C/D), and methodology version metadata."
    >
      <form
        onSubmit={handleSaveMethodology}
        className="ecosme-card p-6 max-w-3xl space-y-6 text-xs"
      >
        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
          <div className="flex items-center gap-2">
            <Sliders className="h-5 w-5 text-[#16A36A]" />
            <h2 className="text-base font-bold text-[#123B2A]">
              Methodology Configuration ({methodology.name})
            </h2>
          </div>
          <span className="rounded bg-blue-50 text-blue-900 border border-blue-200 px-2.5 py-1 font-bold">
            Provisional Green Score
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Methodology Version Tag
            </label>
            <input
              type="text"
              required
              value={version}
              onChange={(e) => setVersion(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 font-mono font-bold"
            />
          </div>
          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Total Component Weight Sum (Target: 100%)
            </label>
            <div className="rounded-lg bg-[#F5F8F6] border border-[#DDE5DF] px-3 py-2 font-bold text-[#123B2A]">
              {totalWeight}%
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="font-bold text-[#123B2A]">
            Dimension Weights (%):
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
            <div>
              <label className="block text-slate-600 mb-1">
                1. Efficiency (%)
              </label>
              <input
                type="number"
                value={wEff}
                onChange={(e) => setWEff(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-bold"
              />
            </div>
            <div>
              <label className="block text-slate-600 mb-1">
                2. Stability (%)
              </label>
              <input
                type="number"
                value={wStab}
                onChange={(e) => setWStab(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-bold"
              />
            </div>
            <div>
              <label className="block text-slate-600 mb-1">
                3. Data Quality (%)
              </label>
              <input
                type="number"
                value={wComp}
                onChange={(e) => setWComp(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-bold"
              />
            </div>
            <div>
              <label className="block text-slate-600 mb-1">
                4. Carbon / Sust (%)
              </label>
              <input
                type="number"
                value={wSust}
                onChange={(e) => setWSust(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-bold"
              />
            </div>
            <div>
              <label className="block text-slate-600 mb-1">
                5. Consistency (%)
              </label>
              <input
                type="number"
                value={wCons}
                onChange={(e) => setWCons(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-bold"
              />
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <h3 className="font-bold text-[#123B2A]">
            Grade Rating Minimum Thresholds (0–100):
          </h3>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-600 mb-1">
                Grade A Minimum
              </label>
              <input
                type="number"
                value={threshA}
                onChange={(e) => setThreshA(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-bold"
              />
            </div>
            <div>
              <label className="block text-slate-600 mb-1">
                Grade B Minimum
              </label>
              <input
                type="number"
                value={threshB}
                onChange={(e) => setThreshB(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-bold"
              />
            </div>
            <div>
              <label className="block text-slate-600 mb-1">
                Grade C Minimum
              </label>
              <input
                type="number"
                value={threshC}
                onChange={(e) => setThreshC(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-bold"
              />
            </div>
          </div>
        </div>

        <button
          type="submit"
          className="rounded-lg bg-[#123B2A] hover:bg-[#0D2B1E] text-white px-6 py-2.5 font-semibold transition-colors"
        >
          Publish Methodology &amp; Recalculate Green Scores
        </button>

        {savedMsg && (
          <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-3 text-emerald-900 font-medium flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-[#16A36A]" />
            {savedMsg}
          </div>
        )}
      </form>
    </PortalShell>
  );
}
