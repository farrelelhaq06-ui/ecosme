import React from "react";
import Link from "next/link";
import {
  Activity,
  ArrowRight,
  Award,
  Building2,
  CheckCircle2,
  Cpu,
  Factory,
  Landmark,
  ShieldCheck,
} from "lucide-react";
import { PublicNavbar } from "@/components/PublicNavbar";
import { PublicFooter } from "@/components/PublicFooter";

export default function SolutionsPage() {
  return (
    <div className="min-h-screen flex flex-col bg-[#F5F8F6]">
      <PublicNavbar />
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
        <div className="max-w-3xl space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-[#16A36A]">
            EcoSME Solutions Architecture
          </span>
          <h1 className="text-3xl sm:text-4xl font-bold text-[#123B2A] tracking-tight">
            Tailored Solutions for Industrial SMEs and Green Financial Institutions
          </h1>
          <p className="text-base text-[#4B5563] leading-relaxed">
            EcoSME aligns operational energy engineering on the factory floor with the standardized data requirements of sustainable commercial banking.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="ecosme-card p-6 space-y-4">
            <div className="h-11 w-11 rounded-lg bg-[#E8F7F0] flex items-center justify-center text-[#123B2A]">
              <Factory className="h-6 w-6 text-[#16A36A]" />
            </div>
            <h2 className="text-xl font-bold text-[#123B2A]">
              1. For IKM / Factory Owners
            </h2>
            <p className="text-sm text-[#4B5563] leading-relaxed">
              Eliminate energy waste across high-load thermal, compressed air, weaving, and stamping machinery.
            </p>
            <ul className="space-y-2 text-xs text-slate-700">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-[#16A36A] shrink-0" />
                <span>Sub-metering for single-phase (220V) and 3-phase (380V) industrial lines</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-[#16A36A] shrink-0" />
                <span>Power factor (<code className="text-[11px]">cos φ</code>) monitoring to avoid PLN reactive power penalties</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-[#16A36A] shrink-0" />
                <span>Operating-hour &amp; production-volume normalized baseline savings</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-[#16A36A] shrink-0" />
                <span>Downloadable PDF dossiers for internal management and bank submissions</span>
              </li>
            </ul>
            <div className="pt-2">
              <Link
                href="/app/overview"
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#123B2A] hover:text-[#16A36A]"
              >
                Open IKM Factory Dashboard <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>

          <div className="ecosme-card p-6 space-y-4">
            <div className="h-11 w-11 rounded-lg bg-slate-100 flex items-center justify-center text-[#14243A]">
              <Building2 className="h-6 w-6 text-[#14243A]" />
            </div>
            <h2 className="text-xl font-bold text-[#14243A]">
              2. For Partner Banks &amp; Green Lenders
            </h2>
            <p className="text-sm text-[#4B5563] leading-relaxed">
              Evaluate consented SME green capex applications using structured, meter-backed energy telemetry rather than unverified vendor claims.
            </p>
            <ul className="space-y-2 text-xs text-slate-700">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-[#16A36A] shrink-0" />
                <span>Strict consent-gated pipeline (view only IKMs with active authorization)</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-[#16A36A] shrink-0" />
                <span>5-dimension Provisional Green Score breakdown with data-quality flags</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-[#16A36A] shrink-0" />
                <span>Clear separation between verified active-power savings and estimated figures</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-[#16A36A] shrink-0" />
                <span>Full audit trail of bank underwriting status updates and review notes</span>
              </li>
            </ul>
            <div className="pt-2">
              <Link
                href="/bank/overview"
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#14243A] hover:text-[#16A36A]"
              >
                Open Partner Bank Portal <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>

          <div className="ecosme-card p-6 space-y-4">
            <div className="h-11 w-11 rounded-lg bg-[#E8F7F0] flex items-center justify-center text-[#123B2A]">
              <Cpu className="h-6 w-6 text-[#16A36A]" />
            </div>
            <h2 className="text-xl font-bold text-[#123B2A]">
              3. Energy Savings-as-a-Service (ESaaS)
            </h2>
            <p className="text-sm text-[#4B5563] leading-relaxed">
              Support performance-based equipment retrofits (such as VFD inverters and IE4 motors) where fees are tied exclusively to verified savings.
            </p>
            <ul className="space-y-2 text-xs text-slate-700">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-[#16A36A] shrink-0" />
                <span>Zero fee charged on unverified or current-only (CT) estimated savings</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-[#16A36A] shrink-0" />
                <span>Configurable revenue-share percentage (e.g., 30% EcoSME / 70% IKM retained)</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-[#16A36A] shrink-0" />
                <span>Transparent monthly reconciliation against PLN tariff schedules</span>
              </li>
            </ul>
            <div className="pt-2">
              <Link
                href="/pricing"
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#123B2A] hover:text-[#16A36A]"
              >
                Simulate ESaaS Revenue Split <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </main>
      <PublicFooter />
    </div>
  );
}
