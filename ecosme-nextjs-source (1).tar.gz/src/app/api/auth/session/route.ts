import { NextRequest, NextResponse } from "next/server";
import { appendAuditLog, getDb, saveDb } from "@/lib/db";
import {
  getServerSession,
  resolveSessionFromUserId,
  SESSION_COOKIE_NAME,
} from "@/lib/auth";

export async function GET() {
  const session = await getServerSession();
  const db = getDb();
  return NextResponse.json({
    user: session.user,
    organization: session.organization,
    demoAccounts: db.users.map((u) => {
      const org = db.organizations.find((o) => o.id === u.organization_id);
      return {
        id: u.id,
        name: u.name,
        email: u.email,
        role: u.role,
        title: u.title,
        organizationName: org?.name ?? u.organization_id,
      };
    }),
  });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const db = getDb();

    let targetUser = db.users.find((u) => u.id === body.userId);
    if (!targetUser && body.email) {
      targetUser = db.users.find(
        (u) => u.email.toLowerCase() === String(body.email).toLowerCase()
      );
    }

    if (!targetUser) {
      return NextResponse.json(
        { error: "User account not found in EcoSME directory." },
        { status: 404 }
      );
    }

    if (!targetUser.active) {
      return NextResponse.json(
        { error: "This user account has been deactivated by an administrator." },
        { status: 403 }
      );
    }

    const session = resolveSessionFromUserId(targetUser.id, db);
    appendAuditLog(db, {
      user_id: session.user.id,
      user_name: session.user.name,
      user_role: session.user.role,
      organization_id: session.organization.id,
      action: "USER_SESSION_SWITCHED",
      target_record: `User:${session.user.id}`,
      metadata: {
        role: session.user.role,
        organization: session.organization.name,
      },
    });
    saveDb(db);

    const res = NextResponse.json({
      user: session.user,
      organization: session.organization,
    });

    res.cookies.set(SESSION_COOKIE_NAME, session.user.id, {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 7,
    });

    return res;
  } catch {
    return NextResponse.json(
      { error: "Invalid session switch request payload." },
      { status: 400 }
    );
  }
}
