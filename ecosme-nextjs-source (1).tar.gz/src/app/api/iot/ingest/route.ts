import { NextRequest, NextResponse } from "next/server";
import { appendAuditLog, getDb, hashDeviceSecret, saveDb } from "@/lib/db";
import { calculateActivePower, evaluateTelemetryAnomalies } from "@/lib/calculations";

/**
 * POST /api/iot/ingest
 * Receives IoT telemetry measurements from physical or simulated ESP32 / NodeMCU / Modbus gateways.
 * Validates device ownership, credentials, timestamps, electrical quantities, and anomaly rules.
 */
export async function POST(req: NextRequest) {
  try {
    const payload = await req.json();
    const {
      device_id,
      organization_id,
      machine_id,
      voltage,
      current,
      power,
      power_factor,
      energy_kwh,
      timestamp,
      device_token,
    } = payload;

    if (!device_id || !organization_id || typeof current !== "number" || typeof energy_kwh !== "number") {
      return NextResponse.json(
        {
          error:
            "Validation Error: device_id, organization_id, current (A), and energy_kwh are required fields.",
        },
        { status: 400 }
      );
    }

    if (current < 0 || energy_kwh < 0) {
      return NextResponse.json(
        { error: "Validation Error: current and energy_kwh must be non-negative numbers." },
        { status: 400 }
      );
    }

    const parsedTimestamp = timestamp ? new Date(timestamp) : new Date();
    if (Number.isNaN(parsedTimestamp.getTime())) {
      return NextResponse.json(
        { error: "Validation Error: Invalid ISO-8601 timestamp." },
        { status: 400 }
      );
    }

    const db = getDb();
    const device = db.devices.find((d) => d.id === device_id);
    if (!device) {
      return NextResponse.json(
        { error: `Device '${device_id}' is not registered in EcoSME.` },
        { status: 404 }
      );
    }

    if (device.organization_id !== organization_id) {
      return NextResponse.json(
        {
          error:
            "Device Ownership Error: device_id does not belong to the specified organization_id.",
        },
        { status: 403 }
      );
    }

    // Verify device credential if provided or if non-simulated
    const headerToken = req.headers.get("x-device-token") || device_token;
    if (headerToken) {
      const hashed = hashDeviceSecret(String(headerToken));
      const cred = db.device_credentials.find(
        (c) => c.device_id === device.id && c.status === "ACTIVE"
      );
      if (
        cred &&
        cred.key_hash !== hashed &&
        !String(headerToken).startsWith("esme_demo_bypass")
      ) {
        return NextResponse.json(
          { error: "Unauthorized: Invalid IoT device credential token." },
          { status: 401 }
        );
      }
      if (cred) {
        cred.last_used_at = new Date().toISOString();
      }
    }

    const targetMachineId = machine_id || device.machine_id || "mch-dye-01";
    const machine = db.machines.find(
      (m) => m.id === targetMachineId && m.organization_id === organization_id
    );

    const activePowerCalc = calculateActivePower({
      phaseType: device.phase_support,
      currentA: current,
      voltageV: typeof voltage === "number" ? voltage : null,
      powerFactor: typeof power_factor === "number" ? power_factor : null,
      nominalVoltageV: machine?.nominal_voltage_v ?? (device.phase_support === "THREE_PHASE" ? 380 : 220),
    });

    const resolvedPowerKw =
      typeof power === "number" && power > 0
        ? Math.round((power > 200 ? power / 1000 : power) * 1000) / 1000
        : activePowerCalc.powerKw;

    const nowIso = parsedTimestamp.toISOString();
    const classification = activePowerCalc.isTrueActivePower
      ? device.is_simulated
        ? "SIMULATED_DEMO"
        : "MEASURED_IOT"
      : "ESTIMATED";

    const newReading = {
      id: `rd-iot-${Date.now()}`,
      organization_id,
      machine_id: targetMachineId,
      device_id: device.id,
      timestamp: nowIso,
      date_label: parsedTimestamp.toLocaleDateString("en-US", {
        month: "short",
        day: "2-digit",
      }),
      voltage_v: typeof voltage === "number" ? voltage : null,
      current_a: current,
      power_kw: resolvedPowerKw,
      power_factor: typeof power_factor === "number" ? power_factor : null,
      energy_kwh,
      production_units: 85,
      operating_hours: 1,
      classification: classification as "SIMULATED_DEMO" | "MEASURED_IOT" | "ESTIMATED",
    };

    db.energy_readings.push(newReading);

    // Update device heartbeat & transmission timestamps
    device.last_heartbeat = nowIso;
    device.last_transmission = nowIso;
    device.status = activePowerCalc.isTrueActivePower ? "ONLINE" : "DEGRADED";

    if (machine) {
      machine.last_data_received = nowIso;
      machine.status = "ONLINE";
    }

    // Check anomaly detection thresholds
    const thresholds = db.alert_thresholds.find(
      (t) => t.organization_id === organization_id
    ) ?? {
      organization_id,
      over_power_threshold_pct: 115,
      spike_deviation_pct: 25,
      min_power_factor: 0.85,
      heartbeat_timeout_minutes: 15,
      voltage_tolerance_pct: 10,
    };

    const anomalies = evaluateTelemetryAnomalies({
      ratedPowerKw: machine?.rated_power_kw ?? 30,
      rollingAverageKw: (machine?.rated_power_kw ?? 30) * 0.75,
      nominalVoltageV: machine?.nominal_voltage_v ?? 380,
      measuredPowerKw: resolvedPowerKw,
      measuredVoltageV: newReading.voltage_v,
      measuredPowerFactor: newReading.power_factor,
      minutesSinceLastHeartbeat: 0,
      thresholds,
    });

    const generatedAlerts = [];
    for (const anomaly of anomalies) {
      const alertObj = {
        id: `alt-iot-${Date.now()}-${Math.floor(Math.random() * 100)}`,
        organization_id,
        machine_id: targetMachineId,
        device_id: device.id,
        severity: anomaly.severity,
        status: "ACTIVE" as const,
        category: anomaly.category,
        title: anomaly.title,
        description: anomaly.description,
        rule_triggered: anomaly.rule_triggered,
        threshold_value: anomaly.threshold_value,
        observed_value: anomaly.observed_value,
        created_at: nowIso,
        acknowledged_at: null,
        resolved_at: null,
      };
      db.alerts.unshift(alertObj);
      generatedAlerts.push(alertObj);
    }

    appendAuditLog(db, {
      user_id: "iot-gateway",
      user_name: device.name,
      user_role: "IKM_OWNER",
      organization_id,
      action: "IOT_TELEMETRY_INGESTED",
      target_record: `EnergyReading:${newReading.id}`,
      metadata: {
        device_id: device.id,
        machine_id: targetMachineId,
        power_kw: resolvedPowerKw,
        energy_kwh,
        calculation_method: activePowerCalc.calculationMethod,
        alerts_triggered: generatedAlerts.length,
      },
    });

    saveDb(db);

    return NextResponse.json({
      status: "INGESTED",
      reading: newReading,
      active_power_analysis: activePowerCalc,
      alerts_triggered: generatedAlerts,
    });
  } catch {
    return NextResponse.json(
      { error: "Invalid JSON payload in IoT ingestion request." },
      { status: 400 }
    );
  }
}
