import { NextRequest, NextResponse } from "next/server";
import {
  appendAuditLog,
  getDb,
  hashDeviceSecret,
  resetDbToSeed,
  saveDb,
} from "@/lib/db";
import {
  canAccessOrganizationData,
  getAuthorizedIkmOrganizationsForBank,
  getServerSession,
  hasRolePermission,
} from "@/lib/auth";
import { calculateGreenScore } from "@/lib/calculations";
import { ApplicationStatus, Device, Machine } from "@/lib/types";

export async function GET(req: NextRequest) {
  const session = await getServerSession();
  const db = getDb();
  const requestedOrgId =
    req.nextUrl.searchParams.get("orgId") || session.organization.id;

  // Enforce server-side RBAC and organization-level isolation
  if (session.user.role === "IKM_OWNER") {
    const access = canAccessOrganizationData(session.user, requestedOrgId, db);
    if (!access.allowed) {
      return NextResponse.json({ error: access.reason }, { status: 403 });
    }
  } else if (session.user.role === "BANK_OFFICER" && requestedOrgId !== session.organization.id) {
    const access = canAccessOrganizationData(session.user, requestedOrgId, db);
    if (!access.allowed) {
      return NextResponse.json({ error: access.reason }, { status: 403 });
    }
  }

  const targetOrg =
    db.organizations.find((o) => o.id === requestedOrgId) ?? session.organization;

  // For Bank Portal: compute strictly consented IKM pipeline
  const consentedBankPipeline =
    session.user.role === "BANK_OFFICER" || session.user.role === "ECOSME_ADMIN"
      ? getAuthorizedIkmOrganizationsForBank("org-bank-nusantara", db).map(
          ({ organization, consent }) => {
            const gs = db.green_scores.find(
              (g) => g.organization_id === organization.id
            );
            const app = db.financing_applications.find(
              (a) => a.organization_id === organization.id
            );
            const machines = db.machines.filter(
              (m) => m.organization_id === organization.id
            );
            const savings = db.savings_records.filter(
              (s) => s.organization_id === organization.id
            );
            const reports = db.reports.filter(
              (r) => r.organization_id === organization.id
            );
            return {
              organization,
              consent,
              greenScore: gs ?? null,
              application: app ?? null,
              machines,
              savingsRecords: savings,
              reports,
            };
          }
        )
      : [];

  return NextResponse.json({
    session,
    organization: targetOrg,
    machines: db.machines.filter((m) => m.organization_id === targetOrg.id),
    devices: db.devices.filter((d) => d.organization_id === targetOrg.id),
    deviceCredentials: db.device_credentials
      .filter((c) => c.organization_id === targetOrg.id)
      .map((c) => ({
        id: c.id,
        device_id: c.device_id,
        key_prefix: c.key_prefix,
        status: c.status,
        created_at: c.created_at,
        last_used_at: c.last_used_at,
      })), // Never expose key_hash to client
    readings: db.energy_readings.filter(
      (r) => r.organization_id === targetOrg.id
    ),
    baselines: db.energy_baselines.filter(
      (b) => b.organization_id === targetOrg.id
    ),
    savingsRecords: db.savings_records.filter(
      (s) => s.organization_id === targetOrg.id
    ),
    tariffs: db.electricity_tariffs.filter(
      (t) => t.organization_id === targetOrg.id
    ),
    emissionFactors: db.emission_factors,
    greenScore:
      db.green_scores.find((g) => g.organization_id === targetOrg.id) ??
      db.green_scores[0],
    methodology:
      db.green_score_methodologies.find((m) => m.is_active) ??
      db.green_score_methodologies[0],
    consents: db.data_sharing_consents.filter(
      (c) => c.organization_id === targetOrg.id
    ),
    applications: db.financing_applications.filter(
      (a) => a.organization_id === targetOrg.id
    ),
    reports: db.reports.filter((r) => r.organization_id === targetOrg.id),
    alerts: db.alerts.filter((a) => a.organization_id === targetOrg.id),
    alertThresholds:
      db.alert_thresholds.find((t) => t.organization_id === targetOrg.id) ??
      db.alert_thresholds[0],
    subscription:
      db.subscriptions.find((s) => s.organization_id === targetOrg.id) ??
      db.subscriptions[0],
    platformConfig: db.platform_config,
    consentedBankPipeline,
    // Admin-only collections (returned only when role === ECOSME_ADMIN)
    adminData:
      session.user.role === "ECOSME_ADMIN"
        ? {
            allOrganizations: db.organizations,
            allUsers: db.users,
            allDevices: db.devices,
            allGreenScores: db.green_scores,
            allConsents: db.data_sharing_consents,
            allApplications: db.financing_applications,
            auditLogs: db.audit_logs,
          }
        : null,
  });
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession();
    const db = getDb();
    const body = await req.json();
    const { action, payload } = body;

    switch (action) {
      case "ADD_MACHINE": {
        if (!hasRolePermission(session.user, ["IKM_OWNER", "ECOSME_ADMIN"])) {
          return NextResponse.json({ error: "Forbidden" }, { status: 403 });
        }
        const newMachine: Machine = {
          id: `mch-${Date.now()}`,
          organization_id: session.organization.id,
          name: String(payload.name || "New Industrial Machine"),
          code: String(payload.code || `MCH-NEW-${db.machines.length + 1}`),
          category: String(payload.category || "Production Line"),
          location_zone: String(payload.location_zone || "Main Production Hall"),
          rated_power_kw: Number(payload.rated_power_kw) || 15,
          phase_type:
            payload.phase_type === "SINGLE_PHASE" ? "SINGLE_PHASE" : "THREE_PHASE",
          nominal_voltage_v: payload.phase_type === "SINGLE_PHASE" ? 220 : 380,
          status: "ONLINE",
          device_id: payload.device_id || null,
          monthly_energy_kwh: Number(payload.monthly_energy_kwh) || 3200,
          baseline_monthly_kwh: Number(payload.baseline_monthly_kwh) || 3600,
          last_data_received: new Date().toISOString(),
          efficiency_notes: String(
            payload.efficiency_notes || "Added via Machine Management console."
          ),
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };
        db.machines.push(newMachine);
        appendAuditLog(db, {
          user_id: session.user.id,
          user_name: session.user.name,
          user_role: session.user.role,
          organization_id: session.organization.id,
          action: "MACHINE_CREATED",
          target_record: `Machine:${newMachine.id}`,
          metadata: { code: newMachine.code, name: newMachine.name },
        });
        saveDb(db);
        return NextResponse.json({ ok: true, machine: newMachine });
      }

      case "UPDATE_MACHINE": {
        if (!hasRolePermission(session.user, ["IKM_OWNER", "ECOSME_ADMIN"])) {
          return NextResponse.json({ error: "Forbidden" }, { status: 403 });
        }
        const m = db.machines.find(
          (item) =>
            item.id === payload.id &&
            (item.organization_id === session.organization.id ||
              session.user.role === "ECOSME_ADMIN")
        );
        if (!m) {
          return NextResponse.json({ error: "Machine not found" }, { status: 404 });
        }
        if (payload.name) m.name = String(payload.name);
        if (payload.category) m.category = String(payload.category);
        if (payload.location_zone) m.location_zone = String(payload.location_zone);
        if (payload.rated_power_kw) m.rated_power_kw = Number(payload.rated_power_kw);
        if (payload.efficiency_notes !== undefined)
          m.efficiency_notes = String(payload.efficiency_notes);
        m.updated_at = new Date().toISOString();

        appendAuditLog(db, {
          user_id: session.user.id,
          user_name: session.user.name,
          user_role: session.user.role,
          organization_id: session.organization.id,
          action: "MACHINE_UPDATED",
          target_record: `Machine:${m.id}`,
          metadata: { code: m.code, name: m.name },
        });
        saveDb(db);
        return NextResponse.json({ ok: true, machine: m });
      }

      case "TOGGLE_MACHINE_STATUS": {
        if (!hasRolePermission(session.user, ["IKM_OWNER", "ECOSME_ADMIN"])) {
          return NextResponse.json({ error: "Forbidden" }, { status: 403 });
        }
        const m = db.machines.find(
          (item) =>
            item.id === payload.id &&
            (item.organization_id === session.organization.id ||
              session.user.role === "ECOSME_ADMIN")
        );
        if (!m) {
          return NextResponse.json({ error: "Machine not found" }, { status: 404 });
        }
        m.status = m.status === "DEACTIVATED" ? "ONLINE" : "DEACTIVATED";
        m.updated_at = new Date().toISOString();

        appendAuditLog(db, {
          user_id: session.user.id,
          user_name: session.user.name,
          user_role: session.user.role,
          organization_id: session.organization.id,
          action:
            m.status === "DEACTIVATED"
              ? "MACHINE_DEACTIVATED"
              : "MACHINE_REACTIVATED",
          target_record: `Machine:${m.id}`,
          metadata: { code: m.code, new_status: m.status },
        });
        saveDb(db);
        return NextResponse.json({ ok: true, machine: m });
      }

      case "PAIR_DEVICE": {
        if (!hasRolePermission(session.user, ["IKM_OWNER", "ECOSME_ADMIN"])) {
          return NextResponse.json({ error: "Forbidden" }, { status: 403 });
        }
        const hwType = payload.hardware_type || "ESP32_MODBUS_3P";
        const isCtOnly = hwType === "NODEMCU_CT_ONLY";
        const isThreePhase =
          hwType === "ESP32_MODBUS_3P" || hwType === "SCHNEIDER_PM2230";

        const newDevice: Device = {
          id: `dev-${Date.now()}`,
          organization_id: session.organization.id,
          machine_id: payload.machine_id || null,
          name: String(payload.name || "EcoNode Telemetry Gateway"),
          serial_number: String(
            payload.serial_number || `ESME-DEV-2026-${Math.floor(100 + Math.random() * 900)}`
          ),
          hardware_type: hwType,
          firmware_version: "v2.4.1-tls",
          phase_support: isThreePhase ? "THREE_PHASE" : "SINGLE_PHASE",
          measures_voltage: !isCtOnly,
          measures_power_factor: !isCtOnly,
          connection_protocol: payload.connection_protocol || "MQTT_TLS",
          status: isCtOnly ? "DEGRADED" : "ONLINE",
          last_heartbeat: new Date().toISOString(),
          last_transmission: new Date().toISOString(),
          data_completeness_pct: 100,
          is_simulated: true,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };

        const rawProvisionedToken = `esme_live_${Math.random()
          .toString(36)
          .slice(2, 10)}_${Date.now().toString(36)}`;

        db.devices.push(newDevice);
        db.device_credentials.push({
          id: `cred-${Date.now()}`,
          device_id: newDevice.id,
          organization_id: session.organization.id,
          key_prefix: rawProvisionedToken.slice(0, 14),
          key_hash: hashDeviceSecret(rawProvisionedToken),
          status: "ACTIVE",
          created_at: new Date().toISOString(),
          last_used_at: null,
        });

        if (payload.machine_id) {
          const linkedMachine = db.machines.find(
            (m) => m.id === payload.machine_id
          );
          if (linkedMachine) {
            linkedMachine.device_id = newDevice.id;
          }
        }

        appendAuditLog(db, {
          user_id: session.user.id,
          user_name: session.user.name,
          user_role: session.user.role,
          organization_id: session.organization.id,
          action: "IOT_DEVICE_PAIRED",
          target_record: `Device:${newDevice.id}`,
          metadata: {
            serial_number: newDevice.serial_number,
            hardware_type: newDevice.hardware_type,
            machine_id: newDevice.machine_id,
          },
        });
        saveDb(db);
        // Return the plaintext token ONCE upon provisioning
        return NextResponse.json({
          ok: true,
          device: newDevice,
          provisionedSecretOnce: rawProvisionedToken,
        });
      }

      case "SIMULATE_HEARTBEAT": {
        const dev = db.devices.find((d) => d.id === payload.device_id);
        if (!dev) {
          return NextResponse.json({ error: "Device not found" }, { status: 404 });
        }
        const now = new Date().toISOString();
        if (payload.mode === "DISCONNECT") {
          dev.status = "OFFLINE";
          const alertObj = {
            id: `alt-hb-${Date.now()}`,
            organization_id: dev.organization_id,
            machine_id: dev.machine_id,
            device_id: dev.id,
            severity: "CRITICAL" as const,
            status: "ACTIVE" as const,
            category: "DEVICE_DISCONNECTION" as const,
            title: `Device Disconnection: ${dev.name}`,
            description: `Simulated missed heartbeat on ${dev.serial_number}. Connection marked OFFLINE.`,
            rule_triggered: "heartbeat_timeout > 15m",
            threshold_value: "15 min",
            observed_value: "OFFLINE",
            created_at: now,
            acknowledged_at: null,
            resolved_at: null,
          };
          db.alerts.unshift(alertObj);
        } else {
          dev.status = dev.measures_voltage ? "ONLINE" : "DEGRADED";
          dev.last_heartbeat = now;
          dev.last_transmission = now;
        }
        appendAuditLog(db, {
          user_id: session.user.id,
          user_name: session.user.name,
          user_role: session.user.role,
          organization_id: session.organization.id,
          action:
            payload.mode === "DISCONNECT"
              ? "DEVICE_DISCONNECT_DETECTED"
              : "DEVICE_HEARTBEAT_VERIFIED",
          target_record: `Device:${dev.id}`,
          metadata: { status: dev.status },
        });
        saveDb(db);
        return NextResponse.json({ ok: true, device: dev });
      }

      case "UPDATE_ALERT_STATUS": {
        const alert = db.alerts.find((a) => a.id === payload.alert_id);
        if (!alert) {
          return NextResponse.json({ error: "Alert not found" }, { status: 404 });
        }
        const now = new Date().toISOString();
        if (payload.status === "ACKNOWLEDGED") {
          alert.status = "ACKNOWLEDGED";
          alert.acknowledged_at = now;
        } else if (payload.status === "RESOLVED") {
          alert.status = "RESOLVED";
          alert.resolved_at = now;
        }
        appendAuditLog(db, {
          user_id: session.user.id,
          user_name: session.user.name,
          user_role: session.user.role,
          organization_id: session.organization.id,
          action: `ALERT_${payload.status}`,
          target_record: `Alert:${alert.id}`,
          metadata: { title: alert.title },
        });
        saveDb(db);
        return NextResponse.json({ ok: true, alert });
      }

      case "UPDATE_THRESHOLDS": {
        const existing = db.alert_thresholds.find(
          (t) => t.organization_id === session.organization.id
        );
        if (existing) {
          existing.over_power_threshold_pct = Number(
            payload.over_power_threshold_pct ?? existing.over_power_threshold_pct
          );
          existing.spike_deviation_pct = Number(
            payload.spike_deviation_pct ?? existing.spike_deviation_pct
          );
          existing.min_power_factor = Number(
            payload.min_power_factor ?? existing.min_power_factor
          );
          existing.heartbeat_timeout_minutes = Number(
            payload.heartbeat_timeout_minutes ?? existing.heartbeat_timeout_minutes
          );
        }
        appendAuditLog(db, {
          user_id: session.user.id,
          user_name: session.user.name,
          user_role: session.user.role,
          organization_id: session.organization.id,
          action: "ALERT_THRESHOLDS_CONFIGURED",
          target_record: `AlertThresholdConfig:${session.organization.id}`,
          metadata: { ...payload },
        });
        saveDb(db);
        return NextResponse.json({ ok: true });
      }

      case "TOGGLE_CONSENT": {
        if (!hasRolePermission(session.user, ["IKM_OWNER", "ECOSME_ADMIN"])) {
          return NextResponse.json(
            { error: "Only the IKM Owner can grant or revoke data-sharing consent." },
            { status: 403 }
          );
        }
        const consent = db.data_sharing_consents.find(
          (c) =>
            c.id === payload.consent_id &&
            (c.organization_id === session.organization.id ||
              session.user.role === "ECOSME_ADMIN")
        );
        if (!consent) {
          return NextResponse.json(
            { error: "Consent record not found." },
            { status: 404 }
          );
        }
        const now = new Date().toISOString();
        if (consent.status === "ACTIVE") {
          consent.status = "REVOKED";
          consent.revoked_at = now;
          consent.access_logs.unshift({
            id: `cal-${Date.now()}`,
            timestamp: now,
            accessor_organization: session.organization.name,
            accessor_user: session.user.name,
            action: "Consent REVOKED by IKM Owner — Bank access immediately terminated",
          });
        } else {
          consent.status = "ACTIVE";
          consent.revoked_at = null;
          consent.granted_at = now;
          consent.access_logs.unshift({
            id: `cal-${Date.now()}`,
            timestamp: now,
            accessor_organization: session.organization.name,
            accessor_user: session.user.name,
            action: "Consent GRANTED by IKM Owner — Authorized Partner Bank access enabled",
          });
        }

        appendAuditLog(db, {
          user_id: session.user.id,
          user_name: session.user.name,
          user_role: session.user.role,
          organization_id: session.organization.id,
          action:
            consent.status === "ACTIVE" ? "CONSENT_GRANTED" : "CONSENT_REVOKED",
          target_record: `DataSharingConsent:${consent.id}`,
          metadata: {
            partner_bank: consent.partner_bank_name,
            new_status: consent.status,
          },
        });
        saveDb(db);
        return NextResponse.json({ ok: true, consent });
      }

      case "SUBMIT_FINANCING_APPLICATION": {
        if (!hasRolePermission(session.user, ["IKM_OWNER", "ECOSME_ADMIN"])) {
          return NextResponse.json({ error: "Forbidden" }, { status: 403 });
        }
        const app = db.financing_applications.find(
          (a) => a.organization_id === session.organization.id
        );
        const now = new Date().toISOString();
        if (app) {
          const prevStatus = app.status;
          app.project_title = String(payload.project_title || app.project_title);
          app.requested_amount_idr =
            Number(payload.requested_amount_idr) || app.requested_amount_idr;
          if (payload.status) {
            app.status = payload.status as ApplicationStatus;
          }
          app.updated_at = now;
          app.activities.unshift({
            id: `act-${Date.now()}`,
            timestamp: now,
            actor_name: session.user.name,
            actor_role: session.user.role,
            status_from: prevStatus,
            status_to: app.status,
            note: String(
              payload.note ||
                "Updated financing-readiness profile and project capital requirements."
            ),
          });
          appendAuditLog(db, {
            user_id: session.user.id,
            user_name: session.user.name,
            user_role: session.user.role,
            organization_id: session.organization.id,
            action: "FINANCING_PROFILE_UPDATED",
            target_record: `FinancingApplication:${app.id}`,
            metadata: {
              requested_amount_idr: app.requested_amount_idr,
              status: app.status,
            },
          });
          saveDb(db);
          return NextResponse.json({ ok: true, application: app });
        }
        return NextResponse.json({ error: "Application not found" }, { status: 404 });
      }

      case "BANK_UPDATE_APPLICATION_STATUS": {
        if (!hasRolePermission(session.user, ["BANK_OFFICER", "ECOSME_ADMIN"])) {
          return NextResponse.json(
            {
              error:
                "Credit Assessment Restriction: Only an authorized Partner Bank Officer can update financing review statuses. EcoSME never automatically approves or rejects loans.",
            },
            { status: 403 }
          );
        }
        const app = db.financing_applications.find(
          (a) => a.id === payload.application_id
        );
        if (!app) {
          return NextResponse.json(
            { error: "Financing application not found." },
            { status: 404 }
          );
        }

        // Verify active consent before bank can touch the application
        const consentCheck = canAccessOrganizationData(
          session.user,
          app.organization_id,
          db
        );
        if (!consentCheck.allowed) {
          return NextResponse.json({ error: consentCheck.reason }, { status: 403 });
        }

        const prevStatus = app.status;
        const nextStatus = payload.new_status as ApplicationStatus;
        const now = new Date().toISOString();
        app.status = nextStatus;
        if (payload.bank_reviewer_notes !== undefined) {
          app.bank_reviewer_notes = String(payload.bank_reviewer_notes);
        }
        app.updated_at = now;
        app.activities.unshift({
          id: `act-${Date.now()}`,
          timestamp: now,
          actor_name: session.user.name,
          actor_role: session.user.role,
          status_from: prevStatus,
          status_to: nextStatus,
          note: String(
            payload.review_note ||
              `Bank underwriting status updated from '${prevStatus}' to '${nextStatus}'.`
          ),
        });

        if (consentCheck.consent) {
          consentCheck.consent.access_logs.unshift({
            id: `cal-${Date.now()}`,
            timestamp: now,
            accessor_organization: session.organization.name,
            accessor_user: session.user.name,
            action: `Updated Financing Application ${app.id} status to '${nextStatus}'`,
          });
        }

        appendAuditLog(db, {
          user_id: session.user.id,
          user_name: session.user.name,
          user_role: session.user.role,
          organization_id: session.organization.id,
          action: "BANK_CREDIT_STATUS_DECISION",
          target_record: `FinancingApplication:${app.id}`,
          metadata: {
            ikm_organization_id: app.organization_id,
            status_from: prevStatus,
            status_to: nextStatus,
          },
        });
        saveDb(db);
        return NextResponse.json({ ok: true, application: app });
      }

      case "ADMIN_UPDATE_METHODOLOGY": {
        if (!hasRolePermission(session.user, ["ECOSME_ADMIN"])) {
          return NextResponse.json(
            { error: "Only EcoSME Administrators can modify Green Score methodology." },
            { status: 403 }
          );
        }
        const meth = db.green_score_methodologies[0];
        if (payload.weights) {
          meth.weights = {
            efficiency_improvement: Number(payload.weights.efficiency_improvement),
            consumption_stability: Number(payload.weights.consumption_stability),
            data_completeness: Number(payload.weights.data_completeness),
            sustainability_performance: Number(
              payload.weights.sustainability_performance
            ),
            monitoring_consistency: Number(payload.weights.monitoring_consistency),
          };
        }
        if (payload.thresholds) {
          meth.thresholds = {
            rating_a_min: Number(payload.thresholds.rating_a_min),
            rating_b_min: Number(payload.thresholds.rating_b_min),
            rating_c_min: Number(payload.thresholds.rating_c_min),
          };
        }
        if (payload.version) {
          meth.version = String(payload.version);
        }
        meth.updated_by = session.user.name;
        meth.updated_at = new Date().toISOString();

        // Recalculate PT Sinar Tekstil Mandiri's Green Score with updated methodology
        const updatedSinar = calculateGreenScore({
          organizationId: "org-ikm-sinar",
          assessmentPeriod: "Oct 11, 2026 – Nov 09, 2026",
          savingsPercentage: 14.48,
          loadVarianceCoefficientPct: 7.8,
          dataCompletenessPct: 98.2,
          truePowerMeterRatioPct: 80,
          co2ReductionRatioPct: 14.48,
          activeMonitoringDaysRatioPct: 100,
          methodology: meth,
        });
        db.green_scores[0] = updatedSinar;

        appendAuditLog(db, {
          user_id: session.user.id,
          user_name: session.user.name,
          user_role: session.user.role,
          organization_id: session.organization.id,
          action: "GREEN_SCORE_METHODOLOGY_UPDATED",
          target_record: `GreenScoreMethodology:${meth.id}`,
          metadata: {
            version: meth.version,
            recalculated_sinar_score: updatedSinar.overall_score,
          },
        });
        saveDb(db);
        return NextResponse.json({
          ok: true,
          methodology: meth,
          greenScore: updatedSinar,
        });
      }

      case "UPDATE_TARIFF_BASELINE": {
        if (!hasRolePermission(session.user, ["IKM_OWNER", "ECOSME_ADMIN"])) {
          return NextResponse.json({ error: "Forbidden" }, { status: 403 });
        }
        const tariff = db.electricity_tariffs.find(
          (t) => t.organization_id === session.organization.id
        );
        if (tariff && payload.rate_idr_per_kwh) {
          tariff.rate_idr_per_kwh = Number(payload.rate_idr_per_kwh);
          if (payload.effective_date) {
            tariff.effective_date = String(payload.effective_date);
          }
        }
        const baseline = db.energy_baselines.find(
          (b) => b.organization_id === session.organization.id
        );
        if (baseline && payload.baseline_energy_kwh) {
          baseline.baseline_energy_kwh = Number(payload.baseline_energy_kwh);
          baseline.updated_at = new Date().toISOString();
        }
        appendAuditLog(db, {
          user_id: session.user.id,
          user_name: session.user.name,
          user_role: session.user.role,
          organization_id: session.organization.id,
          action: "TARIFF_AND_BASELINE_UPDATED",
          target_record: `Organization:${session.organization.id}`,
          metadata: {
            rate_idr_per_kwh: tariff?.rate_idr_per_kwh ?? null,
            baseline_energy_kwh: baseline?.baseline_energy_kwh ?? null,
          },
        });
        saveDb(db);
        return NextResponse.json({ ok: true, tariff, baseline });
      }

      case "UPDATE_PERSONAL_COMPANY_PROFILE": {
        const usr = db.users.find((u) => u.id === session.user.id);
        const org = db.organizations.find((o) => o.id === session.organization.id);
        if (usr) {
          if (payload.personal_name) usr.name = String(payload.personal_name);
          if (payload.personal_title) usr.title = String(payload.personal_title);
          if (payload.personal_email) usr.email = String(payload.personal_email);
        }
        if (org) {
          if (payload.company_name) org.name = String(payload.company_name);
          if (payload.industry_category)
            org.industry_category = String(payload.industry_category);
          if (payload.tax_id_npwp) org.tax_id_npwp = String(payload.tax_id_npwp);
          if (payload.business_license_nib)
            org.business_license_nib = String(payload.business_license_nib);
          if (payload.address) org.address = String(payload.address);
          if (payload.pln_tariff_class)
            org.pln_tariff_class = String(payload.pln_tariff_class);
          if (payload.installed_capacity_kva)
            org.installed_capacity_kva = Number(payload.installed_capacity_kva);
        }
        appendAuditLog(db, {
          user_id: session.user.id,
          user_name: usr?.name ?? session.user.name,
          user_role: session.user.role,
          organization_id: session.organization.id,
          action: "PERSONAL_AND_COMPANY_PROFILE_UPDATED",
          target_record: `Organization:${session.organization.id}`,
          metadata: {
            personal_name: usr?.name ?? null,
            company_name: org?.name ?? null,
          },
        });
        saveDb(db);
        return NextResponse.json({ ok: true, user: usr, organization: org });
      }

      case "RESET_DEMO_DATA": {
        const fresh = resetDbToSeed();
        return NextResponse.json({ ok: true, state: fresh });
      }

      default:
        return NextResponse.json(
          { error: `Unknown action: ${action}` },
          { status: 400 }
        );
    }
  } catch (err) {
    console.error("Error in POST /api/state:", err);
    return NextResponse.json(
      { error: "Failed to process mutation request." },
      { status: 500 }
    );
  }
}
