"use client";

import React, { useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  Info,
  ShieldAlert,
  Sliders,
} from "lucide-react";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";
import { AlertSeverity } from "@/lib/types";
import { formatDateTime } from "@/lib/formatters";

export default function AlertsPage() {
  const { alerts, alertThresholds, mutateState } = useEcoSME();
  const [severityFilter, setSeverityFilter] = useState<AlertSeverity | "ALL">(
    "ALL"
  );
  const [overPowerPct, setOverPowerPct] = useState(
    alertThresholds?.over_power_threshold_pct ?? 115
  );
  const [spikePct, setSpikePct] = useState(
    alertThresholds?.spike_deviation_pct ?? 25
  );
  const [minPf, setMinPf] = useState(alertThresholds?.min_power_factor ?? 0.85);
  const [savedNotice, setSavedNotice] = useState(false);

  const filteredAlerts =
    severityFilter === "ALL"
      ? alerts
      : alerts.filter((a) => a.severity === severityFilter);

  const handleSaveThresholds = async (e: React.FormEvent) => {
    e.preventDefault();
    await mutateState("UPDATE_THRESHOLDS", {
      over_power_threshold_pct: overPowerPct,
      spike_deviation_pct: spikePct,
      min_power_factor: minPf,
    });
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2500);
  };

  return (
    <PortalShell
      portalType="IKM"
      title="Energy Alerts & Deterministic Anomaly Detection"
      subtitle="Transparent threshold-based detection for abnormal power draw, shift spikes, low power factor, and missing sensor data."
    >
      {/* Transparency Note */}
      <div className="ecosme-card p-4 mb-6 bg-slate-50 border-slate-200 flex items-start gap-3">
        <Info className="h-5 w-5 text-[#123B2A] shrink-0 mt-0.5" />
        <p className="text-xs text-slate-700 leading-relaxed">
          <strong className="text-[#123B2A]">
            Transparent Rule Engine (No Black-Box AI Claims):
          </strong>{" "}
          All alerts in EcoSME are triggered by deterministic electrical engineering rules configured below (rated capacity thresholds, rolling baseline deviations, PLN <code className="font-mono">cos φ ≥ 0.85</code> limits, and device heartbeat timeouts).
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Alert Stream */}
        <div className="lg:col-span-8 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 bg-white p-1 rounded-xl border border-[#DDE5DF] text-xs">
              {(["ALL", "CRITICAL", "WARNING", "INFORMATIONAL"] as const).map(
                (sev) => (
                  <button
                    key={sev}
                    type="button"
                    onClick={() => setSeverityFilter(sev)}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                      severityFilter === sev
                        ? "bg-[#123B2A] text-white"
                        : "text-slate-600 hover:bg-slate-100"
                    }`}
                  >
                    {sev}
                  </button>
                )
              )}
            </div>
          </div>

          <div className="space-y-3">
            {filteredAlerts.map((alt) => (
              <div
                key={alt.id}
                className="ecosme-card p-5 space-y-3 border-l-4"
                style={{
                  borderLeftColor:
                    alt.severity === "CRITICAL"
                      ? "#DC2626"
                      : alt.severity === "WARNING"
                      ? "#D97706"
                      : "#2563EB",
                }}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span
                      className={`rounded px-2 py-0.5 text-[10px] font-bold uppercase ${
                        alt.severity === "CRITICAL"
                          ? "bg-red-100 text-red-900"
                          : alt.severity === "WARNING"
                          ? "bg-amber-100 text-amber-900"
                          : "bg-blue-100 text-blue-900"
                      }`}
                    >
                      {alt.severity}
                    </span>
                    <span className="text-xs font-mono text-slate-500">
                      {alt.category}
                    </span>
                    <span
                      className={`rounded px-2 py-0.5 text-[10px] font-bold ${
                        alt.status === "ACTIVE"
                          ? "bg-amber-100 text-amber-900"
                          : alt.status === "ACKNOWLEDGED"
                          ? "bg-blue-50 text-blue-800"
                          : "bg-emerald-100 text-emerald-900"
                      }`}
                    >
                      {alt.status}
                    </span>
                  </div>
                  <span className="text-xs text-slate-500">
                    {formatDateTime(alt.created_at)}
                  </span>
                </div>

                <div>
                  <h3 className="text-sm font-bold text-[#123B2A]">
                    {alt.title}
                  </h3>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    {alt.description}
                  </p>
                </div>

                <div className="rounded-lg bg-[#F5F8F6] p-3 grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                  <div>
                    <span className="text-slate-500 block text-[10px]">
                      Rule Triggered
                    </span>
                    <code className="font-mono text-[11px] font-semibold text-slate-800">
                      {alt.rule_triggered}
                    </code>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">
                      Configured Threshold
                    </span>
                    <span className="font-semibold text-slate-800">
                      {alt.threshold_value}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">
                      Observed Value
                    </span>
                    <span className="font-bold text-red-700">
                      {alt.observed_value}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-1">
                  {alt.status === "ACTIVE" && (
                    <button
                      type="button"
                      onClick={() =>
                        mutateState("UPDATE_ALERT_STATUS", {
                          alert_id: alt.id,
                          status: "ACKNOWLEDGED",
                        })
                      }
                      className="px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700"
                    >
                      Acknowledge
                    </button>
                  )}
                  {alt.status !== "RESOLVED" && (
                    <button
                      type="button"
                      onClick={() =>
                        mutateState("UPDATE_ALERT_STATUS", {
                          alert_id: alt.id,
                          status: "RESOLVED",
                        })
                      }
                      className="px-3 py-1.5 rounded-lg bg-[#123B2A] hover:bg-[#0D2B1E] text-white text-xs font-semibold"
                    >
                      Mark Resolved
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Configurable Threshold Rules */}
        <div className="lg:col-span-4">
          <form
            onSubmit={handleSaveThresholds}
            className="ecosme-card p-5 space-y-4 text-xs"
          >
            <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
              <Sliders className="h-4 w-4 text-[#16A36A]" />
              <h2 className="text-sm font-bold text-[#123B2A]">
                Configurable Detection Thresholds
              </h2>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Over-Rated Power Limit (% of Machine Rated kW)
              </label>
              <input
                type="number"
                value={overPowerPct}
                onChange={(e) => setOverPowerPct(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-semibold"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                Triggers CRITICAL alert when active power exceeds {overPowerPct}% of rated capacity.
              </p>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Rolling Baseline Spike Deviation (%)
              </label>
              <input
                type="number"
                value={spikePct}
                onChange={(e) => setSpikePct(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-semibold"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                Triggers WARNING alert when shift power jumps &gt;{spikePct}% above rolling average.
              </p>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Minimum Power Factor (PLN kVArh Threshold)
              </label>
              <input
                type="number"
                step="0.01"
                value={minPf}
                onChange={(e) => setMinPf(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-semibold"
              />
            </div>

            <button
              type="submit"
              className="w-full rounded-lg bg-[#123B2A] hover:bg-[#0D2B1E] text-white py-2.5 font-semibold transition-colors"
            >
              Save Threshold Rules
            </button>

            {savedNotice && (
              <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-2.5 text-emerald-900 font-medium text-center">
                Threshold rules updated and logged to Audit Trail.
              </div>
            )}
          </form>
        </div>
      </div>
    </PortalShell>
  );
}
