"use client";

import React, { useState } from "react";
import {
  AlertTriangle,
  Calculator,
  CheckCircle2,
  Download,
  PiggyBank,
} from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";
import { DataClassificationBadge } from "@/components/DataClassificationBadge";
import { calculateEnergySavings, calculateESaaSShare } from "@/lib/calculations";
import { formatIdr, formatNumber } from "@/lib/formatters";
import { downloadEcoSMEReportPdf } from "@/lib/pdf-generator";

export default function EnergySavingsPage() {
  const {
    organization,
    machines,
    baselines,
    tariffs,
    savingsRecords,
    greenScore,
    emissionFactors,
    applications,
  } = useEcoSME();

  const baselineObj = baselines[0];
  const tariffRate = tariffs[0]?.rate_idr_per_kwh ?? 1444.7;

  const [normalizeEnabled, setNormalizeEnabled] = useState<boolean>(false);
  const [actualHours, setActualHours] = useState<number>(456);
  const [actualProdUnits, setActualProdUnits] = useState<number>(34800);

  const current30dKwh = 41820;

  const calc = calculateEnergySavings({
    rawBaselineKwh: baselineObj?.baseline_energy_kwh ?? 48900,
    currentConsumptionKwh: current30dKwh,
    tariffIdrPerKwh: tariffRate,
    baselineOperatingHours: baselineObj?.baseline_operating_hours ?? 448,
    actualOperatingHours: actualHours,
    baselineProductionUnits: baselineObj?.baseline_production_units ?? 34000,
    actualProductionUnits: actualProdUnits,
    normalizeByOperatingConditions: normalizeEnabled,
    hasMeterVerification: true,
  });

  // 95% of facility consumption is on the 4 true V*I*PF metered machines (VERIFIED)
  // 5% is on the WWTP Pump #2 with current-only CT sensor (ESTIMATED — never billed under ESaaS)
  const verifiedSavingsKwh = Math.round(calc.energySavingsKwh * 0.95 * 10) / 10;
  const estimatedSavingsKwh =
    Math.round((calc.energySavingsKwh - verifiedSavingsKwh) * 10) / 10;

  const verifiedMonetaryIdr = Math.round(verifiedSavingsKwh * tariffRate);
  const estimatedMonetaryIdr = Math.round(estimatedSavingsKwh * tariffRate);

  const esaasOnVerified = calculateESaaSShare(verifiedMonetaryIdr, "VERIFIED", 30);

  return (
    <PortalShell
      portalType="IKM"
      title="Normalized Energy Savings & ESaaS Verification"
      subtitle="Transparent comparison of baseline vs. actual electricity consumption with strict separation of VERIFIED and ESTIMATED savings."
    >
      {/* Top Action & Normalization Controls */}
      <div className="ecosme-card p-5 mb-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
          <div className="flex items-center gap-2.5">
            <Calculator className="h-5 w-5 text-[#16A36A]" />
            <div>
              <h2 className="text-sm font-bold text-[#123B2A]">
                Baseline Normalization &amp; Operating Condition Controls
              </h2>
              <p className="text-xs text-slate-600">
                Baseline Period: <strong>{baselineObj?.period_label}</strong> • Applicable Tariff:{" "}
                <strong>{formatIdr(tariffRate)}/kWh</strong> (Effective {tariffs[0]?.effective_date})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <label className="inline-flex items-center gap-2 text-xs font-semibold text-[#123B2A] cursor-pointer">
              <input
                type="checkbox"
                checked={normalizeEnabled}
                onChange={(e) => setNormalizeEnabled(e.target.checked)}
                className="rounded border-slate-300 text-[#123B2A] focus:ring-[#16A36A]"
              />
              Enable Operating Hours &amp; Production Volume Normalization
            </label>

            <button
              type="button"
              onClick={() =>
                downloadEcoSMEReportPdf({
                  reportType: "ENERGY_SAVINGS",
                  organization,
                  reportingPeriod: "Oct 11, 2026 – Nov 09, 2026 (30d)",
                  tariffIdrPerKwh: tariffRate,
                  totalEnergyKwh: current30dKwh,
                  baselineEnergyKwh: calc.adjustedBaselineKwh,
                  verifiedSavingsKwh,
                  estimatedSavingsKwh,
                  greenScore,
                  emissionFactor: emissionFactors[0],
                  machines,
                  financingApplication: applications[0],
                })
              }
              className="inline-flex items-center gap-1.5 rounded-lg bg-[#123B2A] hover:bg-[#0D2B1E] text-white px-3.5 py-2 text-xs font-semibold"
            >
              <Download className="h-3.5 w-3.5 text-[#16A36A]" />
              Download Savings PDF
            </button>
          </div>
        </div>

        {normalizeEnabled && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-1 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Actual Operating Hours (Baseline: {baselineObj?.baseline_operating_hours}h)
              </label>
              <input
                type="number"
                value={actualHours}
                onChange={(e) => setActualHours(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-1.5 font-semibold"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Actual Production Output Units (Baseline:{" "}
                {formatNumber(baselineObj?.baseline_production_units ?? 34000)})
              </label>
              <input
                type="number"
                step={500}
                value={actualProdUnits}
                onChange={(e) => setActualProdUnits(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-1.5 font-semibold"
              />
            </div>
            <div className="rounded-lg bg-[#E8F7F0] p-3 border border-[#16A36A]/30">
              <span className="text-[11px] font-semibold text-[#123B2A] block">
                Normalization Factor Applied
              </span>
              <span className="text-base font-bold text-[#123B2A]">
                ×{calc.normalizationFactor.toFixed(3)} → {formatNumber(calc.adjustedBaselineKwh, 0)} kWh
              </span>
            </div>
          </div>
        )}
      </div>

      {/* KPI Comparison Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="ecosme-card p-5 space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">
              Adjusted Baseline (30d)
            </span>
            <DataClassificationBadge type="MEASURED_DEMO" customLabel="BASELINE" />
          </div>
          <p className="text-2xl font-bold text-[#123B2A]">
            {formatNumber(calc.adjustedBaselineKwh, 0)} kWh
          </p>
          <p className="text-[11px] text-slate-500">
            Baseline Cost: {formatIdr(calc.baselineCostIdr)}
          </p>
        </div>

        <div className="ecosme-card p-5 space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">
              Current Consumption (30d)
            </span>
            <DataClassificationBadge type="MEASURED_DEMO" />
          </div>
          <p className="text-2xl font-bold text-[#123B2A]">
            {formatNumber(calc.currentConsumptionKwh, 0)} kWh
          </p>
          <p className="text-[11px] text-slate-500">
            Current Cost: {formatIdr(calc.currentCostIdr)}
          </p>
        </div>

        <div className="ecosme-card p-5 space-y-1.5 border-emerald-300 bg-[#E8F7F0]/40">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#123B2A]">
              Verified Savings (95% Metered)
            </span>
            <DataClassificationBadge type="VERIFIED" />
          </div>
          <p className="text-2xl font-bold text-[#16A36A]">
            {formatIdr(verifiedMonetaryIdr)}
          </p>
          <p className="text-[11px] text-[#123B2A] font-medium">
            {formatNumber(verifiedSavingsKwh, 1)} kWh saved on 4 Class-1 meters
          </p>
        </div>

        <div className="ecosme-card p-5 space-y-1.5 border-amber-300 bg-amber-50/40">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-950">
              Estimated Savings (5% CT-Only)
            </span>
            <DataClassificationBadge type="ESTIMATED" />
          </div>
          <p className="text-2xl font-bold text-amber-900">
            {formatIdr(estimatedMonetaryIdr)}
          </p>
          <p className="text-[11px] text-amber-800">
            {formatNumber(estimatedSavingsKwh, 1)} kWh on WWTP Pump #2 (Excluded from ESaaS)
          </p>
        </div>
      </div>

      {/* Formula Transparency + Monthly Trend */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-6">
        <div className="lg:col-span-7 ecosme-card p-5 space-y-4">
          <h2 className="text-base font-bold text-[#123B2A]">
            Monthly Monetary Savings &amp; ESaaS Retention Trend (IDR)
          </h2>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={savingsRecords}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis dataKey="period_month" tick={{ fontSize: 11, fill: "#4B5563" }} />
                <YAxis tick={{ fontSize: 11, fill: "#4B5563" }} />
                <Tooltip />
                <Bar
                  dataKey="ikm_retained_savings_idr"
                  name="IKM Retained Savings (IDR)"
                  fill="#123B2A"
                  radius={[4, 4, 0, 0]}
                />
                <Bar
                  dataKey="esaas_fee_idr"
                  name="EcoSME 30% Verified ESaaS Fee (IDR)"
                  fill="#16A36A"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="lg:col-span-5 ecosme-card p-5 space-y-3 text-xs">
          <h2 className="text-base font-bold text-[#123B2A]">
            Transparent Calculation Formulas &amp; ESaaS Policy
          </h2>
          <div className="rounded-lg bg-[#F5F8F6] p-3.5 border border-[#DDE5DF] space-y-2 font-mono text-[11px]">
            <p>1. Electricity Cost = kWh × Tariff ({formatIdr(tariffRate)}/kWh)</p>
            <p>
              2. Energy Savings = Adjusted Baseline ({formatNumber(calc.adjustedBaselineKwh, 0)} kWh) − Current ({formatNumber(calc.currentConsumptionKwh, 0)} kWh) ={" "}
              <strong>{formatNumber(calc.energySavingsKwh, 1)} kWh</strong>
            </p>
            <p>
              3. Savings (%) = ({formatNumber(calc.energySavingsKwh, 1)} /{" "}
              {formatNumber(calc.adjustedBaselineKwh, 0)}) × 100 ={" "}
              <strong>{calc.savingsPercentage}%</strong>
            </p>
            <p>
              4. Monetary Savings = {formatNumber(calc.energySavingsKwh, 1)} ×{" "}
              {tariffRate} = <strong>{formatIdr(calc.monetarySavingsIdr)}</strong>
            </p>
          </div>

          <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-3.5 space-y-1.5">
            <p className="font-bold text-[#123B2A]">
              ESaaS Settlement Breakdown (30% Verified Share):
            </p>
            <p className="text-slate-700">
              • Verified Savings Base: <strong>{formatIdr(verifiedMonetaryIdr)}</strong>
            </p>
            <p className="text-slate-700">
              • EcoSME 30% Service Share:{" "}
              <strong>{formatIdr(esaasOnVerified.ecosmeFeeIdr)}</strong>
            </p>
            <p className="text-slate-700">
              • IKM Net Retained Savings:{" "}
              <strong>
                {formatIdr(
                  esaasOnVerified.ikmRetainedSavingsIdr + estimatedMonetaryIdr
                )}
              </strong>{" "}
              (100% of estimated CT savings + 70% of verified savings)
            </p>
          </div>
        </div>
      </div>
    </PortalShell>
  );
}
