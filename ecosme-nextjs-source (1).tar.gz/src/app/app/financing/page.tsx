"use client";

import React, { useState } from "react";
import {
  CheckCircle2,
  Download,
  FileCheck,
  History,
  Landmark,
  Lock,
  ShieldAlert,
  ShieldCheck,
  Unlock,
} from "lucide-react";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";
import { formatDateTime, formatIdr, formatNumber } from "@/lib/formatters";
import { downloadEcoSMEReportPdf } from "@/lib/pdf-generator";

export default function FinancingGatewayPage() {
  const {
    organization,
    machines,
    tariffs,
    emissionFactors,
    greenScore,
    consents,
    applications,
    mutateState,
  } = useEcoSME();

  const app = applications[0];
  const consent = consents[0];

  const [projectTitle, setProjectTitle] = useState(
    app?.project_title ??
      "Phase II: High-Efficiency IE4 Dyeing Motors & Exhaust Heat Recovery"
  );
  const [requestedAmount, setRequestedAmount] = useState(
    app?.requested_amount_idr ?? 450000000
  );
  const [submissionNote, setSubmissionNote] = useState("");
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleUpdateApplication = async (e: React.FormEvent) => {
    e.preventDefault();
    await mutateState("SUBMIT_FINANCING_APPLICATION", {
      project_title: projectTitle,
      requested_amount_idr: requestedAmount,
      status: app?.status === "Draft" ? "Submitted" : app?.status,
      note:
        submissionNote ||
        "Updated financing-readiness package and project capital specification.",
    });
    setSubmissionNote("");
    setFeedback("Financing-readiness package updated and logged.");
    setTimeout(() => setFeedback(null), 3000);
  };

  const handleToggleConsent = async () => {
    if (!consent) return;
    await mutateState("TOGGLE_CONSENT", { consent_id: consent.id });
  };

  return (
    <PortalShell
      portalType="IKM"
      title="Green Finance Gateway & Consent Manager"
      subtitle="Prepare standardized green financing dossiers, manage explicit bank data-sharing consent, and track partner bank review status."
    >
      {/* Mandatory Non-Lender Positioning Banner */}
      <div className="ecosme-card p-4 mb-6 bg-slate-900 text-white flex items-start justify-between gap-4 flex-wrap">
        <div className="flex items-start gap-3 max-w-4xl">
          <ShieldAlert className="h-5 w-5 text-[#16A36A] shrink-0 mt-0.5" />
          <div className="text-xs text-slate-200 space-y-1 leading-relaxed">
            <p className="font-bold text-white">
              Critical Financial Governance &amp; Privacy Notice
            </p>
            <p>
              EcoSME prepares technical energy-performance and Provisional Green Score readiness dossiers.{" "}
              <strong>
                EcoSME never automatically approves or rejects loans. All credit underwriting and financing decisions belong exclusively to the partner financial institution.
              </strong>{" "}
              Partner banks can only view your profile while your explicit Data-Sharing Consent below is set to{" "}
              <span className="text-emerald-400 font-bold">ACTIVE</span>.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() =>
            downloadEcoSMEReportPdf({
              reportType: "FINANCING_READINESS",
              organization,
              reportingPeriod: greenScore.assessment_period,
              tariffIdrPerKwh: tariffs[0]?.rate_idr_per_kwh ?? 1444.7,
              totalEnergyKwh: 41820,
              baselineEnergyKwh: 48900,
              verifiedSavingsKwh: 6726,
              estimatedSavingsKwh: 354,
              greenScore,
              emissionFactor: emissionFactors[0],
              machines,
              financingApplication: app,
            })
          }
          className="inline-flex items-center gap-1.5 rounded-lg bg-[#16A36A] hover:bg-emerald-500 text-white px-4 py-2 text-xs font-semibold shrink-0"
        >
          <Download className="h-4 w-4" />
          Download Financing Readiness Dossier (PDF)
        </button>
      </div>

      {/* Top Row: Readiness Summary & Explicit Consent Control */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-6">
        {/* Explicit Data-Sharing Consent Card */}
        <div className="lg:col-span-6 ecosme-card p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <div className="flex items-center gap-2">
              {consent?.status === "ACTIVE" ? (
                <ShieldCheck className="h-5 w-5 text-[#16A36A]" />
              ) : (
                <Lock className="h-5 w-5 text-red-600" />
              )}
              <h2 className="text-base font-bold text-[#123B2A]">
                Explicit Data-Sharing Consent Control
              </h2>
            </div>
            <span
              className={`rounded-md px-2.5 py-0.5 text-xs font-bold uppercase ${
                consent?.status === "ACTIVE"
                  ? "bg-emerald-100 text-emerald-900"
                  : "bg-red-100 text-red-900"
              }`}
            >
              {consent?.status ?? "NONE"}
            </span>
          </div>

          <div className="rounded-lg bg-[#F5F8F6] p-4 border border-[#DDE5DF] space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-500">Authorized Partner Bank:</span>
              <span className="font-bold text-[#14243A]">
                {consent?.partner_bank_name}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Authorized By:</span>
              <span className="font-medium text-slate-800">
                {consent?.granted_by_name} ({formatDateTime(consent?.granted_at)})
              </span>
            </div>
            <p className="text-slate-600 pt-1 leading-relaxed">
              {consent?.purpose_statement}
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <div className="text-xs text-slate-600">
              {consent?.status === "ACTIVE"
                ? "Partner bank currently has read-only access to your Green Score & energy reports."
                : "Consent is REVOKED. Your IKM profile is hidden from the Partner Bank Portal."}
            </div>

            <button
              type="button"
              onClick={handleToggleConsent}
              className={`inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold transition-colors ${
                consent?.status === "ACTIVE"
                  ? "bg-red-600 hover:bg-red-700 text-white"
                  : "bg-[#16A36A] hover:bg-emerald-600 text-white"
              }`}
            >
              {consent?.status === "ACTIVE" ? (
                <>
                  <Lock className="h-3.5 w-3.5" /> Revoke Bank Consent Immediately
                </>
              ) : (
                <>
                  <Unlock className="h-3.5 w-3.5" /> Grant Explicit Bank Consent
                </>
              )}
            </button>
          </div>

          {/* Access History Log */}
          <div className="pt-3 border-t border-slate-200 space-y-2">
            <h3 className="text-xs font-bold text-[#123B2A] flex items-center gap-1.5">
              <History className="h-3.5 w-3.5 text-[#16A36A]" />
              Consent &amp; Bank Access Audit History
            </h3>
            <div className="max-h-36 overflow-y-auto space-y-1.5 text-[11px]">
              {consent?.access_logs.map((log) => (
                <div
                  key={log.id}
                  className="rounded bg-slate-50 border border-slate-200 px-3 py-1.5 flex items-center justify-between gap-2"
                >
                  <span className="text-slate-700">
                    <strong>{log.accessor_user}:</strong> {log.action}
                  </span>
                  <span className="text-slate-400 font-mono shrink-0">
                    {formatDateTime(log.timestamp)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Application Status & Required Documents Checklist */}
        <div className="lg:col-span-6 ecosme-card p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <div>
              <span className="text-[11px] font-mono font-bold text-[#16A36A]">
                Application #{app?.id}
              </span>
              <h2 className="text-base font-bold text-[#123B2A]">
                Financing Readiness &amp; Underwriting Status
              </h2>
            </div>
            <span className="rounded-lg bg-blue-100 text-blue-900 px-3 py-1 text-xs font-bold">
              {app?.status}
            </span>
          </div>

          {/* Status Stepper */}
          <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
            {(
              [
                "Draft",
                "Submitted",
                "Under Review",
                "Additional Information Required",
                "Approved by Bank",
                "Disbursed",
              ] as const
            ).map((step) => {
              const isCurrent = app?.status === step;
              return (
                <span
                  key={step}
                  className={`rounded-md px-2 py-1 font-semibold border ${
                    isCurrent
                      ? "bg-[#123B2A] text-white border-[#123B2A]"
                      : "bg-slate-50 text-slate-500 border-slate-200"
                  }`}
                >
                  {step}
                </span>
              );
            })}
          </div>

          <div className="rounded-lg bg-[#F5F8F6] p-3.5 border border-[#DDE5DF] text-xs space-y-1.5">
            <span className="font-bold text-[#14243A] block">
              Latest Partner Bank Underwriting Note:
            </span>
            <p className="text-slate-700 leading-relaxed">
              {app?.bank_reviewer_notes}
            </p>
          </div>

          {/* Required Documents Checklist */}
          <div className="space-y-2 pt-1 text-xs">
            <h3 className="font-bold text-[#123B2A]">
              Required Readiness Documents Checklist:
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {[
                {
                  label: "Business License (NIB / OSS)",
                  ok: app?.documents_Checklist.company_registration_nib,
                },
                {
                  label: "NPWP Tax Compliance",
                  ok: app?.documents_Checklist.npwp_tax_compliance,
                },
                {
                  label: "6-Month PLN Utility Invoices",
                  ok: app?.documents_Checklist.pln_electricity_bills_6m,
                },
                {
                  label: "EcoSME Provisional Green Score Report",
                  ok: app?.documents_Checklist.ecosme_green_score_report,
                },
                {
                  label: "Equipment Vendor Technical Quotation",
                  ok: app?.documents_Checklist.equipment_vendor_quotation,
                },
              ].map((docItem) => (
                <div
                  key={docItem.label}
                  className="flex items-center gap-2 rounded bg-white border border-slate-200 px-3 py-2"
                >
                  <CheckCircle2
                    className={`h-4 w-4 shrink-0 ${
                      docItem.ok ? "text-[#16A36A]" : "text-slate-300"
                    }`}
                  />
                  <span className="text-slate-800 font-medium">
                    {docItem.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Row: Edit Financing Profile + Activity Log */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <form
          onSubmit={handleUpdateApplication}
          className="lg:col-span-6 ecosme-card p-6 space-y-4 text-xs"
        >
          <h2 className="text-base font-bold text-[#123B2A]">
            Update Green Financing Project Specification
          </h2>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Energy Efficiency Capex Project Title
            </label>
            <input
              type="text"
              required
              value={projectTitle}
              onChange={(e) => setProjectTitle(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 font-medium"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Requested Green Financing (IDR)
              </label>
              <input
                type="number"
                step={10000000}
                required
                value={requestedAmount}
                onChange={(e) => setRequestedAmount(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-bold text-[#123B2A]"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Projected Annual Savings (IDR)
              </label>
              <input
                type="text"
                disabled
                value={formatIdr(app?.estimated_annual_savings_idr ?? 122741712)}
                className="w-full rounded-lg border border-slate-200 bg-slate-100 px-3 py-2 font-semibold text-emerald-800"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Submission / Update Note for Partner Bank
            </label>
            <input
              type="text"
              placeholder="e.g., Attached updated IE4 motor quotation from supplier..."
              value={submissionNote}
              onChange={(e) => setSubmissionNote(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2"
            />
          </div>

          <button
            type="submit"
            className="w-full rounded-lg bg-[#123B2A] hover:bg-[#0D2B1E] text-white py-2.5 font-semibold transition-colors"
          >
            Save &amp; Synchronize Readiness Profile
          </button>

          {feedback && (
            <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-2.5 text-emerald-900 font-medium text-center">
              {feedback}
            </div>
          )}
        </form>

        {/* Application Activity Timeline */}
        <div className="lg:col-span-6 ecosme-card p-6 space-y-4 text-xs">
          <h2 className="text-base font-bold text-[#123B2A]">
            Application Review &amp; Activity Timeline
          </h2>
          <div className="space-y-3">
            {app?.activities.map((act) => (
              <div
                key={act.id}
                className="rounded-lg bg-[#F5F8F6] border border-[#DDE5DF] p-3.5 space-y-1"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#123B2A]">
                    {act.actor_name} ({act.actor_role})
                  </span>
                  <span className="font-mono text-[11px] text-slate-500">
                    {formatDateTime(act.timestamp)}
                  </span>
                </div>
                <p className="text-[11px] font-semibold text-[#16A36A]">
                  Status Transition: {act.status_from ?? "Initial"} →{" "}
                  {act.status_to}
                </p>
                <p className="text-slate-700">{act.note}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </PortalShell>
  );
}
