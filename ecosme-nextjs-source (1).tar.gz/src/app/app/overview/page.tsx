"use client";

import React, { useMemo, useState } from "react";
import Link from "next/link";
import {
  AlertTriangle,
  ArrowRight,
  Award,
  CheckCircle2,
  Cpu,
  Download,
  Leaf,
  PiggyBank,
  Zap,
} from "lucide-react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";
import { DataClassificationBadge } from "@/components/DataClassificationBadge";
import {
  calculateCarbonFootprint,
  calculateElectricityCost,
  calculateEnergySavings,
} from "@/lib/calculations";
import { formatIdr, formatNumber } from "@/lib/formatters";
import { downloadEcoSMEReportPdf } from "@/lib/pdf-generator";

type TimeFilter = "TODAY" | "7D" | "30D" | "CUSTOM";

export default function IkmOverviewPage() {
  const {
    organization,
    machines,
    devices,
    readings,
    baselines,
    tariffs,
    emissionFactors,
    greenScore,
    alerts,
    applications,
  } = useEcoSME();

  const [timeFilter, setTimeFilter] = useState<TimeFilter>("30D");
  const [customDays, setCustomDays] = useState<number>(14);

  const activeTariff = tariffs[0]?.rate_idr_per_kwh ?? 1444.7;
  const activeBaseline = baselines[0]?.baseline_energy_kwh ?? 48900;
  const emissionFactor = emissionFactors[0];

  // Aggregate daily readings deterministically
  const dailySeries = useMemo(() => {
    const map = new Map<
      string,
      {
        date_label: string;
        timestamp: string;
        totalKwh: number;
        verifiedMeterKwh: number;
        estimatedCtKwh: number;
      }
    >();

    for (const r of readings) {
      const existing = map.get(r.date_label) ?? {
        date_label: r.date_label,
        timestamp: r.timestamp,
        totalKwh: 0,
        verifiedMeterKwh: 0,
        estimatedCtKwh: 0,
      };
      existing.totalKwh += r.energy_kwh;
      if (r.classification === "ESTIMATED") {
        existing.estimatedCtKwh += r.energy_kwh;
      } else {
        existing.verifiedMeterKwh += r.energy_kwh;
      }
      map.set(r.date_label, existing);
    }

    const allDays = Array.from(map.values()).map((d) => ({
      ...d,
      totalKwh: Math.round(d.totalKwh * 10) / 10,
      baselineDayKwh: Math.round((activeBaseline / 30) * 10) / 10,
      costIdr: Math.round(d.totalKwh * activeTariff),
    }));

    if (timeFilter === "TODAY") return allDays.slice(-1);
    if (timeFilter === "7D") return allDays.slice(-7);
    if (timeFilter === "CUSTOM")
      return allDays.slice(-Math.max(1, Math.min(30, customDays)));
    return allDays;
  }, [readings, timeFilter, customDays, activeBaseline, activeTariff]);

  const periodDaysCount = dailySeries.length || 1;
  const periodTotalKwh = useMemo(
    () =>
      Math.round(
        dailySeries.reduce((sum, d) => sum + d.totalKwh, 0) * 10
      ) / 10,
    [dailySeries]
  );

  const periodBaselineKwh = Math.round(
    (activeBaseline / 30) * periodDaysCount * 10
  ) / 10;

  const estimatedCostIdr = calculateElectricityCost(
    periodTotalKwh,
    activeTariff
  );

  const savingsResult = calculateEnergySavings({
    rawBaselineKwh: periodBaselineKwh,
    currentConsumptionKwh: periodTotalKwh,
    tariffIdrPerKwh: activeTariff,
    normalizeByOperatingConditions: false,
    hasMeterVerification: true,
  });

  // 95% of consumption is on the 4 true active-power meters (VERIFIED), 5% on WWTP CT-only sensor (ESTIMATED)
  const verifiedSavingsKwh = Math.round(savingsResult.energySavingsKwh * 0.95);
  const estimatedSavingsKwh =
    Math.round((savingsResult.energySavingsKwh - verifiedSavingsKwh) * 10) / 10;
  const verifiedSavingsIdr = calculateElectricityCost(
    verifiedSavingsKwh,
    activeTariff
  );
  const estimatedSavingsIdr = calculateElectricityCost(
    estimatedSavingsKwh,
    activeTariff
  );

  const carbonResult = calculateCarbonFootprint(
    periodTotalKwh,
    savingsResult.energySavingsKwh,
    emissionFactor
  );

  const onlineMachines = machines.filter((m) => m.status === "ONLINE").length;
  const activeAlerts = alerts.filter((a) => a.status === "ACTIVE");

  return (
    <PortalShell
      portalType="IKM"
      title="IKM Energy & Sustainability Overview"
      subtitle="Consolidated operational energy consumption, cost, verified vs. estimated savings, and Green Score readiness."
    >
      {/* Top Controls & Time Range Filter */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div className="flex flex-wrap items-center gap-1.5 bg-white p-1 rounded-xl border border-[#DDE5DF]">
          {(
            [
              { id: "TODAY", label: "Today (24h)" },
              { id: "7D", label: "Last 7 Days" },
              { id: "30D", label: "Last 30 Days" },
              { id: "CUSTOM", label: "Custom Range" },
            ] as Array<{ id: TimeFilter; label: string }>
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setTimeFilter(tab.id)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                timeFilter === tab.id
                  ? "bg-[#123B2A] text-white"
                  : "text-slate-600 hover:bg-slate-100"
              }`}
            >
              {tab.label}
            </button>
          ))}
          {timeFilter === "CUSTOM" && (
            <div className="flex items-center gap-1.5 px-2">
              <label htmlFor="custom-days-input" className="text-xs text-slate-600">
                Days:
              </label>
              <input
                id="custom-days-input"
                type="number"
                min={2}
                max={30}
                value={customDays}
                onChange={(e) => setCustomDays(Number(e.target.value))}
                className="w-14 rounded border border-slate-300 px-2 py-0.5 text-xs font-semibold"
              />
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={() =>
            downloadEcoSMEReportPdf({
              reportType: "ENERGY_CONSUMPTION",
              organization,
              reportingPeriod: `Last ${periodDaysCount} Day(s) — Oct/Nov 2026`,
              tariffIdrPerKwh: activeTariff,
              totalEnergyKwh: periodTotalKwh,
              baselineEnergyKwh: periodBaselineKwh,
              verifiedSavingsKwh,
              estimatedSavingsKwh,
              greenScore,
              emissionFactor,
              machines,
              financingApplication: applications[0],
            })
          }
          className="inline-flex items-center gap-2 rounded-lg bg-[#123B2A] hover:bg-[#0D2B1E] text-white px-4 py-2 text-xs font-semibold transition-colors shadow-xs"
        >
          <Download className="h-4 w-4 text-[#16A36A]" />
          Download Executive PDF Report
        </button>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {/* KPI 1: Total Energy Consumption */}
        <div className="ecosme-card p-5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">
              Total Energy Consumption
            </span>
            <DataClassificationBadge type="MEASURED_DEMO" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-[#123B2A]">
              {formatNumber(periodTotalKwh, 1)}
            </span>
            <span className="text-xs font-semibold text-slate-500">kWh</span>
          </div>
          <p className="text-[11px] text-emerald-700 font-medium">
            ↓ {savingsResult.savingsPercentage}% vs {formatNumber(periodBaselineKwh, 0)} kWh baseline
          </p>
        </div>

        {/* KPI 2: Estimated Electricity Cost */}
        <div className="ecosme-card p-5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">
              Estimated Electricity Cost
            </span>
            <DataClassificationBadge type="ESTIMATED" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-[#123B2A]">
              {formatIdr(estimatedCostIdr)}
            </span>
          </div>
          <p className="text-[11px] text-slate-500">
            Tariff: {formatIdr(activeTariff)}/kWh ({organization.pln_tariff_class})
          </p>
        </div>

        {/* KPI 3: Verified vs Estimated Savings */}
        <div className="ecosme-card p-5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">
              Verified Energy Savings
            </span>
            <DataClassificationBadge type="VERIFIED" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-[#16A36A]">
              {formatIdr(verifiedSavingsIdr)}
            </span>
            <span className="text-xs font-semibold text-slate-500">
              ({formatNumber(verifiedSavingsKwh, 0)} kWh)
            </span>
          </div>
          <p className="text-[11px] text-amber-800 font-medium">
            + {formatIdr(estimatedSavingsIdr)} ({formatNumber(estimatedSavingsKwh, 0)} kWh) ESTIMATED on CT sensor
          </p>
        </div>

        {/* KPI 4: Carbon Emission Estimate & Green Score */}
        <div className="ecosme-card p-5 space-y-2 bg-[#E8F7F0]/50 border-[#16A36A]/30">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#123B2A]">
              Green Score &amp; CO₂e Saved
            </span>
            <DataClassificationBadge type="PROVISIONAL" customLabel="PROVISIONAL" />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <span className="text-2xl font-bold text-[#123B2A]">
                {greenScore.overall_score}/100
              </span>
              <span className="ml-2 inline-block rounded bg-[#123B2A] text-white px-2 py-0.5 text-xs font-bold">
                Grade {greenScore.rating}
              </span>
            </div>
          </div>
          <p className="text-[11px] text-[#123B2A] font-medium">
            CO₂e Reduced: <strong>{formatNumber(carbonResult.estimatedReductionKgCo2e, 1)} kg</strong> (ESTIMATED)
          </p>
        </div>
      </div>

      {/* Main Chart + Machine & Alert Status */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-6">
        <div className="lg:col-span-8 ecosme-card p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="text-base font-bold text-[#123B2A]">
                Daily Energy Consumption vs. Normalized Baseline (kWh)
              </h2>
              <p className="text-xs text-slate-500">
                Showing {periodDaysCount} day(s) of deterministic facility telemetry across 5 monitored machine lines.
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="inline-flex items-center gap-1.5 text-slate-600">
                <span className="h-2.5 w-2.5 rounded-full bg-[#16A36A]" />
                Actual Consumption (kWh)
              </span>
              <span className="inline-flex items-center gap-1.5 text-slate-500">
                <span className="h-2.5 w-2.5 rounded-full bg-slate-400" />
                Daily Baseline ({formatNumber(activeBaseline / 30, 0)} kWh)
              </span>
            </div>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={dailySeries} margin={{ top: 10, right: 16, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorKwh" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#16A36A" stopOpacity={0.28} />
                    <stop offset="95%" stopColor="#16A36A" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis dataKey="date_label" tick={{ fontSize: 11, fill: "#4B5563" }} />
                <YAxis tick={{ fontSize: 11, fill: "#4B5563" }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#FFFFFF",
                    borderColor: "#DDE5DF",
                    borderRadius: "8px",
                    fontSize: "12px",
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="baselineDayKwh"
                  name="Baseline (kWh)"
                  stroke="#94A3B8"
                  strokeDasharray="4 4"
                  fill="none"
                />
                <Area
                  type="monotone"
                  dataKey="totalKwh"
                  name="Measured Demo Consumption (kWh)"
                  stroke="#123B2A"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorKwh)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Right: Machine Status & Active Alerts Summary */}
        <div className="lg:col-span-4 space-y-4">
          <div className="ecosme-card p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-[#123B2A] flex items-center gap-2">
                <Cpu className="h-4 w-4 text-[#16A36A]" />
                Machine &amp; Device Connectivity
              </h2>
              <Link
                href="/app/machines"
                className="text-xs font-semibold text-[#16A36A] hover:underline"
              >
                Manage ({machines.length}) →
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-2.5 text-center">
              <div className="rounded-lg bg-[#E8F7F0] p-3 border border-[#16A36A]/30">
                <span className="text-xl font-bold text-[#123B2A] block">
                  {onlineMachines} / {machines.length}
                </span>
                <span className="text-[11px] font-medium text-[#123B2A]">
                  Machines Online
                </span>
              </div>
              <div className="rounded-lg bg-slate-50 p-3 border border-slate-200">
                <span className="text-xl font-bold text-[#14243A] block">
                  {devices.filter((d) => d.measures_voltage).length} / {devices.length}
                </span>
                <span className="text-[11px] font-medium text-slate-600">
                  True Power Meters
                </span>
              </div>
            </div>
            <ul className="space-y-2 pt-1 text-xs">
              {machines.slice(0, 4).map((m) => (
                <li
                  key={m.id}
                  className="flex items-center justify-between py-1 border-b border-slate-100 last:border-0"
                >
                  <span className="font-medium text-slate-800 truncate max-w-[180px]">
                    {m.name}
                  </span>
                  <span
                    className={`rounded px-1.5 py-0.5 text-[10px] font-bold ${
                      m.status === "ONLINE"
                        ? "bg-emerald-100 text-emerald-900"
                        : "bg-slate-200 text-slate-700"
                    }`}
                  >
                    {m.status}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          <div className="ecosme-card p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-bold text-[#123B2A] flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-amber-600" />
                Active Energy Alerts ({activeAlerts.length})
              </h2>
              <Link
                href="/app/alerts"
                className="text-xs font-semibold text-[#16A36A] hover:underline"
              >
                View All →
              </Link>
            </div>
            <div className="space-y-2">
              {activeAlerts.slice(0, 2).map((alt) => (
                <div
                  key={alt.id}
                  className="rounded-lg bg-amber-50/70 border border-amber-200 p-3 text-xs space-y-1"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-amber-950">{alt.title}</span>
                    <span className="text-[10px] font-bold uppercase px-1.5 py-0.5 rounded bg-amber-200 text-amber-900">
                      {alt.severity}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600 line-clamp-2">
                    {alt.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </PortalShell>
  );
}
