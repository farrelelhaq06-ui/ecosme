"use client";

import React from "react";
import {
  Award,
  CheckCircle2,
  Download,
  Info,
  ShieldAlert,
  Sparkles,
} from "lucide-react";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";
import { DataClassificationBadge } from "@/components/DataClassificationBadge";
import { downloadEcoSMEReportPdf } from "@/lib/pdf-generator";

export default function GreenScorePage() {
  const {
    organization,
    machines,
    tariffs,
    emissionFactors,
    greenScore,
    methodology,
    applications,
  } = useEcoSME();

  return (
    <PortalShell
      portalType="IKM"
      title="EcoSME Provisional Green Score Card"
      subtitle="Standardized 5-dimension evaluation of operational energy efficiency, load stability, data reliability, and Scope 2 sustainability."
    >
      {/* Mandatory Provisional & Non-Creditworthiness Disclosure */}
      <div className="ecosme-card p-4 mb-6 bg-blue-50/70 border-blue-200 flex items-start justify-between gap-4 flex-wrap">
        <div className="flex items-start gap-3 max-w-4xl">
          <Info className="h-5 w-5 text-blue-800 shrink-0 mt-0.5" />
          <div className="text-xs text-blue-950 space-y-1 leading-relaxed">
            <p className="font-bold">
              Methodology &amp; Scope Disclosure: {greenScore.status_label} ({greenScore.methodology_version})
            </p>
            <p>
              The EcoSME Green Score evaluates operational energy efficiency and environmental telemetry performance only.{" "}
              <strong>
                It does not evaluate financial creditworthiness, is not an official government certification, and does not guarantee bank loan approval.
              </strong>
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() =>
            downloadEcoSMEReportPdf({
              reportType: "GREEN_SCORE_CARD",
              organization,
              reportingPeriod: greenScore.assessment_period,
              tariffIdrPerKwh: tariffs[0]?.rate_idr_per_kwh ?? 1444.7,
              totalEnergyKwh: 41820,
              baselineEnergyKwh: 48900,
              verifiedSavingsKwh: 6726,
              estimatedSavingsKwh: 354,
              greenScore,
              emissionFactor: emissionFactors[0],
              machines,
              financingApplication: applications[0],
            })
          }
          className="inline-flex items-center gap-1.5 rounded-lg bg-[#123B2A] hover:bg-[#0D2B1E] text-white px-4 py-2 text-xs font-semibold shrink-0"
        >
          <Download className="h-4 w-4 text-[#16A36A]" />
          Download Green Score Card (PDF)
        </button>
      </div>

      {/* Hero Score Banner */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-6">
        <div className="lg:col-span-5 ecosme-card p-6 bg-[#123B2A] text-white flex flex-col justify-between space-y-6">
          <div className="flex items-center justify-between">
            <span className="rounded-md bg-emerald-900 border border-emerald-600/50 px-2.5 py-1 text-xs font-semibold text-emerald-200">
              {greenScore.status_label}
            </span>
            <span className="text-xs text-emerald-200 font-mono">
              {greenScore.methodology_version}
            </span>
          </div>

          <div className="flex items-center gap-6">
            <div className="h-24 w-24 rounded-2xl bg-[#16A36A] flex flex-col items-center justify-center text-white shadow-lg shrink-0">
              <span className="text-xs font-bold uppercase tracking-wider">
                Rating
              </span>
              <span className="text-4xl font-extrabold">{greenScore.rating}</span>
            </div>
            <div>
              <p className="text-xs uppercase tracking-wider text-emerald-300 font-semibold">
                Composite Performance Score
              </p>
              <p className="text-4xl font-extrabold text-white mt-0.5">
                {greenScore.overall_score}{" "}
                <span className="text-lg font-normal text-emerald-200">
                  / 100
                </span>
              </p>
              <p className="text-xs text-emerald-100 mt-1">
                Assessment Window: {greenScore.assessment_period}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 pt-3 border-t border-emerald-800/80 text-xs">
            <div>
              <span className="text-emerald-300 block text-[11px]">
                Data Quality Status
              </span>
              <span className="font-bold text-white">
                {greenScore.data_quality_status} ({greenScore.data_completeness_pct}%)
              </span>
            </div>
            <div>
              <span className="text-emerald-300 block text-[11px]">
                Rating Scale Thresholds
              </span>
              <span className="font-semibold text-white">
                A ≥ {methodology.thresholds.rating_a_min} | B ≥{" "}
                {methodology.thresholds.rating_b_min} | C ≥{" "}
                {methodology.thresholds.rating_c_min}
              </span>
            </div>
          </div>
        </div>

        {/* Right: 5 Component Dimensions Breakdown */}
        <div className="lg:col-span-7 ecosme-card p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <h2 className="text-base font-bold text-[#123B2A]">
              Component Score Breakdown (5 Weighted Dimensions)
            </h2>
            <DataClassificationBadge type="PROVISIONAL" />
          </div>

          <div className="space-y-4">
            {greenScore.dimensions.map((dim) => (
              <div key={dim.key} className="space-y-1.5">
                <div className="flex flex-wrap items-center justify-between text-xs gap-1">
                  <div>
                    <span className="font-bold text-[#123B2A]">{dim.label}</span>
                    <span className="ml-2 text-slate-500">
                      (Weight: {dim.weight_pct}%)
                    </span>
                  </div>
                  <div className="font-semibold text-[#123B2A]">
                    Raw: {dim.raw_score}/100 • Weighted:{" "}
                    <span className="text-[#16A36A] font-bold">
                      {dim.weighted_score} pts
                    </span>
                  </div>
                </div>
                <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#16A36A] rounded-full"
                    style={{ width: `${dim.raw_score}%` }}
                  />
                </div>
                <div className="flex flex-wrap items-center justify-between text-[11px] text-slate-600">
                  <span>{dim.explanation}</span>
                  <span className="font-mono font-medium text-slate-800">
                    {dim.metric_evidence}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Actionable Recommendations */}
      <div className="ecosme-card p-6 space-y-3">
        <h2 className="text-base font-bold text-[#123B2A] flex items-center gap-2">
          <CheckCircle2 className="h-5 w-5 text-[#16A36A]" />
          Engineering Recommendations to Improve Green Score
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {greenScore.recommendations.map((rec, idx) => (
            <div
              key={idx}
              className="rounded-lg bg-[#F5F8F6] border border-[#DDE5DF] p-4 text-xs text-slate-700 leading-relaxed flex items-start gap-2.5"
            >
              <span className="h-5 w-5 rounded-full bg-[#123B2A] text-white font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">
                {idx + 1}
              </span>
              <span>{rec}</span>
            </div>
          ))}
        </div>
      </div>
    </PortalShell>
  );
}
