"use client";

import React from "react";
import {
  Award,
  Download,
  FileText,
  Gauge,
  Landmark,
  Leaf,
  PiggyBank,
} from "lucide-react";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";
import { ReportType } from "@/lib/types";
import { downloadEcoSMEReportPdf } from "@/lib/pdf-generator";

const reportCards: Array<{
  type: ReportType;
  title: string;
  desc: string;
  icon: React.ComponentType<{ className?: string }>;
  methodology: string;
}> = [
  {
    type: "ENERGY_CONSUMPTION",
    title: "1. Energy Consumption Report",
    desc: "Machine-by-machine 30-day kWh consumption, peak load profile, single/3-phase metering breakdown, and applicable PLN tariff cost calculation.",
    icon: Gauge,
    methodology: "Class-1 Active Power Integration + PLN I-3 Tariff Schedule",
  },
  {
    type: "ENERGY_SAVINGS",
    title: "2. Energy Savings Report",
    desc: "Normalized baseline comparison, strict separation of VERIFIED active-power savings vs. ESTIMATED CT-only readings, and 30% ESaaS settlement breakdown.",
    icon: PiggyBank,
    methodology: "IPMVP Option B Normalized Baseline Reconciliation",
  },
  {
    type: "SUSTAINABILITY_CARBON",
    title: "3. Sustainability / Carbon Footprint Report",
    desc: "Scope 2 location-based GHG emissions and CO₂e reduction estimates with full Ministry of ESDM Jamali grid emission factor provenance (0.78 kgCO₂e/kWh).",
    icon: Leaf,
    methodology: "GHG Protocol Scope 2 Location-Based Operating Margin",
  },
  {
    type: "GREEN_SCORE_CARD",
    title: "4. EcoSME Green Score Card",
    desc: "Complete 5-dimension Provisional Green Score breakdown (83/100 Grade A), component weightings, telemetry completeness status, and engineering recommendations.",
    icon: Award,
    methodology: "EcoSME Industrial Readiness Methodology v1.2-2026",
  },
  {
    type: "FINANCING_READINESS",
    title: "5. Financing Readiness Report",
    desc: "Consolidated underwriting package for partner banks including business profile, required documents checklist, Green Score, and capex payback projections.",
    icon: Landmark,
    methodology: "EcoSME Green Finance Gateway Standard Dossier",
  },
];

export default function ReportsPage() {
  const {
    organization,
    machines,
    tariffs,
    emissionFactors,
    greenScore,
    applications,
  } = useEcoSME();

  const handleDownload = (reportType: ReportType) => {
    downloadEcoSMEReportPdf({
      reportType,
      organization,
      reportingPeriod: "Oct 11, 2026 – Nov 09, 2026 (30-Day Window)",
      tariffIdrPerKwh: tariffs[0]?.rate_idr_per_kwh ?? 1444.7,
      totalEnergyKwh: 41820,
      baselineEnergyKwh: 48900,
      verifiedSavingsKwh: 6726,
      estimatedSavingsKwh: 354,
      greenScore,
      emissionFactor: emissionFactors[0],
      machines,
      financingApplication: applications[0],
    });
  };

  return (
    <PortalShell
      portalType="IKM"
      title="Standardized PDF Report Center"
      subtitle="Generate and download audit-ready PDF reports using the exact same deterministic dataset and calculations as your live dashboard."
    >
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {reportCards.map((item) => {
          const Icon = item.icon;
          return (
            <div
              key={item.type}
              className="ecosme-card p-6 flex flex-col justify-between space-y-5"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="h-10 w-10 rounded-lg bg-[#E8F7F0] flex items-center justify-center text-[#123B2A]">
                    <Icon className="h-5 w-5 text-[#16A36A]" />
                  </div>
                  <span className="rounded bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-700">
                    PDF / A4
                  </span>
                </div>
                <h2 className="text-base font-bold text-[#123B2A]">
                  {item.title}
                </h2>
                <p className="text-xs text-[#4B5563] leading-relaxed">
                  {item.desc}
                </p>
                <div className="rounded-lg bg-[#F5F8F6] p-2.5 text-[11px] text-slate-600">
                  <strong className="text-[#123B2A] block">Methodology:</strong>
                  {item.methodology}
                </div>
              </div>

              <button
                type="button"
                onClick={() => handleDownload(item.type)}
                className="w-full inline-flex items-center justify-center gap-2 rounded-lg bg-[#123B2A] hover:bg-[#0D2B1E] text-white py-2.5 text-xs font-semibold transition-colors"
              >
                <Download className="h-4 w-4 text-[#16A36A]" />
                Generate &amp; Download PDF
              </button>
            </div>
          );
        })}
      </div>
    </PortalShell>
  );
}
