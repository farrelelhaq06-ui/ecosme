"use client";

import React, { useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  Cpu,
  KeyRound,
  Plus,
  Radio,
  RefreshCw,
  WifiOff,
  X,
} from "lucide-react";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";
import { formatDateTime } from "@/lib/formatters";

export default function DevicesPage() {
  const { devices, machines, deviceCredentials, mutateState } = useEcoSME();
  const [showPairModal, setShowPairModal] = useState(false);
  const [devName, setDevName] = useState("");
  const [serialNumber, setSerialNumber] = useState("");
  const [hwType, setHwType] = useState("ESP32_MODBUS_3P");
  const [protocol, setProtocol] = useState("MQTT_TLS");
  const [linkedMachineId, setLinkedMachineId] = useState("");
  const [provisionedToken, setProvisionedToken] = useState<string | null>(null);

  const handlePairDevice = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await mutateState("PAIR_DEVICE", {
      name: devName,
      serial_number: serialNumber,
      hardware_type: hwType,
      connection_protocol: protocol,
      machine_id: linkedMachineId || null,
    });
    if (res.ok && res.data?.provisionedSecretOnce) {
      setProvisionedToken(String(res.data.provisionedSecretOnce));
    }
    setDevName("");
    setSerialNumber("");
    setShowPairModal(false);
  };

  return (
    <PortalShell
      portalType="IKM"
      title="IoT Device Management & Heartbeat Connectivity"
      subtitle="Pair ESP32 / NodeMCU / Modbus energy meters, provision hashed API credentials, and monitor real-time device heartbeats."
    >
      {/* Important IoT Engineering Considerations Banner */}
      <div className="ecosme-card p-4 mb-6 bg-slate-50 border-slate-200 space-y-2 text-xs text-slate-700">
        <div className="font-bold text-[#123B2A] flex items-center gap-2">
          <Cpu className="h-4 w-4 text-[#16A36A]" />
          Hardware Metering &amp; Tamper-Resilience Architecture Notes
        </div>
        <ul className="list-disc pl-5 space-y-1 text-[11px] leading-relaxed">
          <li>
            <strong>True Active Power vs. Current-Only Sensors:</strong> Single-phase active power requires Voltage, Current, and Power Factor (<code className="font-mono">V × I × PF</code>); three-phase systems require phase-appropriate Modbus metering (<code className="font-mono">√3 × V × I × PF</code>). Legacy <code className="font-mono">NODEMCU_CT_ONLY</code> clamps are flagged as <code className="font-mono">DEGRADED / ESTIMATED</code>.
          </li>
          <li>
            <strong>Heartbeat vs. Physical Sensor Integrity:</strong> Heartbeat monitoring detects network or power dropouts within 15 minutes; it does not by itself guarantee that a physical CT sensor has not been manipulated. EcoSME reconciles sub-meter totals against monthly PLN utility bills for verified savings.
          </li>
        </ul>
      </div>

      {provisionedToken && (
        <div className="ecosme-card p-4 mb-6 bg-emerald-50 border-emerald-400 space-y-2 text-xs">
          <div className="flex items-center justify-between">
            <span className="font-bold text-emerald-950 flex items-center gap-1.5">
              <KeyRound className="h-4 w-4 text-[#16A36A]" />
              New Device Provisioned — Copy One-Time API Credential Now
            </span>
            <button
              type="button"
              onClick={() => setProvisionedToken(null)}
              className="text-slate-500 hover:text-slate-800"
            >
              Dismiss
            </button>
          </div>
          <p className="text-emerald-900">
            For security, EcoSME stores only the SHA-256 hash of device credentials on the server. Flash this token to your ESP32 <code className="font-mono">x-device-token</code> header:
          </p>
          <code className="block rounded bg-slate-900 text-emerald-400 px-3 py-2 font-mono text-xs select-all">
            {provisionedToken}
          </code>
        </div>
      )}

      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-3 text-xs">
          <span className="rounded-lg bg-white border border-[#DDE5DF] px-3 py-1.5 font-medium">
            Registered Gateways: <strong>{devices.length}</strong>
          </span>
          <span className="rounded-lg bg-[#E8F7F0] border border-[#16A36A]/30 px-3 py-1.5 font-medium text-[#123B2A]">
            Online Heartbeats:{" "}
            <strong>
              {devices.filter((d) => d.status === "ONLINE").length}
            </strong>
          </span>
        </div>

        <button
          type="button"
          onClick={() => setShowPairModal(true)}
          className="inline-flex items-center gap-1.5 rounded-lg bg-[#123B2A] hover:bg-[#0D2B1E] text-white px-4 py-2 text-xs font-semibold"
        >
          <Plus className="h-4 w-4 text-[#16A36A]" />
          Pair New IoT Device
        </button>
      </div>

      {/* Devices Table */}
      <div className="ecosme-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#F5F8F6] text-slate-600 border-b border-[#DDE5DF]">
                <th className="py-3 px-4 font-semibold">Device Name &amp; Serial</th>
                <th className="py-3 px-4 font-semibold">Hardware &amp; Phase</th>
                <th className="py-3 px-4 font-semibold">Assigned Machine</th>
                <th className="py-3 px-4 font-semibold">Metering Capability</th>
                <th className="py-3 px-4 font-semibold">Last Heartbeat</th>
                <th className="py-3 px-4 font-semibold">Completeness</th>
                <th className="py-3 px-4 font-semibold">Status</th>
                <th className="py-3 px-4 font-semibold text-right">Heartbeat Test</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {devices.map((d) => {
                const m = machines.find((item) => item.id === d.machine_id);
                const cred = deviceCredentials.find((c) => c.device_id === d.id);
                return (
                  <tr key={d.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4">
                      <span className="font-bold text-[#123B2A] block">
                        {d.name}
                      </span>
                      <span className="font-mono text-[11px] text-slate-500">
                        {d.serial_number} • {d.connection_protocol}
                      </span>
                      {cred && (
                        <span className="block text-[10px] font-mono text-emerald-800">
                          Key: {cred.key_prefix}••• (SHA-256)
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-semibold text-slate-800 block">
                        {d.hardware_type}
                      </span>
                      <span className="text-[11px] text-slate-500">
                        {d.phase_support} • FW {d.firmware_version}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      {m ? (
                        <span className="font-medium text-[#123B2A]">
                          {m.code} — {m.name}
                        </span>
                      ) : (
                        <span className="text-slate-400">Unassigned</span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      {d.measures_voltage && d.measures_power_factor ? (
                        <span className="rounded bg-emerald-100 text-emerald-900 px-2 py-0.5 text-[10px] font-bold">
                          True Active Power (V, I, PF)
                        </span>
                      ) : (
                        <span className="rounded bg-amber-100 text-amber-900 px-2 py-0.5 text-[10px] font-bold">
                          Current-Only (Estimated)
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-slate-600">
                      {formatDateTime(d.last_heartbeat)}
                    </td>
                    <td className="py-3 px-4 font-bold text-[#123B2A]">
                      {d.data_completeness_pct}%
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`rounded px-2 py-0.5 text-[10px] font-bold uppercase ${
                          d.status === "ONLINE"
                            ? "bg-emerald-100 text-emerald-900"
                            : d.status === "DEGRADED"
                            ? "bg-amber-100 text-amber-900"
                            : "bg-red-100 text-red-900"
                        }`}
                      >
                        {d.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() =>
                          mutateState("SIMULATE_HEARTBEAT", {
                            device_id: d.id,
                            mode: "PING",
                          })
                        }
                        className="inline-flex items-center gap-1 rounded border border-slate-300 bg-white hover:bg-slate-100 px-2 py-1 text-[11px] font-medium text-slate-700"
                      >
                        <RefreshCw className="h-3 w-3" /> Ping
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          mutateState("SIMULATE_HEARTBEAT", {
                            device_id: d.id,
                            mode: "DISCONNECT",
                          })
                        }
                        className="inline-flex items-center gap-1 rounded border border-red-200 bg-red-50 hover:bg-red-100 px-2 py-1 text-[11px] font-medium text-red-800"
                      >
                        <WifiOff className="h-3 w-3" /> Simulate Drop
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pair Device Modal */}
      {showPairModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
          <form
            onSubmit={handlePairDevice}
            className="ecosme-card p-6 max-w-lg w-full space-y-4 text-xs"
          >
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h2 className="text-base font-bold text-[#123B2A]">
                Pair New IoT Energy Monitoring Device
              </h2>
              <button
                type="button"
                onClick={() => setShowPairModal(false)}
                className="p-1 rounded hover:bg-slate-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Device Friendly Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., EcoNode-3P #06 (Chiller)"
                  value={devName}
                  onChange={(e) => setDevName(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Hardware Serial Number
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., ESME-ESP32-3P-2026-006"
                  value={serialNumber}
                  onChange={(e) => setSerialNumber(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Hardware Architecture
                </label>
                <select
                  value={hwType}
                  onChange={(e) => setHwType(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2"
                >
                  <option value="ESP32_MODBUS_3P">
                    ESP32 + 3-Phase Modbus Meter (True V,I,PF)
                  </option>
                  <option value="ESP32_PZEM004T">
                    ESP32 + PZEM-004T 1-Phase (True V,I,PF)
                  </option>
                  <option value="SCHNEIDER_PM2230">
                    Schneider PM2230 Industrial Meter
                  </option>
                  <option value="NODEMCU_CT_ONLY">
                    NodeMCU CT-Clamp Only (Current-Only / Estimated)
                  </option>
                </select>
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Telemetry Protocol
                </label>
                <select
                  value={protocol}
                  onChange={(e) => setProtocol(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2"
                >
                  <option value="MQTT_TLS">MQTT over TLS (Port 8883)</option>
                  <option value="HTTPS_REST">HTTPS REST (/api/iot/ingest)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Assign to Industrial Machine
              </label>
              <select
                value={linkedMachineId}
                onChange={(e) => setLinkedMachineId(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2"
              >
                <option value="">— Unassigned (Standby Gateway) —</option>
                {machines.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.code} — {m.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowPairModal(false)}
                className="px-4 py-2 rounded-lg border border-slate-300 font-semibold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-lg bg-[#123B2A] text-white font-semibold"
              >
                Provision &amp; Generate Key
              </button>
            </div>
          </form>
        </div>
      )}
    </PortalShell>
  );
}
