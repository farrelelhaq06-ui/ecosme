"use client";

import React, { useMemo, useState } from "react";
import {
  Activity,
  AlertCircle,
  CheckCircle2,
  Cpu,
  Gauge,
  Send,
  Zap,
} from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";
import { DataClassificationBadge } from "@/components/DataClassificationBadge";
import { calculateActivePower, calculateElectricityCost } from "@/lib/calculations";
import { formatIdr, formatNumber } from "@/lib/formatters";

export default function EnergyMonitoringPage() {
  const { organization, machines, devices, readings, tariffs, refreshState } =
    useEcoSME();

  const [selectedMachineId, setSelectedMachineId] = useState<string>("ALL");
  const [simDeviceId, setSimDeviceId] = useState<string>("dev-esp32-3p-01");
  const [simVoltage, setSimVoltage] = useState<number>(380.5);
  const [simCurrent, setSimCurrent] = useState<number>(38.4);
  const [simPf, setSimPf] = useState<number>(0.91);
  const [simEnergyKwh, setSimEnergyKwh] = useState<number>(21.5);
  const [simResult, setSimResult] = useState<string | null>(null);
  const [simSubmitting, setSimSubmitting] = useState<boolean>(false);

  const activeTariff = tariffs[0]?.rate_idr_per_kwh ?? 1444.7;

  const filteredReadings = useMemo(() => {
    if (selectedMachineId === "ALL") return readings;
    return readings.filter((r) => r.machine_id === selectedMachineId);
  }, [readings, selectedMachineId]);

  const latestReading = filteredReadings[filteredReadings.length - 1];
  const totalKwh = useMemo(
    () =>
      Math.round(
        filteredReadings.reduce((sum, r) => sum + r.energy_kwh, 0) * 10
      ) / 10,
    [filteredReadings]
  );

  const machineComparisonData = useMemo(() => {
    return machines.map((m) => ({
      code: m.code,
      name: m.name,
      actualKwh: m.monthly_energy_kwh,
      baselineKwh: m.baseline_monthly_kwh,
      ratedKw: m.rated_power_kw,
    }));
  }, [machines]);

  const selectedSimDevice = devices.find((d) => d.id === simDeviceId) ?? devices[0];
  const livePowerPreview = calculateActivePower({
    phaseType: selectedSimDevice?.phase_support ?? "THREE_PHASE",
    currentA: simCurrent,
    voltageV: selectedSimDevice?.measures_voltage ? simVoltage : null,
    powerFactor: selectedSimDevice?.measures_power_factor ? simPf : null,
  });

  const handleIngestTelemetry = async (e: React.FormEvent) => {
    e.preventDefault();
    setSimSubmitting(true);
    setSimResult(null);
    try {
      const res = await fetch("/api/iot/ingest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          device_id: selectedSimDevice.id,
          organization_id: organization.id,
          machine_id: selectedSimDevice.machine_id,
          voltage: selectedSimDevice.measures_voltage ? simVoltage : null,
          current: simCurrent,
          power_factor: selectedSimDevice.measures_power_factor ? simPf : null,
          energy_kwh: simEnergyKwh,
          timestamp: new Date().toISOString(),
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setSimResult(`Error: ${data.error}`);
      } else {
        setSimResult(
          `Ingested ${data.reading.energy_kwh} kWh (${data.active_power_analysis.powerKw} kW via ${data.active_power_analysis.calculationMethod}). Triggered ${data.alerts_triggered.length} alert(s).`
        );
        await refreshState();
      }
    } catch {
      setSimResult("Failed to send telemetry payload.");
    } finally {
      setSimSubmitting(false);
    }
  };

  return (
    <PortalShell
      portalType="IKM"
      title="Electrical Energy & Sub-Metering Telemetry"
      subtitle="Inspect Voltage (V), Current (A), Power Factor (PF), Active Power (W/kW), and accumulated kWh across production lines."
    >
      {/* Engineering Disclosure Banner */}
      <div className="ecosme-card p-4 mb-6 bg-[#E8F7F0]/60 border-[#16A36A]/30 flex items-start gap-3">
        <AlertCircle className="h-5 w-5 text-[#123B2A] shrink-0 mt-0.5" />
        <div className="text-xs text-slate-700 leading-relaxed">
          <strong className="text-[#123B2A]">
            Telemetry Source &amp; Active Power Verification Notice:
          </strong>{" "}
          Readings in this environment come from EcoSME&apos;s deterministic demo dataset (<code className="font-mono">SIMULATED_DEMO</code>) unless pushed via a live hardware gateway. Single-phase active power requires <code className="font-mono">P = V × I × PF</code> and balanced 3-phase requires <code className="font-mono">P = √3 × V_LL × I_L × PF</code>. Current-only sensors (such as <code className="font-mono">MCH-PMP-05</code>) display <code className="font-mono">V = N/A</code> and are classified as <strong>ESTIMATED</strong>.
        </div>
      </div>

      {/* Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-2">
          <label
            htmlFor="machine-filter-select"
            className="text-xs font-semibold text-slate-700"
          >
            Filter by Industrial Line:
          </label>
          <select
            id="machine-filter-select"
            value={selectedMachineId}
            onChange={(e) => setSelectedMachineId(e.target.value)}
            className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-semibold text-[#123B2A]"
          >
            <option value="ALL">All Monitored Machines ({machines.length})</option>
            {machines.map((m) => (
              <option key={m.id} value={m.id}>
                {m.code} — {m.name} ({m.phase_type})
              </option>
            ))}
          </select>
        </div>

        <DataClassificationBadge
          type={
            latestReading?.classification === "ESTIMATED"
              ? "ESTIMATED"
              : "MEASURED_DEMO"
          }
        />
      </div>

      {/* Electrical Quantities Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 mb-6">
        <div className="ecosme-card p-4 space-y-1">
          <span className="text-[11px] font-semibold text-slate-500">
            Voltage (V)
          </span>
          <p className="text-xl font-bold text-[#123B2A]">
            {latestReading?.voltage_v !== null && latestReading?.voltage_v !== undefined
              ? `${latestReading.voltage_v.toFixed(1)} V`
              : "N/A (CT Only)"}
          </p>
          <p className="text-[10px] text-slate-500">
            {latestReading?.voltage_v ? "True RMS Measured (Demo)" : "Assumed 220V Nominal"}
          </p>
        </div>

        <div className="ecosme-card p-4 space-y-1">
          <span className="text-[11px] font-semibold text-slate-500">
            Line Current (A)
          </span>
          <p className="text-xl font-bold text-[#123B2A]">
            {latestReading ? `${latestReading.current_a.toFixed(1)} A` : "0.0 A"}
          </p>
          <p className="text-[10px] text-slate-500">CT / Shunt Transducer</p>
        </div>

        <div className="ecosme-card p-4 space-y-1">
          <span className="text-[11px] font-semibold text-slate-500">
            Active Power (W / kW)
          </span>
          <p className="text-xl font-bold text-[#123B2A]">
            {latestReading
              ? `${latestReading.power_kw.toFixed(2)} kW`
              : "0.00 kW"}
          </p>
          <p className="text-[10px] text-slate-500">
            {latestReading
              ? `${Math.round(latestReading.power_kw * 1000).toLocaleString()} W`
              : "0 W"}
          </p>
        </div>

        <div className="ecosme-card p-4 space-y-1">
          <span className="text-[11px] font-semibold text-slate-500">
            Power Factor (cos φ)
          </span>
          <p className="text-xl font-bold text-[#123B2A]">
            {latestReading?.power_factor !== null &&
            latestReading?.power_factor !== undefined
              ? latestReading.power_factor.toFixed(2)
              : "0.85 (Assumed)"}
          </p>
          <p className="text-[10px] text-emerald-700 font-medium">
            PLN Threshold: ≥ 0.85
          </p>
        </div>

        <div className="ecosme-card p-4 space-y-1 col-span-2 sm:col-span-1">
          <span className="text-[11px] font-semibold text-slate-500">
            Accumulated Energy (30d)
          </span>
          <p className="text-xl font-bold text-[#123B2A]">
            {formatNumber(totalKwh, 1)} kWh
          </p>
          <p className="text-[10px] text-slate-500">
            Est. Cost: {formatIdr(calculateElectricityCost(totalKwh, activeTariff))}
          </p>
        </div>
      </div>

      {/* Machine Comparison Chart + Live IoT Telemetry Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-6">
        <div className="lg:col-span-7 ecosme-card p-5 space-y-4">
          <div>
            <h2 className="text-base font-bold text-[#123B2A]">
              Machine-Level Consumption vs. Baseline (30-Day kWh)
            </h2>
            <p className="text-xs text-slate-500">
              Comparison of current 30-day energy usage against pre-retrofit baseline across all 5 facility machines.
            </p>
          </div>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={machineComparisonData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis dataKey="code" tick={{ fontSize: 11, fill: "#4B5563" }} />
                <YAxis tick={{ fontSize: 11, fill: "#4B5563" }} />
                <Tooltip />
                <Bar
                  dataKey="baselineKwh"
                  name="Baseline 30d (kWh)"
                  fill="#94A3B8"
                  radius={[4, 4, 0, 0]}
                />
                <Bar
                  dataKey="actualKwh"
                  name="Current 30d (kWh)"
                  fill="#123B2A"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Interactive IoT API Ingestion Tester */}
        <div className="lg:col-span-5 ecosme-card p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#16A36A]">
                POST /api/iot/ingest
              </span>
              <h2 className="text-base font-bold text-[#123B2A]">
                Simulate IoT Measurement Transmission
              </h2>
            </div>
            <Cpu className="h-5 w-5 text-[#16A36A]" />
          </div>

          <form onSubmit={handleIngestTelemetry} className="space-y-3 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Target IoT Device
              </label>
              <select
                value={simDeviceId}
                onChange={(e) => setSimDeviceId(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-1.5 font-medium"
              >
                {devices.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name} ({d.phase_support} •{" "}
                    {d.measures_voltage ? "True V*I*PF" : "CT-Only"})
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-3 gap-2.5">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Voltage (V)
                </label>
                <input
                  type="number"
                  step="0.1"
                  disabled={!selectedSimDevice?.measures_voltage}
                  value={selectedSimDevice?.measures_voltage ? simVoltage : 0}
                  onChange={(e) => setSimVoltage(Number(e.target.value))}
                  className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 disabled:bg-slate-100"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Current (A)
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={simCurrent}
                  onChange={(e) => setSimCurrent(Number(e.target.value))}
                  className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Power Factor
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0.5"
                  max="1"
                  disabled={!selectedSimDevice?.measures_power_factor}
                  value={selectedSimDevice?.measures_power_factor ? simPf : 0.85}
                  onChange={(e) => setSimPf(Number(e.target.value))}
                  className="w-full rounded-lg border border-slate-300 px-2.5 py-1.5 disabled:bg-slate-100"
                />
              </div>
            </div>

            <div className="rounded-lg bg-[#F5F8F6] p-3 border border-[#DDE5DF] space-y-1">
              <div className="flex justify-between font-semibold text-[#123B2A]">
                <span>Computed Active Power:</span>
                <span>
                  {livePowerPreview.powerKw} kW ({livePowerPreview.powerWatts} W)
                </span>
              </div>
              <p className="text-[11px] text-slate-600">
                {livePowerPreview.engineeringNote}
              </p>
            </div>

            <button
              type="submit"
              disabled={simSubmitting}
              className="w-full inline-flex items-center justify-center gap-1.5 rounded-lg bg-[#123B2A] hover:bg-[#0D2B1E] text-white py-2 font-semibold transition-colors"
            >
              <Send className="h-3.5 w-3.5 text-[#16A36A]" />
              {simSubmitting
                ? "Transmitting to /api/iot/ingest..."
                : "Transmit Telemetry Payload"}
            </button>

            {simResult && (
              <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-2.5 text-[11px] text-emerald-950 font-medium">
                {simResult}
              </div>
            )}
          </form>
        </div>
      </div>

      {/* Historical Readings Table */}
      <div className="ecosme-card overflow-hidden">
        <div className="p-4 border-b border-[#DDE5DF] flex items-center justify-between">
          <h2 className="text-sm font-bold text-[#123B2A]">
            Recent Telemetry Readings Log (Showing Latest 12 Records)
          </h2>
          <span className="text-xs text-slate-500">
            Tariff Rate: {formatIdr(activeTariff)}/kWh
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#F5F8F6] text-slate-600 border-b border-[#DDE5DF]">
                <th className="py-2.5 px-4 font-semibold">Date / Timestamp</th>
                <th className="py-2.5 px-4 font-semibold">Machine</th>
                <th className="py-2.5 px-4 font-semibold">Voltage (V)</th>
                <th className="py-2.5 px-4 font-semibold">Current (A)</th>
                <th className="py-2.5 px-4 font-semibold">PF</th>
                <th className="py-2.5 px-4 font-semibold">Active Power</th>
                <th className="py-2.5 px-4 font-semibold">Energy (kWh)</th>
                <th className="py-2.5 px-4 font-semibold">Classification</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredReadings
                .slice(-12)
                .reverse()
                .map((r) => {
                  const m = machines.find((item) => item.id === r.machine_id);
                  return (
                    <tr key={r.id} className="hover:bg-slate-50">
                      <td className="py-2.5 px-4 font-mono text-[11px] text-slate-600">
                        {r.date_label} ({r.timestamp.slice(11, 16)} UTC)
                      </td>
                      <td className="py-2.5 px-4 font-medium text-[#123B2A]">
                        {m ? `${m.code} — ${m.name}` : r.machine_id}
                      </td>
                      <td className="py-2.5 px-4">
                        {r.voltage_v !== null ? `${r.voltage_v.toFixed(1)} V` : "N/A (CT)"}
                      </td>
                      <td className="py-2.5 px-4">{r.current_a.toFixed(1)} A</td>
                      <td className="py-2.5 px-4">
                        {r.power_factor !== null ? r.power_factor.toFixed(2) : "—"}
                      </td>
                      <td className="py-2.5 px-4 font-semibold">
                        {r.power_kw.toFixed(2)} kW
                      </td>
                      <td className="py-2.5 px-4 font-bold text-[#123B2A]">
                        {r.energy_kwh.toFixed(1)} kWh
                      </td>
                      <td className="py-2.5 px-4">
                        <DataClassificationBadge
                          type={
                            r.classification === "ESTIMATED"
                              ? "ESTIMATED"
                              : "MEASURED_DEMO"
                          }
                        />
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>
      </div>
    </PortalShell>
  );
}
