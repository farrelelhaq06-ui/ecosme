"use client";

import React, { useState } from "react";
import {
  CheckCircle2,
  Cpu,
  Edit3,
  Eye,
  Plus,
  Power,
  Radio,
  X,
} from "lucide-react";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";
import { Machine } from "@/lib/types";
import { formatDateTime, formatNumber } from "@/lib/formatters";

export default function MachinesPage() {
  const { machines, devices, mutateState } = useEcoSME();
  const [selectedMachine, setSelectedMachine] = useState<Machine | null>(null);
  const [editingMachine, setEditingMachine] = useState<Machine | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  // Add Machine Form State
  const [newName, setNewName] = useState("");
  const [newCode, setNewCode] = useState("");
  const [newCategory, setNewCategory] = useState("Thermal & Wet Processing");
  const [newZone, setNewZone] = useState("Hall A — Production Floor");
  const [newRatedKw, setNewRatedKw] = useState(18.5);
  const [newPhase, setNewPhase] = useState<"THREE_PHASE" | "SINGLE_PHASE">(
    "THREE_PHASE"
  );
  const [newNotes, setNewNotes] = useState("");

  const handleAddMachine = async (e: React.FormEvent) => {
    e.preventDefault();
    await mutateState("ADD_MACHINE", {
      name: newName,
      code: newCode,
      category: newCategory,
      location_zone: newZone,
      rated_power_kw: newRatedKw,
      phase_type: newPhase,
      efficiency_notes: newNotes,
    });
    setNewName("");
    setNewCode("");
    setShowAddModal(false);
  };

  const handleUpdateMachine = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMachine) return;
    await mutateState("UPDATE_MACHINE", {
      id: editingMachine.id,
      name: editingMachine.name,
      category: editingMachine.category,
      location_zone: editingMachine.location_zone,
      rated_power_kw: editingMachine.rated_power_kw,
      efficiency_notes: editingMachine.efficiency_notes,
    });
    setEditingMachine(null);
  };

  return (
    <PortalShell
      portalType="IKM"
      title="Industrial Machine Management"
      subtitle="Manage production equipment, inspect linked IoT sub-metering gateways, and control machine operational status."
    >
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-3 text-xs">
          <span className="rounded-lg bg-white border border-[#DDE5DF] px-3 py-1.5 font-medium">
            Total Machines: <strong>{machines.length}</strong>
          </span>
          <span className="rounded-lg bg-[#E8F7F0] border border-[#16A36A]/30 px-3 py-1.5 font-medium text-[#123B2A]">
            Online:{" "}
            <strong>
              {machines.filter((m) => m.status === "ONLINE").length}
            </strong>
          </span>
        </div>

        <button
          type="button"
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-1.5 rounded-lg bg-[#123B2A] hover:bg-[#0D2B1E] text-white px-4 py-2 text-xs font-semibold transition-colors shadow-xs"
        >
          <Plus className="h-4 w-4 text-[#16A36A]" />
          Add Industrial Machine
        </button>
      </div>

      {/* Machines Table */}
      <div className="ecosme-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#F5F8F6] text-slate-600 border-b border-[#DDE5DF]">
                <th className="py-3 px-4 font-semibold">Machine Name &amp; ID</th>
                <th className="py-3 px-4 font-semibold">Category &amp; Zone</th>
                <th className="py-3 px-4 font-semibold">Phase / Rated Power</th>
                <th className="py-3 px-4 font-semibold">Connected IoT Device</th>
                <th className="py-3 px-4 font-semibold">30d Consumption</th>
                <th className="py-3 px-4 font-semibold">Last Data Received</th>
                <th className="py-3 px-4 font-semibold">Status</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {machines.map((m) => {
                const dev = devices.find((d) => d.id === m.device_id);
                const savingsPct =
                  m.baseline_monthly_kwh > 0
                    ? (
                        ((m.baseline_monthly_kwh - m.monthly_energy_kwh) /
                          m.baseline_monthly_kwh) *
                        100
                      ).toFixed(1)
                    : "0.0";
                return (
                  <tr key={m.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4">
                      <span className="font-bold text-[#123B2A] block">
                        {m.name}
                      </span>
                      <span className="font-mono text-[11px] text-slate-500">
                        {m.code}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-medium text-slate-800 block">
                        {m.category}
                      </span>
                      <span className="text-[11px] text-slate-500">
                        {m.location_zone}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-semibold text-slate-800 block">
                        {m.rated_power_kw} kW
                      </span>
                      <span className="text-[11px] text-slate-500">
                        {m.phase_type} ({m.nominal_voltage_v}V)
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      {dev ? (
                        <div>
                          <span className="inline-flex items-center gap-1 font-medium text-[#123B2A]">
                            <Radio className="h-3.5 w-3.5 text-[#16A36A]" />
                            {dev.name}
                          </span>
                          <span className="block text-[10px] text-slate-500">
                            {dev.measures_voltage
                              ? "True Power (V, I, PF)"
                              : "CT-Only (Estimated)"}
                          </span>
                        </div>
                      ) : (
                        <span className="text-slate-400">Unpaired</span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-bold text-[#123B2A] block">
                        {formatNumber(m.monthly_energy_kwh, 1)} kWh
                      </span>
                      <span className="text-[11px] text-emerald-700 font-medium">
                        ↓ {savingsPct}% vs {formatNumber(m.baseline_monthly_kwh, 0)} kWh
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-600">
                      {formatDateTime(m.last_data_received)}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-block rounded px-2 py-0.5 text-[10px] font-bold uppercase ${
                          m.status === "ONLINE"
                            ? "bg-emerald-100 text-emerald-900"
                            : m.status === "DEACTIVATED"
                            ? "bg-red-100 text-red-900"
                            : "bg-slate-200 text-slate-700"
                        }`}
                      >
                        {m.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => setSelectedMachine(m)}
                        className="inline-flex items-center gap-1 rounded border border-slate-300 bg-white hover:bg-slate-100 px-2 py-1 text-[11px] font-medium text-slate-700"
                      >
                        <Eye className="h-3 w-3" /> Details
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingMachine({ ...m })}
                        className="inline-flex items-center gap-1 rounded border border-slate-300 bg-white hover:bg-slate-100 px-2 py-1 text-[11px] font-medium text-slate-700"
                      >
                        <Edit3 className="h-3 w-3" /> Edit
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          mutateState("TOGGLE_MACHINE_STATUS", { id: m.id })
                        }
                        className="inline-flex items-center gap-1 rounded border border-slate-300 bg-white hover:bg-slate-100 px-2 py-1 text-[11px] font-medium text-slate-700"
                      >
                        <Power className="h-3 w-3" />
                        {m.status === "DEACTIVATED" ? "Activate" : "Deactivate"}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Machine Details Modal */}
      {selectedMachine && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
          <div className="ecosme-card p-6 max-w-lg w-full space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div>
                <span className="text-[11px] font-mono font-bold text-[#16A36A]">
                  {selectedMachine.code}
                </span>
                <h2 className="text-lg font-bold text-[#123B2A]">
                  {selectedMachine.name}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setSelectedMachine(null)}
                className="p-1 rounded hover:bg-slate-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="rounded-lg bg-[#F5F8F6] p-3">
                <span className="text-slate-500 block">Category &amp; Zone</span>
                <span className="font-semibold text-slate-900">
                  {selectedMachine.category} • {selectedMachine.location_zone}
                </span>
              </div>
              <div className="rounded-lg bg-[#F5F8F6] p-3">
                <span className="text-slate-500 block">Electrical Spec</span>
                <span className="font-semibold text-slate-900">
                  {selectedMachine.rated_power_kw} kW • {selectedMachine.phase_type} (
                  {selectedMachine.nominal_voltage_v}V)
                </span>
              </div>
              <div className="rounded-lg bg-[#F5F8F6] p-3">
                <span className="text-slate-500 block">30d Consumption</span>
                <span className="font-bold text-[#123B2A]">
                  {formatNumber(selectedMachine.monthly_energy_kwh, 1)} kWh
                </span>
              </div>
              <div className="rounded-lg bg-[#F5F8F6] p-3">
                <span className="text-slate-500 block">Baseline Consumption</span>
                <span className="font-semibold text-slate-800">
                  {formatNumber(selectedMachine.baseline_monthly_kwh, 1)} kWh
                </span>
              </div>
            </div>
            <div className="rounded-lg bg-emerald-50/70 border border-emerald-200 p-3 text-xs">
              <span className="font-bold text-[#123B2A] block mb-1">
                Engineering &amp; Retrofit Notes:
              </span>
              <p className="text-slate-700">{selectedMachine.efficiency_notes}</p>
            </div>
          </div>
        </div>
      )}

      {/* Edit Machine Modal */}
      {editingMachine && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
          <form
            onSubmit={handleUpdateMachine}
            className="ecosme-card p-6 max-w-lg w-full space-y-4 text-xs"
          >
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h2 className="text-base font-bold text-[#123B2A]">
                Edit Machine: {editingMachine.code}
              </h2>
              <button
                type="button"
                onClick={() => setEditingMachine(null)}
                className="p-1 rounded hover:bg-slate-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Machine Name
              </label>
              <input
                type="text"
                required
                value={editingMachine.name}
                onChange={(e) =>
                  setEditingMachine({ ...editingMachine, name: e.target.value })
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Location Zone
                </label>
                <input
                  type="text"
                  required
                  value={editingMachine.location_zone}
                  onChange={(e) =>
                    setEditingMachine({
                      ...editingMachine,
                      location_zone: e.target.value,
                    })
                  }
                  className="w-full rounded-lg border border-slate-300 px-3 py-2"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Rated Power (kW)
                </label>
                <input
                  type="number"
                  step="0.5"
                  required
                  value={editingMachine.rated_power_kw}
                  onChange={(e) =>
                    setEditingMachine({
                      ...editingMachine,
                      rated_power_kw: Number(e.target.value),
                    })
                  }
                  className="w-full rounded-lg border border-slate-300 px-3 py-2"
                />
              </div>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Efficiency &amp; Maintenance Notes
              </label>
              <textarea
                rows={3}
                value={editingMachine.efficiency_notes}
                onChange={(e) =>
                  setEditingMachine({
                    ...editingMachine,
                    efficiency_notes: e.target.value,
                  })
                }
                className="w-full rounded-lg border border-slate-300 px-3 py-2"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditingMachine(null)}
                className="px-4 py-2 rounded-lg border border-slate-300 font-semibold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-lg bg-[#123B2A] text-white font-semibold"
              >
                Save Changes
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Add Machine Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 flex items-center justify-center p-4">
          <form
            onSubmit={handleAddMachine}
            className="ecosme-card p-6 max-w-lg w-full space-y-4 text-xs"
          >
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h2 className="text-base font-bold text-[#123B2A]">
                Register New Industrial Machine
              </h2>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="p-1 rounded hover:bg-slate-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Machine Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Heat Recovery Chiller #2"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Machine Code
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., MCH-CHL-06"
                  value={newCode}
                  onChange={(e) => setNewCode(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Electrical Phase
                </label>
                <select
                  value={newPhase}
                  onChange={(e) =>
                    setNewPhase(
                      e.target.value as "THREE_PHASE" | "SINGLE_PHASE"
                    )
                  }
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2"
                >
                  <option value="THREE_PHASE">THREE_PHASE (380V)</option>
                  <option value="SINGLE_PHASE">SINGLE_PHASE (220V)</option>
                </select>
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Rated Power (kW)
                </label>
                <input
                  type="number"
                  step="0.5"
                  required
                  value={newRatedKw}
                  onChange={(e) => setNewRatedKw(Number(e.target.value))}
                  className="w-full rounded-lg border border-slate-300 px-3 py-2"
                />
              </div>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Efficiency Notes
              </label>
              <input
                type="text"
                value={newNotes}
                onChange={(e) => setNewNotes(e.target.value)}
                placeholder="Baseline sub-metering setup notes..."
                className="w-full rounded-lg border border-slate-300 px-3 py-2"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 rounded-lg border border-slate-300 font-semibold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-lg bg-[#123B2A] text-white font-semibold"
              >
                Create Machine
              </button>
            </div>
          </form>
        </div>
      )}
    </PortalShell>
  );
}
