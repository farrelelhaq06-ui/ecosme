"use client";

import React from "react";
import {
  AlertTriangle,
  Download,
  FileCheck2,
  Globe2,
  Leaf,
} from "lucide-react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";
import { DataClassificationBadge } from "@/components/DataClassificationBadge";
import { calculateCarbonFootprint } from "@/lib/calculations";
import { formatNumber } from "@/lib/formatters";
import { downloadEcoSMEReportPdf } from "@/lib/pdf-generator";

export default function SustainabilityPage() {
  const {
    organization,
    machines,
    tariffs,
    emissionFactors,
    savingsRecords,
    greenScore,
    applications,
  } = useEcoSME();

  const ef = emissionFactors[0];
  const currentConsumptionKwh = 41820;
  const baselineConsumptionKwh = 48900;
  const totalSavingsKwh = 7080;

  const carbon = calculateCarbonFootprint(
    currentConsumptionKwh,
    totalSavingsKwh,
    ef
  );

  const monthlyCarbonSeries = savingsRecords.map((rec) => ({
    month: rec.period_month.slice(0, 8),
    baselineCo2Kg: Math.round(
      rec.adjusted_baseline_kwh * ef.factor_kgco2_per_kwh
    ),
    actualCo2Kg: Math.round(
      rec.actual_consumption_kwh * ef.factor_kgco2_per_kwh
    ),
    reducedCo2Kg: Math.round(rec.energy_savings_kwh * ef.factor_kgco2_per_kwh),
  }));

  return (
    <PortalShell
      portalType="IKM"
      title="Sustainability & Scope 2 Carbon Footprint"
      subtitle="Location-based Scope 2 greenhouse gas (GHG) emissions and operational reduction estimates using published ESDM grid factors."
    >
      {/* Mandatory Non-Credit Disclaimer */}
      <div className="ecosme-card p-4 mb-6 bg-amber-50/80 border-amber-300 flex items-start justify-between gap-4 flex-wrap">
        <div className="flex items-start gap-3 max-w-4xl">
          <AlertTriangle className="h-5 w-5 text-amber-700 shrink-0 mt-0.5" />
          <p className="text-xs text-amber-950 leading-relaxed">
            <strong>Important Environmental Disclosure:</strong> Estimated CO₂e reductions are calculated using published Ministry of ESDM location-based grid emission factors for operational sustainability reporting and green-finance readiness.{" "}
            <strong>
              These figures are operational estimates and do not constitute officially certified carbon credits (SPE-GRK / Verra / Gold Standard).
            </strong>
          </p>
        </div>

        <button
          type="button"
          onClick={() =>
            downloadEcoSMEReportPdf({
              reportType: "SUSTAINABILITY_CARBON",
              organization,
              reportingPeriod: "Oct 11, 2026 – Nov 09, 2026",
              tariffIdrPerKwh: tariffs[0]?.rate_idr_per_kwh ?? 1444.7,
              totalEnergyKwh: currentConsumptionKwh,
              baselineEnergyKwh: baselineConsumptionKwh,
              verifiedSavingsKwh: 6726,
              estimatedSavingsKwh: 354,
              greenScore,
              emissionFactor: ef,
              machines,
              financingApplication: applications[0],
            })
          }
          className="inline-flex items-center gap-1.5 rounded-lg bg-[#123B2A] hover:bg-[#0D2B1E] text-white px-4 py-2 text-xs font-semibold shrink-0"
        >
          <Download className="h-4 w-4 text-[#16A36A]" />
          Download Sustainability Report (PDF)
        </button>
      </div>

      {/* Carbon KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="ecosme-card p-5 space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">
              Electricity Consumed (30d)
            </span>
            <DataClassificationBadge type="MEASURED_DEMO" />
          </div>
          <p className="text-2xl font-bold text-[#123B2A]">
            {formatNumber(carbon.energyConsumedKwh, 0)} kWh
          </p>
          <p className="text-[11px] text-slate-500">
            Gross Scope 2: {formatNumber(carbon.grossEmissionsKgCo2e, 1)} kgCO₂e
          </p>
        </div>

        <div className="ecosme-card p-5 space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">
              Electricity Saved (30d)
            </span>
            <DataClassificationBadge type="VERIFIED" customLabel="95% VERIFIED" />
          </div>
          <p className="text-2xl font-bold text-[#16A36A]">
            {formatNumber(carbon.electricitySavingsKwh, 0)} kWh
          </p>
          <p className="text-[11px] text-emerald-700 font-medium">
            14.48% reduction vs baseline
          </p>
        </div>

        <div className="ecosme-card p-5 space-y-1.5 bg-[#E8F7F0]/50 border-[#16A36A]/30">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#123B2A]">
              Est. CO₂e Emission Reduction
            </span>
            <DataClassificationBadge type="ESTIMATED" />
          </div>
          <p className="text-2xl font-bold text-[#123B2A]">
            {formatNumber(carbon.estimatedReductionKgCo2e, 1)} kgCO₂e
          </p>
          <p className="text-[11px] text-[#123B2A] font-medium">
            Equivalent to {carbon.estimatedReductionTonnesCo2e.toFixed(2)} tonnes CO₂e / 30d
          </p>
        </div>

        <div className="ecosme-card p-5 space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">
              Grid Emission Factor
            </span>
            <span className="rounded bg-slate-100 px-2 py-0.5 text-[10px] font-bold text-slate-700">
              {ef.reporting_year} ESDM
            </span>
          </div>
          <p className="text-2xl font-bold text-[#14243A]">
            {ef.factor_kgco2_per_kwh}
          </p>
          <p className="text-[11px] text-slate-500">
            {ef.unit} • {ef.grid_region}
          </p>
        </div>
      </div>

      {/* Chart + Emission Factor Provenance Card */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 ecosme-card p-5 space-y-4">
          <h2 className="text-base font-bold text-[#123B2A]">
            Monthly Scope 2 Emissions vs. Baseline (kgCO₂e)
          </h2>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={monthlyCarbonSeries}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#4B5563" }} />
                <YAxis tick={{ fontSize: 11, fill: "#4B5563" }} />
                <Tooltip />
                <Area
                  type="monotone"
                  dataKey="baselineCo2Kg"
                  name="Baseline Emissions (kgCO2e)"
                  stroke="#94A3B8"
                  fill="#F1F5F9"
                />
                <Area
                  type="monotone"
                  dataKey="actualCo2Kg"
                  name="Actual Emissions (kgCO2e)"
                  stroke="#123B2A"
                  fill="#E8F7F0"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="lg:col-span-5 ecosme-card p-5 space-y-4 text-xs">
          <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
            <Globe2 className="h-5 w-5 text-[#16A36A]" />
            <h2 className="text-base font-bold text-[#123B2A]">
              Emission Factor Metadata &amp; Provenance
            </h2>
          </div>

          <div className="space-y-2.5">
            <div>
              <span className="text-slate-500 block text-[11px]">
                Issuing Authority / Source
              </span>
              <span className="font-semibold text-slate-900">
                {ef.source_authority}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block text-[11px]">
                Publication Reference
              </span>
              <span className="font-medium text-slate-800">
                {ef.publication_reference}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-3 pt-1">
              <div className="rounded-lg bg-[#F5F8F6] p-3">
                <span className="text-slate-500 block text-[10px]">
                  Geographic Grid
                </span>
                <span className="font-semibold text-[#123B2A]">
                  {ef.grid_region}
                </span>
              </div>
              <div className="rounded-lg bg-[#F5F8F6] p-3">
                <span className="text-slate-500 block text-[10px]">
                  Reporting Year &amp; Unit
                </span>
                <span className="font-semibold text-[#123B2A]">
                  {ef.reporting_year} • {ef.factor_kgco2_per_kwh} {ef.unit}
                </span>
              </div>
            </div>
            <div>
              <span className="text-slate-500 block text-[11px]">
                Accounting Methodology / Scope
              </span>
              <span className="font-semibold text-emerald-900">
                {ef.methodology_scope}
              </span>
            </div>
            <div className="rounded-lg bg-[#F5F8F6] p-3 font-mono text-[11px] text-slate-700">
              Formula: Estimated CO₂ Reduction = {formatNumber(totalSavingsKwh, 0)} kWh ×{" "}
              {ef.factor_kgco2_per_kwh} kgCO₂e/kWh ={" "}
              <strong>{formatNumber(carbon.estimatedReductionKgCo2e, 1)} kgCO₂e</strong>
            </div>
          </div>
        </div>
      </div>
    </PortalShell>
  );
}
