"use client";

import React, { useState } from "react";
import { CheckCircle2, Settings, Zap } from "lucide-react";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";
import { formatIdr, formatNumber } from "@/lib/formatters";

export default function SettingsPage() {
  const { organization, tariffs, baselines, subscription, mutateState } =
    useEcoSME();

  const currentTariff = tariffs[0];
  const currentBaseline = baselines[0];

  const [tariffRate, setTariffRate] = useState(
    currentTariff?.rate_idr_per_kwh ?? 1444.7
  );
  const [effectiveDate, setEffectiveDate] = useState(
    currentTariff?.effective_date ?? "2026-01-01"
  );
  const [baselineKwh, setBaselineKwh] = useState(
    currentBaseline?.baseline_energy_kwh ?? 48900
  );
  const [saved, setSaved] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    await mutateState("UPDATE_TARIFF_BASELINE", {
      rate_idr_per_kwh: tariffRate,
      effective_date: effectiveDate,
      baseline_energy_kwh: baselineKwh,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <PortalShell
      portalType="IKM"
      title="Organization, Tariff & Baseline Configuration"
      subtitle="Manage applicable PLN electricity tariff schedules, normalized baseline parameters, and active SaaS/ESaaS subscription settings."
    >
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <form
          onSubmit={handleSave}
          className="lg:col-span-7 ecosme-card p-6 space-y-4 text-xs"
        >
          <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
            <Zap className="h-5 w-5 text-[#16A36A]" />
            <h2 className="text-base font-bold text-[#123B2A]">
              Applicable Electricity Tariff &amp; Baseline Configuration
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Applicable PLN Tariff Rate (IDR / kWh)
              </label>
              <input
                type="number"
                step="0.01"
                min="100"
                required
                value={tariffRate}
                onChange={(e) => setTariffRate(Number(e.target.value))}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 font-bold text-[#123B2A]"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                Tariff Effective Date
              </label>
              <input
                type="date"
                required
                value={effectiveDate}
                onChange={(e) => setEffectiveDate(e.target.value)}
                className="w-full rounded-lg border border-slate-300 px-3 py-2"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              30-Day Normalized Baseline Consumption (kWh)
            </label>
            <input
              type="number"
              step="100"
              min="1000"
              required
              value={baselineKwh}
              onChange={(e) => setBaselineKwh(Number(e.target.value))}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 font-bold text-[#123B2A]"
            />
            <p className="text-[11px] text-slate-500 mt-1">
              Used across Overview, Energy Savings, and PDF Reports for baseline comparison.
            </p>
          </div>

          <button
            type="submit"
            className="rounded-lg bg-[#123B2A] hover:bg-[#0D2B1E] text-white px-5 py-2.5 font-semibold transition-colors"
          >
            Save Tariff &amp; Baseline Configuration
          </button>

          {saved && (
            <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-3 text-emerald-900 font-medium flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-[#16A36A]" />
              Configuration saved and all dashboard cost/savings calculations updated.
            </div>
          )}
        </form>

        {/* Right: Organization & Subscription Summary */}
        <div className="lg:col-span-5 ecosme-card p-6 space-y-4 text-xs">
          <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
            <Settings className="h-5 w-5 text-[#16A36A]" />
            <h2 className="text-base font-bold text-[#123B2A]">
              Organization &amp; Subscription Profile
            </h2>
          </div>

          <div className="space-y-2.5">
            <div>
              <span className="text-slate-500 block">Organization Name</span>
              <span className="font-bold text-[#123B2A]">{organization.name}</span>
            </div>
            <div>
              <span className="text-slate-500 block">Industry &amp; Location</span>
              <span className="font-medium text-slate-800">
                {organization.industry_category} • {organization.location}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">NPWP / NIB</span>
              <span className="font-mono text-slate-700">
                {organization.tax_id_npwp} / {organization.business_license_nib}
              </span>
            </div>
            <div className="rounded-lg bg-[#E8F7F0] p-3.5 border border-[#16A36A]/30 space-y-1">
              <span className="font-bold text-[#123B2A] block">
                Active Plan: {subscription?.plan_name}
              </span>
              <p className="text-slate-700">
                SaaS Fee: <strong>{formatIdr(subscription?.monthly_price_idr ?? 699000)}/mo</strong> (Illustrative Hypothesis)
              </p>
              <p className="text-slate-700">
                ESaaS Performance Share:{" "}
                <strong>
                  {subscription?.esaas_share_percentage ?? 30}% on VERIFIED savings only
                </strong>
              </p>
            </div>
          </div>
        </div>
      </div>
    </PortalShell>
  );
}
