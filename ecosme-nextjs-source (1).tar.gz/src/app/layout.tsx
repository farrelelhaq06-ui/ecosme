import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { EcoSMEProvider } from "@/components/EcoSMEProvider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "EcoSME | Digital Energy Efficiency & Green Finance Readiness Platform for SMEs",
  description:
    "EcoSME helps Small and Medium Industries (IKM) monitor energy consumption, validate energy savings, calculate Scope 2 emissions, generate Provisional Green Score reports, and prepare for consented green financing.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col bg-[#F5F8F6] text-[#111827]">
        <EcoSMEProvider>{children}</EcoSMEProvider>
      </body>
    </html>
  );
}
