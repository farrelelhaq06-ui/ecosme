"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  Activity,
  ArrowRight,
  Building2,
  Factory,
  Lock,
  ShieldCheck,
} from "lucide-react";
import { PublicNavbar } from "@/components/PublicNavbar";
import { PublicFooter } from "@/components/PublicFooter";
import { useEcoSME } from "@/components/EcoSMEProvider";

export default function LoginPage() {
  const router = useRouter();
  const { switchUserRole, session } = useEcoSME();
  const [email, setEmail] = useState("budi.santoso@sinartekstil-demo.co.id");
  const [password, setPassword] = useState("••••••••••••");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleQuickRoleLogin = async (userId: string, redirectPath: string) => {
    setLoading(true);
    setError(null);
    await switchUserRole(userId);
    setLoading(false);
    router.push(redirectPath);
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Invalid credentials");
        setLoading(false);
        return;
      }
      await switchUserRole(data.user.id);
      if (data.user.role === "BANK_OFFICER") {
        router.push("/bank/overview");
      } else if (data.user.role === "ECOSME_ADMIN") {
        router.push("/admin/overview");
      } else {
        router.push("/app/overview");
      }
    } catch {
      setError("Authentication request failed.");
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F5F8F6]">
      <PublicNavbar />
      <main className="flex-1 max-w-6xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: Login Form */}
          <div className="lg:col-span-6 ecosme-card p-6 sm:p-8 space-y-6">
            <div className="space-y-1">
              <span className="text-xs font-bold uppercase tracking-wider text-[#16A36A]">
                Enterprise Role Authentication
              </span>
              <h1 className="text-2xl font-bold text-[#123B2A]">
                Sign In to EcoSME
              </h1>
              <p className="text-xs sm:text-sm text-[#4B5563]">
                Current active session:{" "}
                <strong className="text-[#123B2A]">
                  {session.user.name} ({session.user.role})
                </strong>
              </p>
            </div>

            {error && (
              <div className="rounded-lg bg-red-50 border border-red-200 p-3 text-xs text-red-800 font-medium">
                {error}
              </div>
            )}

            <form onSubmit={handleFormSubmit} className="space-y-4">
              <div>
                <label
                  htmlFor="login-email"
                  className="block text-xs font-semibold text-slate-700 mb-1"
                >
                  Work Email Address
                </label>
                <input
                  id="login-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900"
                />
              </div>

              <div>
                <label
                  htmlFor="login-password"
                  className="block text-xs font-semibold text-slate-700 mb-1"
                >
                  Password
                </label>
                <input
                  id="login-password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-900"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full inline-flex items-center justify-center gap-2 rounded-lg bg-[#123B2A] hover:bg-[#0D2B1E] text-white py-2.5 text-sm font-semibold transition-colors"
              >
                <Lock className="h-4 w-4 text-[#16A36A]" />
                {loading ? "Signing In..." : "Sign In with Email"}
              </button>
            </form>

            <p className="text-xs text-slate-500 text-center pt-2 border-t border-slate-200">
              New industrial facility?{" "}
              <Link
                href="/register"
                className="font-semibold text-[#123B2A] hover:underline"
              >
                Register an IKM Organization →
              </Link>
            </p>
          </div>

          {/* Right: One-Click Demo Role Switcher */}
          <div className="lg:col-span-6 space-y-4">
            <div className="ecosme-card p-6 space-y-4">
              <div>
                <span className="inline-block rounded bg-amber-100 text-amber-900 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider">
                  Controlled Demo Mode
                </span>
                <h2 className="text-lg font-bold text-[#123B2A] mt-1">
                  Instant One-Click Role Evaluation
                </h2>
                <p className="text-xs text-slate-600 mt-0.5">
                  Test server-side Role-Based Access Control (RBAC), organization isolation, and bank consent gating across all three stakeholder roles:
                </p>
              </div>

              <div className="space-y-3">
                <button
                  type="button"
                  disabled={loading}
                  onClick={() =>
                    handleQuickRoleLogin("usr-ikm-budi", "/app/overview")
                  }
                  className="w-full text-left rounded-lg border border-[#DDE5DF] hover:border-[#16A36A] bg-[#F5F8F6] hover:bg-[#E8F7F0]/50 p-4 transition-all flex items-center justify-between"
                >
                  <div className="flex items-start gap-3">
                    <Factory className="h-5 w-5 text-[#123B2A] shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-bold text-[#123B2A]">
                        1. IKM / Factory Owner — Ir. Budi Santoso
                      </p>
                      <p className="text-xs text-slate-600">
                        Organization: <strong>PT Sinar Tekstil Mandiri (DEMO)</strong> • Grade A (83/100)
                      </p>
                      <p className="text-[11px] text-emerald-700 font-medium mt-0.5">
                        Access: Full IKM Dashboard (/app/*), IoT Devices, Consent &amp; Reports
                      </p>
                    </div>
                  </div>
                  <ArrowRight className="h-4 w-4 text-[#123B2A] shrink-0" />
                </button>

                <button
                  type="button"
                  disabled={loading}
                  onClick={() =>
                    handleQuickRoleLogin("usr-bank-arief", "/bank/overview")
                  }
                  className="w-full text-left rounded-lg border border-[#DDE5DF] hover:border-[#14243A] bg-[#F5F8F6] hover:bg-slate-100 p-4 transition-all flex items-center justify-between"
                >
                  <div className="flex items-start gap-3">
                    <Building2 className="h-5 w-5 text-[#14243A] shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-bold text-[#14243A]">
                        2. Partner Bank Officer — Arief Rahman, CFA
                      </p>
                      <p className="text-xs text-slate-600">
                        Institution: <strong>Bank Nusantara Hijau — Green Lending Desk</strong>
                      </p>
                      <p className="text-[11px] text-slate-700 font-medium mt-0.5">
                        Access: Bank Portal (/bank/*) • Views ONLY consented IKM profiles
                      </p>
                    </div>
                  </div>
                  <ArrowRight className="h-4 w-4 text-[#14243A] shrink-0" />
                </button>

                <button
                  type="button"
                  disabled={loading}
                  onClick={() =>
                    handleQuickRoleLogin("usr-admin-nadia", "/admin/overview")
                  }
                  className="w-full text-left rounded-lg border border-[#DDE5DF] hover:border-[#123B2A] bg-[#F5F8F6] hover:bg-[#E8F7F0]/40 p-4 transition-all flex items-center justify-between"
                >
                  <div className="flex items-start gap-3">
                    <ShieldCheck className="h-5 w-5 text-[#16A36A] shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm font-bold text-[#123B2A]">
                        3. EcoSME Administrator — Nadia Putri, M.T.
                      </p>
                      <p className="text-xs text-slate-600">
                        Organization: <strong>EcoSME Platform Governance</strong>
                      </p>
                      <p className="text-[11px] text-emerald-700 font-medium mt-0.5">
                        Access: Admin Portal (/admin/*), Methodology Weights, Fleet &amp; Audit Logs
                      </p>
                    </div>
                  </div>
                  <ArrowRight className="h-4 w-4 text-[#123B2A] shrink-0" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
      <PublicFooter />
    </div>
  );
}
