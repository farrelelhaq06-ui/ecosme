"use client";

import React, { useState } from "react";
import Link from "next/link";
import {
  AlertTriangle,
  ArrowRight,
  Calculator,
  CheckCircle2,
  Info,
  Landmark,
  PiggyBank,
} from "lucide-react";
import { PublicNavbar } from "@/components/PublicNavbar";
import { PublicFooter } from "@/components/PublicFooter";
import { calculateESaaSShare } from "@/lib/calculations";
import { formatIdr } from "@/lib/formatters";
import { useEcoSME } from "@/components/EcoSMEProvider";

export default function PricingPage() {
  const { platformConfig } = useEcoSME();
  const [monthlySavingsInput, setMonthlySavingsInput] = useState<number>(2000000);
  const [sharePctInput, setSharePctInput] = useState<number>(
    platformConfig.default_esaas_share_pct || 30
  );
  const [verificationMode, setVerificationMode] = useState<
    "VERIFIED" | "ESTIMATED"
  >("VERIFIED");

  const esaasCalc = calculateESaaSShare(
    monthlySavingsInput,
    verificationMode,
    sharePctInput
  );

  return (
    <div className="min-h-screen flex flex-col bg-[#F5F8F6]">
      <PublicNavbar />
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
        <div className="max-w-3xl space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-[#16A36A]">
            Business Model &amp; Commercial Hypotheses
          </span>
          <h1 className="text-3xl sm:text-4xl font-bold text-[#123B2A] tracking-tight">
            Transparent B2B SaaS Subscriptions &amp; Performance-Aligned ESaaS
          </h1>
          <p className="text-sm sm:text-base text-[#4B5563] leading-relaxed">
            EcoSME is designed around three configurable commercial models. All subscription prices and commission rates below are transparent product-development hypotheses and can be adjusted in the Admin Portal.
          </p>
        </div>

        {/* Stream A: B2B SaaS Subscription Plans */}
        <section className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h2 className="text-xl font-bold text-[#123B2A]">
                A. B2B SaaS Subscription Plans (Illustrative Hypotheses)
              </h2>
              <p className="text-xs text-slate-600">
                Configurable monthly tiers scaled to factory size and green financing readiness needs.
              </p>
            </div>
            <span className="inline-flex items-center gap-1.5 rounded-md bg-amber-50 border border-amber-300 px-3 py-1 text-xs font-medium text-amber-900">
              <Info className="h-3.5 w-3.5 text-amber-700" />
              Configurable Product Hypotheses — Not Hard-Coded Market Prices
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {platformConfig.plans.map((plan) => (
              <div
                key={plan.id}
                className={`ecosme-card p-6 flex flex-col justify-between ${
                  plan.id === "PRO" ? "ring-2 ring-[#16A36A]" : ""
                }`}
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-bold text-[#123B2A]">
                      {plan.name}
                    </h3>
                    <span className="rounded bg-[#E8F7F0] text-[#123B2A] px-2 py-0.5 text-[11px] font-bold">
                      Up to {plan.max_machines} Machines
                    </span>
                  </div>
                  <div>
                    <span className="text-3xl font-bold text-[#123B2A]">
                      {formatIdr(plan.monthly_price_idr)}
                    </span>
                    <span className="text-xs text-slate-500"> / month</span>
                  </div>
                  <ul className="space-y-2.5 text-xs text-slate-700 pt-2">
                    {plan.features.map((feat) => (
                      <li key={feat} className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 text-[#16A36A] shrink-0" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-6 mt-6 border-t border-slate-100">
                  <Link
                    href="/register"
                    className="w-full inline-flex items-center justify-center gap-1.5 rounded-lg bg-[#123B2A] hover:bg-[#0D2B1E] text-white py-2.5 text-xs font-semibold transition-colors"
                  >
                    Start with {plan.name} <ArrowRight className="h-3.5 w-3.5" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Stream C: Interactive Energy Savings-as-a-Service (ESaaS) Simulator */}
        <section className="ecosme-card p-6 sm:p-8 space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-4">
            <div className="flex items-start gap-3">
              <div className="h-10 w-10 rounded-lg bg-[#E8F7F0] flex items-center justify-center text-[#123B2A] shrink-0">
                <Calculator className="h-5 w-5 text-[#16A36A]" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-[#123B2A]">
                  C. Energy Savings-as-a-Service (ESaaS) Interactive Calculator
                </h2>
                <p className="text-xs sm:text-sm text-[#4B5563]">
                  Performance-based service model where EcoSME shares in verified monthly electricity cost savings.{" "}
                  <strong className="text-[#123B2A]">
                    Strict Policy: Never charge based on unverified savings.
                  </strong>
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-6 space-y-4">
              <div>
                <label
                  htmlFor="esaas-savings-input"
                  className="block text-xs font-semibold text-slate-700 mb-1"
                >
                  Monthly Electricity Savings (IDR) — Illustrative default: Rp2,000,000
                </label>
                <input
                  id="esaas-savings-input"
                  type="number"
                  step={100000}
                  min={0}
                  value={monthlySavingsInput}
                  onChange={(e) => setMonthlySavingsInput(Number(e.target.value))}
                  className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm font-semibold text-[#123B2A]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="esaas-share-input"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    EcoSME Service Share (%)
                  </label>
                  <input
                    id="esaas-share-input"
                    type="number"
                    min={5}
                    max={50}
                    value={sharePctInput}
                    onChange={(e) => setSharePctInput(Number(e.target.value))}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm font-semibold text-[#123B2A]"
                  />
                </div>

                <div>
                  <label
                    htmlFor="esaas-verification-select"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    Savings Verification Status
                  </label>
                  <select
                    id="esaas-verification-select"
                    value={verificationMode}
                    onChange={(e) =>
                      setVerificationMode(
                        e.target.value as "VERIFIED" | "ESTIMATED"
                      )
                    }
                    className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm font-semibold text-[#123B2A]"
                  >
                    <option value="VERIFIED">
                      VERIFIED (True Active Power Metered)
                    </option>
                    <option value="ESTIMATED">
                      ESTIMATED (Unverified / CT-Only Sensor)
                    </option>
                  </select>
                </div>
              </div>
            </div>

            <div className="lg:col-span-6 rounded-xl bg-[#F5F8F6] border border-[#DDE5DF] p-5 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-white rounded-lg p-3.5 border border-slate-200">
                  <span className="text-[11px] text-slate-500 block">
                    Monthly Savings
                  </span>
                  <span className="text-base font-bold text-[#123B2A]">
                    {formatIdr(monthlySavingsInput)}
                  </span>
                </div>
                <div className="bg-white rounded-lg p-3.5 border border-slate-200">
                  <span className="text-[11px] text-slate-500 block">
                    EcoSME Fee ({esaasCalc.ecosmeSharePercentage}%)
                  </span>
                  <span className="text-base font-bold text-[#16A36A]">
                    {formatIdr(esaasCalc.ecosmeFeeIdr)}
                  </span>
                </div>
                <div className="bg-[#E8F7F0] rounded-lg p-3.5 border border-[#16A36A]/30">
                  <span className="text-[11px] font-semibold text-[#123B2A] block">
                    IKM Retains ({100 - esaasCalc.ecosmeSharePercentage}%)
                  </span>
                  <span className="text-base font-bold text-[#123B2A]">
                    {formatIdr(esaasCalc.ikmRetainedSavingsIdr)}
                  </span>
                </div>
              </div>

              <div
                className={`rounded-lg p-3 text-xs flex items-start gap-2 ${
                  verificationMode === "VERIFIED"
                    ? "bg-emerald-50 text-emerald-900 border border-emerald-200"
                    : "bg-amber-50 text-amber-900 border border-amber-300"
                }`}
              >
                <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                <span>{esaasCalc.policyNote}</span>
              </div>
            </div>
          </div>
        </section>

        {/* Stream B: Green Finance Referral / Channeling Hypothesis */}
        <section className="ecosme-card p-6 sm:p-8 bg-[#14243A] text-white space-y-3">
          <div className="flex items-center gap-2.5 text-emerald-400 text-xs font-bold uppercase tracking-wider">
            <Landmark className="h-4 w-4" />
            <span>B. Green Finance Referral / Channeling Commission Hypothesis</span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold text-white">
            Proposed {platformConfig.referral_commission_min_pct}%–{platformConfig.referral_commission_max_pct}% Partner Financial Institution Channeling Fee (Business Hypothesis)
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-4xl">
            Under EcoSME&apos;s fintech product strategy, EcoSME may receive a 1%–2% referral or technical-readiness channeling fee from partner financial institutions when green equipment financing is successfully disbursed through a formal partnership agreement.{" "}
            <strong className="text-white">
              Important Disclosure:
            </strong>{" "}
            This 1%–2% arrangement is an illustrative business hypothesis subject to formal institutional agreement, OJK financial-services regulations, and legal review. No active commercial commission agreement is claimed in this demo environment.
          </p>
        </section>
      </main>
      <PublicFooter />
    </div>
  );
}
