import React from "react";
import Link from "next/link";
import {
  Activity,
  Award,
  Building2,
  CheckCircle2,
  Factory,
  Lock,
  ShieldCheck,
} from "lucide-react";
import { PublicNavbar } from "@/components/PublicNavbar";
import { PublicFooter } from "@/components/PublicFooter";

export default function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col bg-[#F5F8F6]">
      <PublicNavbar />
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
        <div className="max-w-3xl space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-[#16A36A]">
            About EcoSME &amp; Platform Governance
          </span>
          <h1 className="text-3xl sm:text-4xl font-bold text-[#123B2A] tracking-tight">
            Bridging Industrial Energy Efficiency and Sustainable SME Finance
          </h1>
          <p className="text-base text-[#4B5563] leading-relaxed">
            EcoSME is positioned as the{" "}
            <strong>
              &ldquo;Digital Energy Efficiency and Green Finance Readiness Platform for Small and Medium Industries.&rdquo;
            </strong>
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="ecosme-card p-6 space-y-3">
            <h2 className="text-lg font-bold text-[#123B2A]">
              Our Mission &amp; Core Philosophy
            </h2>
            <p className="text-sm text-[#4B5563] leading-relaxed">
              Small and Medium Industries (IKM) form the backbone of Indonesian manufacturing, yet they often lack sub-metering visibility and standardized environmental documentation. EcoSME empowers factory owners to measure electricity usage accurately, validate operational savings, and compile credible readiness dossiers for green equipment upgrades.
            </p>
          </div>

          <div className="ecosme-card p-6 space-y-3">
            <h2 className="text-lg font-bold text-[#123B2A]">
              Clear Boundaries of Responsibility
            </h2>
            <p className="text-sm text-[#4B5563] leading-relaxed">
              EcoSME strictly separates technical energy verification from banking credit decisions:
            </p>
            <ul className="space-y-2 text-xs text-slate-700">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-[#16A36A] shrink-0" />
                <span>
                  <strong>What EcoSME Does:</strong> Sub-meter telemetry ingestion, normalized baseline savings analysis, Scope 2 emissions calculation, and Provisional Green Score generation.
                </span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-[#16A36A] shrink-0" />
                <span>
                  <strong>What Partner Banks Do:</strong> Financial due diligence, KYB/KYC compliance, collateral valuation, and independent loan approval or rejection decisions.
                </span>
              </li>
            </ul>
          </div>
        </div>

        <div className="ecosme-card p-6 sm:p-8 space-y-4">
          <div className="flex items-center gap-2.5 text-[#123B2A]">
            <Lock className="h-5 w-5 text-[#16A36A]" />
            <h2 className="text-xl font-bold">
              Data Privacy, Organization Isolation &amp; Explicit Consent
            </h2>
          </div>
          <p className="text-sm text-[#4B5563] leading-relaxed">
            Every organization&apos;s machine inventory, telemetry readings, and financial records are isolated at the server level. Partner financial institutions cannot browse or discover an IKM&apos;s data unless the IKM Owner explicitly grants a scoped{" "}
            <code className="bg-slate-100 px-1.5 py-0.5 rounded text-xs">
              DataSharingConsent
            </code>{" "}
            authorization—which can be revoked at any time with immediate effect.
          </p>
        </div>
      </main>
      <PublicFooter />
    </div>
  );
}
