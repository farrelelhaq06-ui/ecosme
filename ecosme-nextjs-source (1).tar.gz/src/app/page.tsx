import React from "react";
import Link from "next/link";
import {
  Activity,
  ArrowRight,
  Award,
  BarChart3,
  Building2,
  CheckCircle2,
  Cpu,
  Factory,
  Gauge,
  Landmark,
  Leaf,
  PiggyBank,
  ShieldCheck,
  TrendingDown,
  Zap,
} from "lucide-react";
import { PublicNavbar } from "@/components/PublicNavbar";
import { PublicFooter } from "@/components/PublicFooter";
import { DataClassificationBadge } from "@/components/DataClassificationBadge";
import { LandingLoginSidebar } from "@/components/LandingLoginSidebar";

export default function LandingPage() {
  return (
    <div className="min-h-screen flex flex-col bg-[#F5F8F6]">
      <PublicNavbar />

      <div className="flex-1 flex flex-col lg:flex-row">
        <LandingLoginSidebar />
        <main className="flex-1 min-w-0">
        {/* 1. HERO SECTION */}
        <section className="bg-[#123B2A] text-white py-16 sm:py-24 border-b border-emerald-900">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
              <div className="lg:col-span-7 space-y-6">
                <p className="text-xs font-semibold uppercase tracking-widest text-emerald-300">
                  Digital Energy Efficiency &amp; Green Finance Readiness Platform for Small and Medium Industries
                </p>
                <h1 className="text-3xl sm:text-5xl font-bold tracking-tight text-white leading-[1.12]">
                  Make Energy Efficiency Measurable. Make Green Growth Possible.
                </h1>
                <p className="text-base sm:text-lg text-emerald-100/90 leading-relaxed max-w-2xl">
                  EcoSME helps Small and Medium Industries (IKM) monitor machine-level electricity consumption, validate operational energy savings, quantify Scope 2 carbon reductions, and prepare standardized{" "}
                  <strong className="text-white">Provisional Green Score</strong> profiles for partner financial institutions.
                </p>

                {/* 3 & 4. PRIMARY & SECONDARY CTAs */}
                <div className="flex flex-wrap items-center gap-4 pt-2">
                  <Link
                    id="cta-get-started"
                    href="/register"
                    className="inline-flex items-center gap-2 rounded-lg bg-[#16A36A] hover:bg-emerald-500 px-6 py-3.5 text-sm font-semibold text-white transition-colors shadow-sm"
                  >
                    Get Started
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                  <Link
                    id="cta-explore-platform"
                    href="/app/overview"
                    className="inline-flex items-center gap-2 rounded-lg bg-white/10 hover:bg-white/20 border border-emerald-400/30 px-6 py-3.5 text-sm font-semibold text-white transition-colors"
                  >
                    Explore Platform
                  </Link>
                </div>

                {/* Role Quick Launchers */}
                <div className="pt-4 border-t border-emerald-800/80 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <Link
                    href="/app/overview"
                    className="rounded-lg bg-[#0D2B1E] hover:bg-emerald-950 border border-emerald-800 p-3 flex items-center justify-between transition-colors"
                  >
                    <div>
                      <span className="font-semibold text-white block">1. IKM Factory Portal</span>
                      <span className="text-emerald-300">PT Sinar Tekstil (Demo)</span>
                    </div>
                    <ArrowRight className="h-4 w-4 text-[#16A36A]" />
                  </Link>
                  <Link
                    href="/bank/overview"
                    className="rounded-lg bg-[#0D2B1E] hover:bg-emerald-950 border border-emerald-800 p-3 flex items-center justify-between transition-colors"
                  >
                    <div>
                      <span className="font-semibold text-white block">2. Partner Bank Portal</span>
                      <span className="text-emerald-300">Consented Pipeline</span>
                    </div>
                    <ArrowRight className="h-4 w-4 text-[#16A36A]" />
                  </Link>
                  <Link
                    href="/admin/overview"
                    className="rounded-lg bg-[#0D2B1E] hover:bg-emerald-950 border border-emerald-800 p-3 flex items-center justify-between transition-colors"
                  >
                    <div>
                      <span className="font-semibold text-white block">3. Admin Governance</span>
                      <span className="text-emerald-300">IoT &amp; Methodology</span>
                    </div>
                    <ArrowRight className="h-4 w-4 text-[#16A36A]" />
                  </Link>
                </div>
              </div>

              {/* Right Column: Live Deterministic Telemetry Summary Card */}
              <div className="lg:col-span-5">
                <div className="rounded-xl bg-white text-[#111827] p-6 shadow-xl border border-emerald-900/20 space-y-5">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                    <div>
                      <span className="text-[11px] font-bold uppercase tracking-wider text-[#16A36A]">
                        Sample Industrial Profile
                      </span>
                      <h2 className="text-base font-bold text-[#123B2A]">
                        PT Sinar Tekstil Mandiri (Bandung)
                      </h2>
                    </div>
                    <DataClassificationBadge type="DEMO_FIXTURE" />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="rounded-lg bg-[#F5F8F6] p-3.5 border border-[#DDE5DF]">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-slate-600">30-Day Consumption</span>
                        <DataClassificationBadge type="MEASURED_DEMO" customLabel="DEMO" />
                      </div>
                      <p className="text-xl font-bold text-[#123B2A] mt-1">41,820 kWh</p>
                      <p className="text-[11px] text-emerald-700 font-medium">
                        ↓ 14.48% vs 48,900 kWh baseline
                      </p>
                    </div>
                    <div className="rounded-lg bg-[#F5F8F6] p-3.5 border border-[#DDE5DF]">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-slate-600">Verified Cost Savings</span>
                        <DataClassificationBadge type="VERIFIED" />
                      </div>
                      <p className="text-xl font-bold text-[#123B2A] mt-1">Rp9.72M</p>
                      <p className="text-[11px] text-slate-500">
                        +Rp511K estimated (CT sensor)
                      </p>
                    </div>
                    <div className="rounded-lg bg-[#F5F8F6] p-3.5 border border-[#DDE5DF]">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-slate-600">Scope 2 CO₂e Avoided</span>
                        <DataClassificationBadge type="ESTIMATED" />
                      </div>
                      <p className="text-xl font-bold text-[#123B2A] mt-1">5,522.4 kg</p>
                      <p className="text-[11px] text-slate-500">
                        0.78 kgCO₂e/kWh (ESDM Jamali)
                      </p>
                    </div>
                    <div className="rounded-lg bg-[#E8F7F0] p-3.5 border border-[#16A36A]/40">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-[#123B2A]">
                          Green Score
                        </span>
                        <span className="rounded bg-[#123B2A] text-white px-1.5 py-0.5 text-[10px] font-bold">
                          GRADE A
                        </span>
                      </div>
                      <p className="text-xl font-bold text-[#123B2A] mt-1">83 / 100</p>
                      <p className="text-[11px] text-[#123B2A] font-medium">
                        Provisional Green Score (v1.2)
                      </p>
                    </div>
                  </div>

                  <div className="rounded-lg bg-slate-50 border border-slate-200 p-3 text-xs text-slate-600 leading-relaxed">
                    <strong className="text-slate-800">Positioning Note:</strong>{" "}
                    EcoSME provides standardized energy-performance and financing-readiness data. Credit underwriting and loan approval decisions remain exclusively with partner banks.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 5. PROBLEM SECTION */}
        <section className="py-16 bg-white border-b border-[#DDE5DF]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mb-12">
              <span className="text-xs font-bold uppercase tracking-wider text-[#16A36A]">
                The Industrial Challenge
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold text-[#123B2A] mt-1">
                Why Small and Medium Industries Struggle with Energy Efficiency &amp; Green Capital
              </h2>
              <p className="text-sm sm:text-base text-[#4B5563] mt-2">
                Indonesian manufacturing SMEs (IKM) face compounding operational pressures without the granular data required to justify equipment upgrades.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="ecosme-card p-6 space-y-3">
                <div className="h-10 w-10 rounded-lg bg-red-50 border border-red-200 flex items-center justify-center text-red-700">
                  <Zap className="h-5 w-5" />
                </div>
                <h3 className="text-lg font-bold text-[#123B2A]">
                  1. Rising Industrial Electricity Costs
                </h3>
                <p className="text-sm text-[#4B5563] leading-relaxed">
                  Electricity accounts for 18%–35% of production costs in textile, metalworking, and food processing IKMs. Aging motors, compressed air leaks, and low power factor (<code className="text-xs">PF &lt; 0.85</code>) silently erode operating margins.
                </p>
              </div>

              <div className="ecosme-card p-6 space-y-3">
                <div className="h-10 w-10 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-700">
                  <Gauge className="h-5 w-5" />
                </div>
                <h3 className="text-lg font-bold text-[#123B2A]">
                  2. Blind Spots of Monthly Utility Bills
                </h3>
                <p className="text-sm text-[#4B5563] leading-relaxed">
                  A single aggregate monthly PLN bill cannot show which dyeing line, compressor, or oven is wasting energy, nor can current-only CT clamps measure true active power (<code className="text-xs">V × I × PF</code>) needed for verified savings.
                </p>
              </div>

              <div className="ecosme-card p-6 space-y-3">
                <div className="h-10 w-10 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-800">
                  <Landmark className="h-5 w-5" />
                </div>
                <h3 className="text-lg font-bold text-[#123B2A]">
                  3. Friction in Green Financing Access
                </h3>
                <p className="text-sm text-[#4B5563] leading-relaxed">
                  Financial institutions have green lending mandates but lack standardized, tamper-evident energy baselines and Scope 2 emissions data from SME borrowers to underwrite energy-efficiency capex loans.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* 6. SOLUTION SECTION — THREE STAKEHOLDER ECOSYSTEM */}
        <section className="py-16 bg-[#F5F8F6] border-b border-[#DDE5DF]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mb-12">
              <span className="text-xs font-bold uppercase tracking-wider text-[#16A36A]">
                The EcoSME Solution
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold text-[#123B2A] mt-1">
                Connecting Factory Floors, Energy Intelligence, and Sustainable Finance
              </h2>
              <p className="text-sm sm:text-base text-[#4B5563] mt-2">
                EcoSME bridges the technical verification gap between industrial operations and green lending teams while preserving strict organization-level data privacy.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="ecosme-card p-6 border-t-4 border-t-[#123B2A] space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-[#123B2A]">
                    Stakeholder 01
                  </span>
                  <Factory className="h-5 w-5 text-[#123B2A]" />
                </div>
                <h3 className="text-lg font-bold text-[#123B2A]">
                  IKM / Factory Owners
                </h3>
                <p className="text-sm text-[#4B5563] leading-relaxed">
                  Monitor machine-by-machine electricity usage, receive threshold alerts for power spikes, quantify normalized kWh and IDR savings, and retain full control over data-sharing consent.
                </p>
                <Link
                  href="/app/overview"
                  className="inline-flex items-center gap-1 text-xs font-semibold text-[#16A36A] hover:underline pt-1"
                >
                  Open IKM Dashboard <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>

              <div className="ecosme-card p-6 border-t-4 border-t-[#16A36A] space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-[#16A36A]">
                    Stakeholder 02
                  </span>
                  <Activity className="h-5 w-5 text-[#16A36A]" />
                </div>
                <h3 className="text-lg font-bold text-[#123B2A]">
                  EcoSME Platform Engine
                </h3>
                <p className="text-sm text-[#4B5563] leading-relaxed">
                  Ingests single-phase and three-phase telemetry, normalizes baselines for operating hours and production output, computes Scope 2 CO₂e metrics, and generates transparent{" "}
                  <strong>Provisional Green Score</strong> dossiers.
                </p>
                <Link
                  href="/how-it-works"
                  className="inline-flex items-center gap-1 text-xs font-semibold text-[#16A36A] hover:underline pt-1"
                >
                  Inspect Methodology <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>

              <div className="ecosme-card p-6 border-t-4 border-t-[#14243A] space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-[#14243A]">
                    Stakeholder 03
                  </span>
                  <Building2 className="h-5 w-5 text-[#14243A]" />
                </div>
                <h3 className="text-lg font-bold text-[#14243A]">
                  Partner Financial Institutions
                </h3>
                <p className="text-sm text-[#4B5563] leading-relaxed">
                  Access explicitly consented IKM energy-performance profiles, verify payback assumptions on equipment retrofits, and record independent credit review decisions.
                </p>
                <Link
                  href="/bank/overview"
                  className="inline-flex items-center gap-1 text-xs font-semibold text-[#14243A] hover:underline pt-1"
                >
                  Open Partner Bank Portal <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* 7. HOW IT WORKS SECTION */}
        <section className="py-16 bg-white border-b border-[#DDE5DF]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mb-10">
              <span className="text-xs font-bold uppercase tracking-wider text-[#16A36A]">
                End-to-End Platform Workflow
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold text-[#123B2A] mt-1">
                How EcoSME Works: From Sub-Metering to Green Finance Readiness
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              {[
                {
                  step: "01",
                  title: "Connect Energy Devices",
                  desc: "Pair ESP32 + PZEM-004T (1-phase) or Modbus 3-Phase energy meters to production machines with hashed API credentials.",
                },
                {
                  step: "02",
                  title: "Collect & Analyze Data",
                  desc: "Measure voltage (V), current (A), power factor (PF), active power (kW), and kWh consumption across shifts.",
                },
                {
                  step: "03",
                  title: "Identify & Validate Savings",
                  desc: "Detect abnormal spikes and calculate normalized energy savings against operating hours and production output.",
                },
                {
                  step: "04",
                  title: "Generate Sustainability & Score",
                  desc: "Compute Scope 2 CO₂e reductions using published ESDM grid factors and generate a 5-dimension Provisional Green Score.",
                },
                {
                  step: "05",
                  title: "Prepare Financing Profile",
                  desc: "Compile required technical documents and grant revocable, explicit consent to share readiness reports with partner banks.",
                },
              ].map((item) => (
                <div key={item.step} className="ecosme-card p-5 flex flex-col justify-between">
                  <div>
                    <span className="inline-block rounded bg-[#E8F7F0] text-[#123B2A] font-mono text-xs font-bold px-2 py-1 mb-3">
                      STEP {item.step}
                    </span>
                    <h3 className="text-base font-bold text-[#123B2A] mb-2">
                      {item.title}
                    </h3>
                    <p className="text-xs text-[#4B5563] leading-relaxed">
                      {item.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* 8. KEY FEATURES SECTION */}
        <section className="py-16 bg-[#F5F8F6] border-b border-[#DDE5DF]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mb-12">
              <span className="text-xs font-bold uppercase tracking-wider text-[#16A36A]">
                Core Platform Modules
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold text-[#123B2A] mt-1">
                Six Integrated Capabilities Built for Industrial Rigor
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  icon: Gauge,
                  title: "Real-Time & Historical Energy Monitoring",
                  desc: "Track Voltage (V), Current (A), Active Power (W/kW), Power Factor, and accumulated kWh with transparent engineering distinction between true active-power meters and current-only sensors.",
                  href: "/app/energy",
                },
                {
                  icon: Cpu,
                  title: "Machine Performance Monitoring",
                  desc: "Manage industrial equipment inventories, link IoT gateways, track online/offline heartbeats, and compare machine-level consumption against rated kW capacity.",
                  href: "/app/machines",
                },
                {
                  icon: PiggyBank,
                  title: "Normalized Energy Savings Analysis",
                  desc: "Compare current consumption against operating-hour and production-normalized baselines. Strictly separates ESTIMATED projections from VERIFIED meter-backed savings.",
                  href: "/app/savings",
                },
                {
                  icon: Leaf,
                  title: "Carbon Footprint Estimation",
                  desc: "Calculate Scope 2 location-based GHG reductions using documented Ministry of ESDM grid emission factors with full source, region, and year provenance.",
                  href: "/app/sustainability",
                },
                {
                  icon: Award,
                  title: "EcoSME Green Score Card",
                  desc: "Transparent 0–100 rating (Grades A–D) across 5 weighted dimensions: Efficiency Improvement, Load Stability, Data Completeness, Sustainability, and Monitoring Consistency.",
                  href: "/app/green-score",
                },
                {
                  icon: ShieldCheck,
                  title: "Green Finance Gateway",
                  desc: "Complete financing-readiness checklists, manage granular data-sharing consent with instant revocation, and track partner bank review statuses.",
                  href: "/app/financing",
                },
              ].map((feat) => {
                const Icon = feat.icon;
                return (
                  <div key={feat.title} className="ecosme-card-interactive p-6 flex flex-col justify-between">
                    <div className="space-y-3">
                      <div className="h-10 w-10 rounded-lg bg-[#E8F7F0] flex items-center justify-center text-[#123B2A]">
                        <Icon className="h-5 w-5 text-[#16A36A]" />
                      </div>
                      <h3 className="text-base font-bold text-[#123B2A]">
                        {feat.title}
                      </h3>
                      <p className="text-xs sm:text-sm text-[#4B5563] leading-relaxed">
                        {feat.desc}
                      </p>
                    </div>
                    <div className="pt-4 mt-4 border-t border-slate-100">
                      <Link
                        href={feat.href}
                        className="inline-flex items-center gap-1 text-xs font-semibold text-[#123B2A] hover:text-[#16A36A]"
                      >
                        Explore Module <ArrowRight className="h-3.5 w-3.5" />
                      </Link>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* 9. BUSINESS MODEL & PRICING OVERVIEW */}
        <section className="py-16 bg-white border-b border-[#DDE5DF]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-[#16A36A]">
                  Transparent Commercial Architecture
                </span>
                <h2 className="text-2xl sm:text-3xl font-bold text-[#123B2A] mt-1">
                  B2B SaaS Tiers &amp; Performance-Aligned ESaaS Model
                </h2>
                <p className="text-sm text-[#4B5563] mt-1 max-w-2xl">
                  Configurable subscription hypotheses designed for Indonesian IKM budgets, complemented by verified-only Energy Savings-as-a-Service (ESaaS).
                </p>
              </div>
              <Link
                href="/pricing"
                className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#123B2A] hover:text-[#16A36A]"
              >
                View Full Pricing &amp; ESaaS Calculator <ArrowRight className="h-4 w-4" />
              </Link>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                {
                  name: "Basic",
                  price: "Rp149,000",
                  desc: "Entry-level energy visibility for small workshops.",
                  features: [
                    "Basic energy consumption dashboard",
                    "Limited machine monitoring (up to 3 machines)",
                    "Monthly PDF energy consumption reports",
                  ],
                },
                {
                  name: "Growth",
                  price: "Rp349,000",
                  desc: "Multi-line analytics and anomaly detection for growing factories.",
                  features: [
                    "Expanded machine monitoring (up to 10 machines)",
                    "Single & 3-phase power factor analysis",
                    "Configurable power spike & offline alerts",
                    "Normalized energy savings reports",
                  ],
                  highlight: true,
                },
                {
                  name: "Pro",
                  price: "Rp699,000",
                  desc: "Complete sustainability & green financing readiness suite.",
                  features: [
                    "Advanced multi-zone telemetry & API ingestion",
                    "Scope 2 sustainability & carbon footprint reports",
                    "Provisional Green Score Card & recommendations",
                    "Green Finance Gateway & consented bank sharing",
                  ],
                },
              ].map((tier) => (
                <div
                  key={tier.name}
                  className={`ecosme-card p-6 flex flex-col justify-between ${
                    tier.highlight ? "ring-2 ring-[#16A36A]" : ""
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-bold text-[#123B2A]">
                        {tier.name}
                      </h3>
                      <span className="text-[10px] font-semibold uppercase bg-slate-100 text-slate-600 px-2 py-0.5 rounded">
                        Illustrative Plan
                      </span>
                    </div>
                    <p className="text-2xl font-bold text-[#123B2A] mt-3">
                      {tier.price}
                      <span className="text-xs font-normal text-slate-500">
                        {" "}
                        / month
                      </span>
                    </p>
                    <p className="text-xs text-slate-600 mt-2">{tier.desc}</p>
                    <ul className="mt-5 space-y-2.5 text-xs text-slate-700">
                      {tier.features.map((f) => (
                        <li key={f} className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 text-[#16A36A] shrink-0" />
                          <span>{f}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <Link
                    href="/pricing"
                    className="mt-6 block text-center rounded-lg bg-[#123B2A] hover:bg-[#0D2B1E] text-white py-2.5 text-xs font-semibold transition-colors"
                  >
                    Configure {tier.name} Plan
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* 10. CALL TO ACTION SECTION */}
        <section className="py-16 bg-[#123B2A] text-white">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
            <h2 className="text-2xl sm:text-4xl font-bold tracking-tight">
              Ready to Turn Operational Energy Savings into Green Finance Readiness?
            </h2>
            <p className="text-sm sm:text-base text-emerald-100 max-w-2xl mx-auto">
              Explore the live deterministic demo across all three stakeholder portals—IKM Factory Owner, Partner Bank Underwriter, and EcoSME Platform Administrator.
            </p>
            <div className="flex flex-wrap justify-center gap-4 pt-2">
              <Link
                href="/app/overview"
                className="rounded-lg bg-[#16A36A] hover:bg-emerald-500 px-6 py-3 text-sm font-semibold text-white transition-colors"
              >
                Launch IKM Dashboard
              </Link>
              <Link
                href="/bank/overview"
                className="rounded-lg bg-white text-[#123B2A] hover:bg-slate-100 px-6 py-3 text-sm font-semibold transition-colors"
              >
                Launch Partner Bank Portal
              </Link>
              <Link
                href="/register"
                className="rounded-lg border border-emerald-400/50 hover:bg-white/10 px-6 py-3 text-sm font-semibold text-white transition-colors"
              >
                Register New Organization
              </Link>
            </div>
          </div>
        </section>
      </main>
      </div>

      <PublicFooter />
    </div>
  );
}
