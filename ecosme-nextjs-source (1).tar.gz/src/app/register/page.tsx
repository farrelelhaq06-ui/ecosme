"use client";

import React, { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowRight, CheckCircle2, Factory } from "lucide-react";
import { PublicNavbar } from "@/components/PublicNavbar";
import { PublicFooter } from "@/components/PublicFooter";
import { useEcoSME } from "@/components/EcoSMEProvider";

export default function RegisterPage() {
  const router = useRouter();
  const { switchUserRole } = useEcoSME();
  const [companyName, setCompanyName] = useState("");
  const [industry, setIndustry] = useState("Textile & Garment Manufacturing");
  const [location, setLocation] = useState("Bandung, West Java");
  const [tariffClass, setTariffClass] = useState("I-3 / TM (>200 kVA Industrial)");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    await switchUserRole("usr-ikm-budi");
    setTimeout(() => {
      router.push("/app/overview");
    }, 1200);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F5F8F6]">
      <PublicNavbar />
      <main className="flex-1 max-w-3xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-12">
        <div className="ecosme-card p-6 sm:p-8 space-y-6">
          <div className="space-y-1">
            <span className="text-xs font-bold uppercase tracking-wider text-[#16A36A]">
              IKM Onboarding &amp; Readiness Registration
            </span>
            <h1 className="text-2xl font-bold text-[#123B2A]">
              Register Your Industrial Facility on EcoSME
            </h1>
            <p className="text-xs sm:text-sm text-[#4B5563]">
              Configure your organization profile, PLN industrial tariff class, and sub-metering baseline parameters.
            </p>
          </div>

          {submitted ? (
            <div className="rounded-xl bg-[#E8F7F0] border border-[#16A36A] p-6 text-center space-y-3">
              <CheckCircle2 className="h-8 w-8 text-[#16A36A] mx-auto" />
              <h2 className="text-lg font-bold text-[#123B2A]">
                Workspace Provisioned in Controlled Demo Mode
              </h2>
              <p className="text-xs text-slate-700">
                Redirecting you to the IKM Factory Dashboard with pre-populated deterministic telemetry...
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="reg-company"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    Company / IKM Legal Name
                  </label>
                  <input
                    id="reg-company"
                    type="text"
                    required
                    placeholder="e.g., PT Sinar Tekstil Mandiri"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm"
                  />
                </div>
                <div>
                  <label
                    htmlFor="reg-industry"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    Industrial Sub-Sector (ISIC / KBLI)
                  </label>
                  <select
                    id="reg-industry"
                    value={industry}
                    onChange={(e) => setIndustry(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm"
                  >
                    <option>Textile &amp; Garment Manufacturing</option>
                    <option>Metal Stamping &amp; Precision Engineering</option>
                    <option>Food &amp; Beverage Cold Chain</option>
                    <option>Plastics &amp; Packaging Extrusion</option>
                    <option>Woodworking &amp; Furniture Export</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="reg-location"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    Industrial Estate / City
                  </label>
                  <input
                    id="reg-location"
                    type="text"
                    required
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm"
                  />
                </div>
                <div>
                  <label
                    htmlFor="reg-tariff"
                    className="block text-xs font-semibold text-slate-700 mb-1"
                  >
                    PLN Electricity Tariff Category
                  </label>
                  <select
                    id="reg-tariff"
                    value={tariffClass}
                    onChange={(e) => setTariffClass(e.target.value)}
                    className="w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-sm"
                  >
                    <option>I-3 / TM (&gt;200 kVA Industrial — Rp1,444.70/kWh)</option>
                    <option>I-2 / TR (14 kVA – 200 kVA Industrial)</option>
                    <option>B-3 Commercial (&gt;200 kVA)</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="w-full inline-flex items-center justify-center gap-2 rounded-lg bg-[#123B2A] hover:bg-[#0D2B1E] text-white py-3 text-sm font-semibold transition-colors"
              >
                <Factory className="h-4 w-4 text-[#16A36A]" />
                Initialize IKM Energy Workspace
                <ArrowRight className="h-4 w-4" />
              </button>
            </form>
          )}

          <p className="text-xs text-slate-500 text-center pt-2 border-t border-slate-200">
            Already registered or evaluating demo accounts?{" "}
            <Link
              href="/login"
              className="font-semibold text-[#123B2A] hover:underline"
            >
              Sign In or Switch Demo Role →
            </Link>
          </p>
        </div>
      </main>
      <PublicFooter />
    </div>
  );
}
