import React from "react";
import Link from "next/link";
import {
  Activity,
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  Cpu,
  Radio,
  ShieldCheck,
} from "lucide-react";
import { PublicNavbar } from "@/components/PublicNavbar";
import { PublicFooter } from "@/components/PublicFooter";

export default function HowItWorksPage() {
  return (
    <div className="min-h-screen flex flex-col bg-[#F5F8F6]">
      <PublicNavbar />
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
        <div className="max-w-3xl space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-[#16A36A]">
            Platform Architecture &amp; Engineering Workflow
          </span>
          <h1 className="text-3xl sm:text-4xl font-bold text-[#123B2A] tracking-tight">
            How EcoSME Transforms Machine Telemetry into Green Finance Readiness
          </h1>
          <p className="text-base text-[#4B5563] leading-relaxed">
            Our 6-stage architecture enforces electrical engineering rigor from physical sub-meters to bank-ready sustainability dossiers.
          </p>
        </div>

        {/* 6-Stage Business Workflow */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            {
              stage: "Stage 01",
              title: "Measure Energy",
              desc: "Deploy ESP32 + PZEM-004T (single-phase 220V) or Modbus RS485 3-Phase meters (380V) across high-load production lines. Authenticate payloads using SHA-256 hashed device credentials.",
            },
            {
              stage: "Stage 02",
              title: "Analyze Consumption",
              desc: "Ingest Voltage (V), Current (A), Power Factor (cos φ), Active Power (kW), and accumulated kWh via HTTPS REST or MQTT/TLS.",
            },
            {
              stage: "Stage 03",
              title: "Identify Inefficiencies",
              desc: "Trigger rule-based alerts for over-rated power draw, shift-startup surges, low power factor (<0.85), or missed device heartbeats.",
            },
            {
              stage: "Stage 04",
              title: "Validate Savings",
              desc: "Compute normalized energy savings against operating hours and production output. Separate true active-power VERIFIED savings from current-only ESTIMATED readings.",
            },
            {
              stage: "Stage 05",
              title: "Generate Green Score",
              desc: "Calculate a 0–100 Provisional Green Score (Grades A–D) across 5 transparent dimensions and quantify Scope 2 CO₂e reductions using ESDM grid emission factors.",
            },
            {
              stage: "Stage 06",
              title: "Prepare Green Financing Profile",
              desc: "Assemble technical documentation and grant explicit, revocable data-sharing consent so authorized partner banks can evaluate the project.",
            },
          ].map((item) => (
            <div key={item.stage} className="ecosme-card p-6 space-y-2.5">
              <span className="inline-block rounded bg-[#E8F7F0] text-[#123B2A] font-mono text-xs font-bold px-2.5 py-1">
                {item.stage}
              </span>
              <h2 className="text-lg font-bold text-[#123B2A]">{item.title}</h2>
              <p className="text-xs sm:text-sm text-[#4B5563] leading-relaxed">
                {item.desc}
              </p>
            </div>
          ))}
        </div>

        {/* Critical Electrical Engineering Considerations */}
        <div className="ecosme-card p-6 sm:p-8 space-y-6">
          <div className="flex items-start gap-3">
            <Cpu className="h-6 w-6 text-[#16A36A] shrink-0 mt-0.5" />
            <div>
              <h2 className="text-xl font-bold text-[#123B2A]">
                Electrical Engineering &amp; Telemetry Verification Standards
              </h2>
              <p className="text-sm text-[#4B5563] mt-1">
                Why EcoSME distinguishes between Current-Only (CT) sensors and True Active-Power Meters:
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs sm:text-sm">
            <div className="rounded-lg bg-[#F5F8F6] p-5 border border-[#DDE5DF] space-y-2">
              <h3 className="font-bold text-[#123B2A]">
                1. Single-Phase &amp; Three-Phase Active Power
              </h3>
              <p className="text-slate-600 leading-relaxed">
                Current sensors (CT clamps) alone cannot measure true active power on inductive factory motors because voltage sags and power factor (<code className="font-mono">PF</code>) vary dynamically with mechanical load:
              </p>
              <ul className="space-y-1.5 text-slate-700 font-mono text-xs pt-1">
                <li>• Single-Phase Active Power: P (W) = V × I × PF</li>
                <li>• Three-Phase Active Power: P (W) = √3 × V_LL × I_L × PF</li>
              </ul>
              <p className="text-xs text-emerald-800 font-medium pt-1">
                Any sensor lacking live V and PF is automatically classified by EcoSME as ESTIMATED and excluded from ESaaS billing.
              </p>
            </div>

            <div className="rounded-lg bg-[#F5F8F6] p-5 border border-[#DDE5DF] space-y-2">
              <h3 className="font-bold text-[#123B2A]">
                2. Heartbeat Monitoring vs. Sensor Tampering
              </h3>
              <p className="text-slate-600 leading-relaxed">
                EcoSME tracks continuous device heartbeats to detect Wi-Fi/MQTT dropouts or power outages within 15 minutes. However, heartbeat continuity alone does not guarantee that a physical CT clamp has not been unclipped or relocated.
              </p>
              <p className="text-xs text-slate-700 pt-1">
                Therefore, EcoSME cross-checks sub-meter kWh sums against monthly PLN utility invoices and production output logs before marking savings as{" "}
                <strong>VERIFIED</strong>.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-3 pt-2">
            <Link
              href="/app/devices"
              className="inline-flex items-center gap-2 rounded-lg bg-[#123B2A] text-white px-4 py-2.5 text-xs font-semibold hover:bg-[#0D2B1E]"
            >
              Inspect IoT Device Management &amp; Ingestion API
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              href="/app/energy"
              className="inline-flex items-center gap-2 rounded-lg border border-[#123B2A] text-[#123B2A] px-4 py-2.5 text-xs font-semibold hover:bg-[#E8F7F0]"
            >
              View Live Telemetry Dashboard
            </Link>
          </div>
        </div>
      </main>
      <PublicFooter />
    </div>
  );
}
