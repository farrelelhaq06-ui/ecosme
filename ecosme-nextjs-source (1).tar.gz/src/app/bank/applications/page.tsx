"use client";

import React from "react";
import Link from "next/link";
import { ArrowRight, CheckCircle2, Landmark } from "lucide-react";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";
import { ApplicationStatus } from "@/lib/types";
import { formatDateTime, formatIdr, formatNumber } from "@/lib/formatters";

export default function BankApplicationsPage() {
  const { consentedBankPipeline, mutateState } = useEcoSME();

  const handleQuickStatusUpdate = async (
    applicationId: string,
    newStatus: ApplicationStatus
  ) => {
    await mutateState("BANK_UPDATE_APPLICATION_STATUS", {
      application_id: applicationId,
      new_status: newStatus,
      review_note: `Bank officer updated status to '${newStatus}' from Applications Queue.`,
    });
  };

  return (
    <PortalShell
      portalType="BANK"
      title="Green Financing Applications Underwriting Queue"
      subtitle="Manage consented IKM financing requests, update credit review statuses, and inspect technical readiness evidence."
    >
      <div className="space-y-4">
        {consentedBankPipeline.map((item) => {
          const app = item.application;
          if (!app) return null;
          return (
            <div key={app.id} className="ecosme-card p-6 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 pb-3">
                <div>
                  <span className="text-[11px] font-mono font-bold text-[#16A36A]">
                    Application #{app.id} • Submitted{" "}
                    {formatDateTime(app.submitted_at)}
                  </span>
                  <h2 className="text-lg font-bold text-[#14243A]">
                    {app.project_title}
                  </h2>
                  <p className="text-xs text-slate-600">
                    Borrower: <strong>{item.organization.name}</strong> (
                    {item.organization.location})
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <span className="rounded-lg bg-blue-100 text-blue-900 px-3 py-1 text-xs font-bold">
                    {app.status}
                  </span>
                  <Link
                    href={`/bank/pipeline/${item.organization.id}`}
                    className="inline-flex items-center gap-1 rounded-lg bg-[#14243A] hover:bg-slate-800 text-white px-3.5 py-1.5 text-xs font-semibold"
                  >
                    Full Dossier <ArrowRight className="h-3.5 w-3.5" />
                  </Link>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="rounded-lg bg-[#F5F8F6] p-3">
                  <span className="text-slate-500 block">Requested Capex</span>
                  <span className="text-sm font-bold text-[#123B2A]">
                    {formatIdr(app.requested_amount_idr)}
                  </span>
                </div>
                <div className="rounded-lg bg-[#F5F8F6] p-3">
                  <span className="text-slate-500 block">
                    Est. Annual Savings
                  </span>
                  <span className="text-sm font-bold text-[#16A36A]">
                    {formatIdr(app.estimated_annual_savings_idr)}/yr
                  </span>
                </div>
                <div className="rounded-lg bg-[#F5F8F6] p-3">
                  <span className="text-slate-500 block">
                    Provisional Green Score
                  </span>
                  <span className="text-sm font-bold text-[#123B2A]">
                    {app.green_score_at_submission}/100 (Grade{" "}
                    {app.green_score_rating})
                  </span>
                </div>
                <div className="rounded-lg bg-[#F5F8F6] p-3">
                  <span className="text-slate-500 block">
                    Est. CO₂e Reduction
                  </span>
                  <span className="text-sm font-bold text-slate-800">
                    {formatNumber(app.estimated_co2_reduction_kg / 1000, 1)}{" "}
                    tCO₂e/yr
                  </span>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 text-xs">
                <span className="text-slate-600">
                  <strong>Reviewer Note:</strong> {app.bank_reviewer_notes}
                </span>

                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-slate-500 mr-1">Quick Decision:</span>
                  {(
                    [
                      "Under Review",
                      "Additional Information Required",
                      "Approved by Bank",
                      "Rejected by Bank",
                      "Disbursed",
                    ] as ApplicationStatus[]
                  ).map((st) => (
                    <button
                      key={st}
                      type="button"
                      onClick={() => handleQuickStatusUpdate(app.id, st)}
                      className={`px-2.5 py-1 rounded text-[11px] font-semibold border transition-colors ${
                        app.status === st
                          ? "bg-[#14243A] text-white border-[#14243A]"
                          : "bg-white hover:bg-slate-100 text-slate-700 border-slate-300"
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </PortalShell>
  );
}
