"use client";

import React from "react";
import { Download, FileSpreadsheet, ShieldCheck } from "lucide-react";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";
import { ReportType } from "@/lib/types";
import { downloadEcoSMEReportPdf } from "@/lib/pdf-generator";

export default function BankReportsPage() {
  const { consentedBankPipeline, emissionFactors } = useEcoSME();

  const reportTypes: Array<{ type: ReportType; label: string }> = [
    { type: "GREEN_SCORE_CARD", label: "Provisional Green Score Card" },
    { type: "ENERGY_SAVINGS", label: "Normalized Energy Savings Report" },
    { type: "SUSTAINABILITY_CARBON", label: "Scope 2 Carbon Footprint Report" },
    { type: "FINANCING_READINESS", label: "Full Financing Readiness Dossier" },
  ];

  return (
    <PortalShell
      portalType="BANK"
      title="Authorized IKM Technical & Sustainability Reports"
      subtitle="Download permitted energy-performance, savings verification, and Provisional Green Score PDF dossiers for consented IKMs."
    >
      <div className="space-y-6">
        {consentedBankPipeline.map((item) => (
          <div key={item.organization.id} className="ecosme-card p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-bold text-[#14243A]">
                    {item.organization.name}
                  </h2>
                  <span className="rounded bg-emerald-100 text-emerald-900 px-2 py-0.5 text-[10px] font-bold">
                    Consent #{item.consent.id} ACTIVE
                  </span>
                </div>
                <p className="text-xs text-slate-500">
                  {item.organization.industry_category} • {item.organization.location}
                </p>
              </div>
              <span className="rounded bg-[#123B2A] text-white px-2.5 py-1 text-xs font-bold">
                Green Score: {item.greenScore?.overall_score}/100 (Grade{" "}
                {item.greenScore?.rating})
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {reportTypes.map((rt) => (
                <div
                  key={rt.type}
                  className="rounded-lg bg-[#F5F8F6] border border-[#DDE5DF] p-3.5 flex flex-col justify-between space-y-3"
                >
                  <div>
                    <FileSpreadsheet className="h-4 w-4 text-[#16A36A] mb-1.5" />
                    <h3 className="text-xs font-bold text-[#123B2A]">
                      {rt.label}
                    </h3>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Period: {item.greenScore?.assessment_period}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      if (!item.greenScore) return;
                      downloadEcoSMEReportPdf({
                        reportType: rt.type,
                        organization: item.organization,
                        reportingPeriod: item.greenScore.assessment_period,
                        tariffIdrPerKwh: 1444.7,
                        totalEnergyKwh: 41820,
                        baselineEnergyKwh: 48900,
                        verifiedSavingsKwh: 6726,
                        estimatedSavingsKwh: 354,
                        greenScore: item.greenScore,
                        emissionFactor: emissionFactors[0],
                        machines: item.machines,
                        financingApplication: item.application ?? undefined,
                      });
                    }}
                    className="inline-flex items-center justify-center gap-1.5 rounded bg-[#14243A] hover:bg-slate-800 text-white py-1.5 px-3 text-[11px] font-semibold"
                  >
                    <Download className="h-3.5 w-3.5 text-[#16A36A]" />
                    Download PDF
                  </button>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </PortalShell>
  );
}
