"use client";

import React, { useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  ArrowLeft,
  Award,
  CheckCircle2,
  Download,
  Lock,
  ShieldCheck,
} from "lucide-react";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";
import { ApplicationStatus } from "@/lib/types";
import { formatDateTime, formatIdr, formatNumber } from "@/lib/formatters";
import { downloadEcoSMEReportPdf } from "@/lib/pdf-generator";

export default function BankPipelineDetailPage() {
  const params = useParams<{ id: string }>();
  const orgId = params?.id;
  const { consentedBankPipeline, emissionFactors, mutateState } = useEcoSME();

  const item = consentedBankPipeline.find((p) => p.organization.id === orgId);

  const [newStatus, setNewStatus] = useState<ApplicationStatus>(
    item?.application?.status ?? "Under Review"
  );
  const [reviewNote, setReviewNote] = useState("");
  const [decisionSaved, setDecisionSaved] = useState(false);

  if (!item) {
    return (
      <PortalShell
        portalType="BANK"
        title="Consent & Data Isolation Access Denied"
        subtitle="Server-side consent verification blocked access to this organization."
      >
        <div className="ecosme-card p-8 max-w-2xl mx-auto my-6 border-red-300 bg-red-50/40 space-y-4">
          <div className="flex items-center gap-3 text-red-900">
            <Lock className="h-6 w-6 shrink-0" />
            <h2 className="text-lg font-bold">
              Unauthorized Organization Access Blocked (Consent Missing or Revoked)
            </h2>
          </div>
          <p className="text-sm text-slate-700 leading-relaxed">
            The requested IKM organization (<code className="font-mono">{orgId}</code>) has either not granted data-sharing authorization to your financial institution or has explicitly{" "}
            <strong>REVOKED</strong> its consent. EcoSME strictly prohibits displaying an IKM&apos;s confidential energy or financial profile without an active consent grant.
          </p>
          <Link
            href="/bank/pipeline"
            className="inline-flex items-center gap-1.5 rounded-lg bg-[#14243A] text-white px-4 py-2 text-xs font-semibold"
          >
            <ArrowLeft className="h-4 w-4" /> Return to Authorized Pipeline
          </Link>
        </div>
      </PortalShell>
    );
  }

  const { organization, consent, greenScore, application, machines } = item;

  const handleBankDecisionSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!application) return;
    await mutateState("BANK_UPDATE_APPLICATION_STATUS", {
      application_id: application.id,
      new_status: newStatus,
      bank_reviewer_notes:
        reviewNote || application.bank_reviewer_notes,
      review_note:
        reviewNote ||
        `Partner Bank officer updated application status to '${newStatus}'.`,
    });
    setReviewNote("");
    setDecisionSaved(true);
    setTimeout(() => setDecisionSaved(false), 3000);
  };

  return (
    <PortalShell
      portalType="BANK"
      title={`Underwriting Dossier: ${organization.name}`}
      subtitle={`${organization.industry_category} • ${organization.location} • Authorized via Consent #${consent.id}`}
    >
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <Link
          href="/bank/pipeline"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#14243A] hover:underline"
        >
          <ArrowLeft className="h-4 w-4" /> Back to Authorized Pipeline
        </Link>

        {greenScore && (
          <button
            type="button"
            onClick={() =>
              downloadEcoSMEReportPdf({
                reportType: "FINANCING_READINESS",
                organization,
                reportingPeriod: greenScore.assessment_period,
                tariffIdrPerKwh: 1444.7,
                totalEnergyKwh: 41820,
                baselineEnergyKwh: 48900,
                verifiedSavingsKwh: 6726,
                estimatedSavingsKwh: 354,
                greenScore,
                emissionFactor: emissionFactors[0],
                machines,
                financingApplication: application ?? undefined,
              })
            }
            className="inline-flex items-center gap-1.5 rounded-lg bg-[#123B2A] hover:bg-[#0D2B1E] text-white px-4 py-2 text-xs font-semibold"
          >
            <Download className="h-4 w-4 text-[#16A36A]" />
            Download Authorized Underwriting PDF Package
          </button>
        )}
      </div>

      {/* Top Row: Business Profile, Energy Summary & Green Score */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-6">
        <div className="lg:col-span-4 ecosme-card p-5 space-y-3 text-xs">
          <h2 className="text-sm font-bold text-[#14243A] border-b border-slate-200 pb-2">
            1. IKM Business &amp; Electrical Profile
          </h2>
          <div className="space-y-2">
            <div>
              <span className="text-slate-500 block">Legal Entity Name</span>
              <span className="font-bold text-[#123B2A]">{organization.name}</span>
            </div>
            <div>
              <span className="text-slate-500 block">NPWP / NIB</span>
              <span className="font-mono text-slate-800">
                {organization.tax_id_npwp} / {organization.business_license_nib}
              </span>
            </div>
            <div>
              <span className="text-slate-500 block">Facility Address</span>
              <span className="text-slate-700">{organization.address}</span>
            </div>
            <div>
              <span className="text-slate-500 block">PLN Tariff &amp; Capacity</span>
              <span className="font-semibold text-slate-800">
                {organization.pln_tariff_class} ({organization.installed_capacity_kva} kVA)
              </span>
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 ecosme-card p-5 space-y-3 text-xs">
          <h2 className="text-sm font-bold text-[#14243A] border-b border-slate-200 pb-2">
            2. Energy, Savings &amp; Scope 2 Summary
          </h2>
          <div className="space-y-2.5">
            <div className="rounded-lg bg-[#F5F8F6] p-3 flex justify-between">
              <span className="text-slate-600">Project Capex Request:</span>
              <span className="font-bold text-[#123B2A]">
                {formatIdr(application?.requested_amount_idr ?? 0)}
              </span>
            </div>
            <div className="rounded-lg bg-[#F5F8F6] p-3 flex justify-between">
              <span className="text-slate-600">Projected Annual Savings:</span>
              <span className="font-bold text-[#16A36A]">
                {formatIdr(application?.estimated_annual_savings_idr ?? 0)}/yr
              </span>
            </div>
            <div className="rounded-lg bg-[#F5F8F6] p-3 flex justify-between">
              <span className="text-slate-600">Est. Annual kWh Saved:</span>
              <span className="font-semibold text-slate-900">
                {formatNumber(application?.estimated_annual_savings_kwh ?? 0, 0)} kWh
              </span>
            </div>
            <div className="rounded-lg bg-[#F5F8F6] p-3 flex justify-between">
              <span className="text-slate-600">Est. Scope 2 CO₂e Avoided:</span>
              <span className="font-semibold text-emerald-900">
                {formatNumber(
                  (application?.estimated_co2_reduction_kg ?? 0) / 1000,
                  2
                )}{" "}
                tCO₂e/yr
              </span>
            </div>
          </div>
        </div>

        <div className="lg:col-span-4 ecosme-card p-5 space-y-3 text-xs">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
            <h2 className="text-sm font-bold text-[#14243A]">
              3. Provisional Green Score Breakdown
            </h2>
            <span className="rounded bg-[#123B2A] text-white px-2 py-0.5 font-bold">
              {greenScore?.overall_score}/100 (Grade {greenScore?.rating})
            </span>
          </div>
          <div className="space-y-2">
            {greenScore?.dimensions.map((d) => (
              <div key={d.key} className="space-y-1">
                <div className="flex justify-between text-[11px]">
                  <span className="font-medium text-slate-700">{d.label}</span>
                  <span className="font-bold text-[#123B2A]">
                    {d.raw_score}/100 ({d.weight_pct}%)
                  </span>
                </div>
                <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#16A36A]"
                    style={{ width: `${d.raw_score}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Row: Bank Credit Underwriting Decision Form + Activity Log */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <form
          onSubmit={handleBankDecisionSubmit}
          className="lg:col-span-6 ecosme-card p-6 space-y-4 text-xs"
        >
          <div className="border-b border-slate-200 pb-3">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#16A36A]">
              Partner Financial Institution Authority
            </span>
            <h2 className="text-base font-bold text-[#14243A]">
              Record Credit Review &amp; Application Status Decision
            </h2>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Update Application Underwriting Status
            </label>
            <select
              value={newStatus}
              onChange={(e) => setNewStatus(e.target.value as ApplicationStatus)}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 font-bold text-[#14243A]"
            >
              <option value="Submitted">Submitted</option>
              <option value="Under Review">Under Review</option>
              <option value="Additional Information Required">
                Additional Information Required
              </option>
              <option value="Approved by Bank">Approved by Bank</option>
              <option value="Rejected by Bank">Rejected by Bank</option>
              <option value="Disbursed">Disbursed</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">
              Bank Credit Committee / Technical Underwriter Notes
            </label>
            <textarea
              rows={3}
              required
              placeholder="Enter credit assessment notes, DSCR verification, or additional document requests..."
              value={reviewNote}
              onChange={(e) => setReviewNote(e.target.value)}
              className="w-full rounded-lg border border-slate-300 px-3 py-2"
            />
          </div>

          <button
            type="submit"
            className="w-full rounded-lg bg-[#14243A] hover:bg-slate-800 text-white py-2.5 font-semibold transition-colors"
          >
            Record Bank Decision &amp; Notify IKM
          </button>

          {decisionSaved && (
            <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-2.5 text-emerald-900 font-medium text-center">
              Underwriting decision recorded in Audit Log and visible to IKM Owner.
            </div>
          )}
        </form>

        <div className="lg:col-span-6 ecosme-card p-6 space-y-4 text-xs">
          <h2 className="text-base font-bold text-[#14243A]">
            Underwriting &amp; Consent Activity Log
          </h2>
          <div className="space-y-3">
            {application?.activities.map((act) => (
              <div
                key={act.id}
                className="rounded-lg bg-[#F5F8F6] border border-[#DDE5DF] p-3.5 space-y-1"
              >
                <div className="flex justify-between">
                  <span className="font-bold text-[#123B2A]">
                    {act.actor_name} ({act.actor_role})
                  </span>
                  <span className="font-mono text-[11px] text-slate-500">
                    {formatDateTime(act.timestamp)}
                  </span>
                </div>
                <p className="font-semibold text-[#16A36A]">
                  {act.status_from ?? "Initial"} → {act.status_to}
                </p>
                <p className="text-slate-700">{act.note}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </PortalShell>
  );
}
