"use client";

import React from "react";
import Link from "next/link";
import { ArrowRight, Lock, ShieldCheck } from "lucide-react";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";
import { formatIdr, formatNumber } from "@/lib/formatters";

export default function BankPipelinePage() {
  const { consentedBankPipeline } = useEcoSME();

  return (
    <PortalShell
      portalType="BANK"
      title="Authorized IKM Green Financing Pipeline"
      subtitle="Strict consent-enforced directory of Small and Medium Industries that have authorized data sharing with your institution."
    >
      <div className="ecosme-card overflow-hidden mb-6">
        <div className="p-4 border-b border-[#DDE5DF] flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-[#123B2A]">
            <ShieldCheck className="h-4 w-4 text-[#16A36A]" />
            <span>
              Showing {consentedBankPipeline.length} Consented IKM Organizations
            </span>
          </div>
          <Link
            href="/bank/pipeline/org-ikm-pangan"
            className="inline-flex items-center gap-1.5 text-xs font-medium text-red-700 hover:underline"
          >
            <Lock className="h-3.5 w-3.5" />
            Test Access Control on Revoked IKM (PT Agro Pangan Lestari) →
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#F5F8F6] text-slate-600 border-b border-[#DDE5DF]">
                <th className="py-3 px-4 font-semibold">IKM Organization Name</th>
                <th className="py-3 px-4 font-semibold">Industry &amp; Location</th>
                <th className="py-3 px-4 font-semibold">Provisional Green Score</th>
                <th className="py-3 px-4 font-semibold">Energy Performance Summary</th>
                <th className="py-3 px-4 font-semibold">Consent Status</th>
                <th className="py-3 px-4 font-semibold">Application Status</th>
                <th className="py-3 px-4 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {consentedBankPipeline.map((item) => (
                <tr key={item.organization.id} className="hover:bg-slate-50">
                  <td className="py-3.5 px-4">
                    <span className="font-bold text-[#123B2A] block">
                      {item.organization.name}
                    </span>
                    <span className="font-mono text-[11px] text-slate-500">
                      NIB: {item.organization.business_license_nib}
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="font-medium text-slate-800 block">
                      {item.organization.industry_category}
                    </span>
                    <span className="text-[11px] text-slate-500">
                      {item.organization.location}
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="inline-flex items-center gap-1.5 rounded bg-[#E8F7F0] border border-[#16A36A]/30 px-2.5 py-1 font-bold text-[#123B2A]">
                      {item.greenScore?.overall_score}/100 (Grade{" "}
                      {item.greenScore?.rating})
                    </span>
                    <span className="block text-[10px] text-slate-500 mt-0.5">
                      {item.greenScore?.status_label}
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="font-semibold text-emerald-800 block">
                      Proj. Savings:{" "}
                      {formatNumber(
                        item.application?.estimated_annual_savings_kwh ?? 0,
                        0
                      )}{" "}
                      kWh/yr
                    </span>
                    <span className="text-[11px] text-slate-500">
                      CO₂e Avoided:{" "}
                      {formatNumber(
                        (item.application?.estimated_co2_reduction_kg ?? 0) / 1000,
                        1
                      )}{" "}
                      tCO₂e/yr
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="rounded bg-emerald-100 text-emerald-900 px-2 py-0.5 text-[10px] font-bold uppercase">
                      {item.consent.status}
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    <span className="rounded bg-blue-100 text-blue-900 px-2.5 py-1 text-[11px] font-bold">
                      {item.application?.status}
                    </span>
                    <span className="block text-[11px] font-semibold text-slate-700 mt-0.5">
                      {formatIdr(item.application?.requested_amount_idr ?? 0)}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <Link
                      href={`/bank/pipeline/${item.organization.id}`}
                      className="inline-flex items-center gap-1 rounded-lg bg-[#14243A] hover:bg-slate-800 text-white px-3 py-1.5 font-semibold"
                    >
                      Review Dossier <ArrowRight className="h-3.5 w-3.5" />
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </PortalShell>
  );
}
