"use client";

import React from "react";
import Link from "next/link";
import {
  ArrowRight,
  Award,
  Building2,
  CheckCircle2,
  Landmark,
  Lock,
  ShieldCheck,
} from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { PortalShell } from "@/components/PortalShell";
import { useEcoSME } from "@/components/EcoSMEProvider";
import { formatIdr } from "@/lib/formatters";

export default function BankOverviewPage() {
  const { consentedBankPipeline } = useEcoSME();

  const totalAuthorizedProfiles = consentedBankPipeline.length;
  const totalPipelineAmountIdr = consentedBankPipeline.reduce(
    (sum, item) => sum + (item.application?.requested_amount_idr ?? 0),
    0
  );
  const underReviewCount = consentedBankPipeline.filter(
    (i) =>
      i.application?.status === "Under Review" ||
      i.application?.status === "Submitted" ||
      i.application?.status === "Additional Information Required"
  ).length;
  const approvedCount = consentedBankPipeline.filter(
    (i) => i.application?.status === "Approved by Bank"
  ).length;
  const disbursedCount = consentedBankPipeline.filter(
    (i) => i.application?.status === "Disbursed"
  ).length;

  const gradeDistribution = [
    {
      grade: "Grade A (80-100)",
      count: consentedBankPipeline.filter((i) => i.greenScore?.rating === "A")
        .length,
    },
    {
      grade: "Grade B (65-79)",
      count: consentedBankPipeline.filter((i) => i.greenScore?.rating === "B")
        .length,
    },
    {
      grade: "Grade C (50-64)",
      count: consentedBankPipeline.filter((i) => i.greenScore?.rating === "C")
        .length,
    },
    {
      grade: "Grade D (<50)",
      count: consentedBankPipeline.filter((i) => i.greenScore?.rating === "D")
        .length,
    },
  ];

  return (
    <PortalShell
      portalType="BANK"
      title="Partner Bank Green Lending Dashboard"
      subtitle="Review consented IKM energy-efficiency profiles, Provisional Green Score distributions, and green financing underwriting pipelines."
    >
      {/* Consent & Credit Responsibility Notice */}
      <div className="ecosme-card p-4 mb-6 bg-[#14243A] text-white flex items-start justify-between gap-4 flex-wrap">
        <div className="flex items-start gap-3 max-w-4xl">
          <ShieldCheck className="h-5 w-5 text-[#16A36A] shrink-0 mt-0.5" />
          <div className="text-xs text-slate-200 space-y-1 leading-relaxed">
            <p className="font-bold text-white">
              Consent-Gated Data Isolation &amp; Underwriting Governance (DEMO DATA)
            </p>
            <p>
              This portal displays <strong>only</strong> IKM organizations that have granted an{" "}
              <span className="text-emerald-400 font-bold">ACTIVE</span>{" "}
              <code className="font-mono">DataSharingConsent</code> to{" "}
              <strong>Bank Nusantara Hijau (DEMO)</strong>. Non-consented or revoked organizations (such as{" "}
              <em>PT Agro Pangan Lestari</em>) are automatically excluded by server-side RBAC. All loan approval and credit risk decisions remain the sole authority of the bank.
            </p>
          </div>
        </div>
        <Link
          href="/bank/pipeline"
          className="inline-flex items-center gap-1.5 rounded-lg bg-[#16A36A] hover:bg-emerald-500 text-white px-4 py-2 text-xs font-semibold shrink-0"
        >
          Inspect Consented Pipeline <ArrowRight className="h-4 w-4" />
        </Link>
      </div>

      {/* Bank KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
        <div className="ecosme-card p-5 space-y-1">
          <span className="text-xs font-semibold text-slate-500">
            Authorized IKM Profiles
          </span>
          <p className="text-2xl font-bold text-[#14243A]">
            {totalAuthorizedProfiles}
          </p>
          <p className="text-[11px] text-emerald-700 font-medium">
            100% Active Consent Verified
          </p>
        </div>

        <div className="ecosme-card p-5 space-y-1">
          <span className="text-xs font-semibold text-slate-500">
            Total Financing Pipeline
          </span>
          <p className="text-2xl font-bold text-[#123B2A]">
            {formatIdr(totalPipelineAmountIdr)}
          </p>
          <p className="text-[11px] text-slate-500">
            Green Capex Retrofit Requests
          </p>
        </div>

        <div className="ecosme-card p-5 space-y-1">
          <span className="text-xs font-semibold text-slate-500">
            Applications in Review
          </span>
          <p className="text-2xl font-bold text-blue-900">{underReviewCount}</p>
          <p className="text-[11px] text-slate-500">
            Submitted / Under Review
          </p>
        </div>

        <div className="ecosme-card p-5 space-y-1">
          <span className="text-xs font-semibold text-slate-500">
            Approved by Bank
          </span>
          <p className="text-2xl font-bold text-[#16A36A]">{approvedCount}</p>
          <p className="text-[11px] text-slate-500">Credit Committee Approved</p>
        </div>

        <div className="ecosme-card p-5 space-y-1">
          <span className="text-xs font-semibold text-slate-500">
            Disbursed Facilities
          </span>
          <p className="text-2xl font-bold text-[#123B2A]">{disbursedCount}</p>
          <p className="text-[11px] text-slate-500">Active Green Loans</p>
        </div>
      </div>

      {/* Distribution Chart + Quick Pipeline Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 ecosme-card p-5 space-y-4">
          <h2 className="text-base font-bold text-[#14243A]">
            Provisional Green Score Distribution (Consented Portfolio)
          </h2>
          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={gradeDistribution}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis dataKey="grade" tick={{ fontSize: 11, fill: "#4B5563" }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: "#4B5563" }} />
                <Tooltip />
                <Bar
                  dataKey="count"
                  name="Consented IKMs"
                  fill="#123B2A"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="lg:col-span-7 ecosme-card p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-[#14243A]">
              Authorized IKM Financing Pipeline Summary
            </h2>
            <Link
              href="/bank/pipeline"
              className="text-xs font-semibold text-[#16A36A] hover:underline"
            >
              Open Full Pipeline →
            </Link>
          </div>

          <div className="space-y-3">
            {consentedBankPipeline.map((item) => (
              <div
                key={item.organization.id}
                className="rounded-lg bg-[#F5F8F6] border border-[#DDE5DF] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-[#123B2A]">
                      {item.organization.name}
                    </span>
                    <span className="rounded bg-[#123B2A] text-white px-2 py-0.5 text-[10px] font-bold">
                      Grade {item.greenScore?.rating} ({item.greenScore?.overall_score}/100)
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">
                    {item.organization.industry_category} • {item.organization.location}
                  </p>
                  <p className="text-xs font-medium text-slate-800">
                    Project: {item.application?.project_title} • Requested:{" "}
                    <strong>
                      {formatIdr(item.application?.requested_amount_idr ?? 0)}
                    </strong>
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className="rounded-md bg-blue-100 text-blue-900 px-2.5 py-1 text-xs font-bold">
                    {item.application?.status}
                  </span>
                  <Link
                    href={`/bank/pipeline/${item.organization.id}`}
                    className="inline-flex items-center gap-1 rounded-lg bg-[#14243A] hover:bg-slate-800 text-white px-3 py-1.5 text-xs font-semibold"
                  >
                    Underwrite <ArrowRight className="h-3.5 w-3.5" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </PortalShell>
  );
}
