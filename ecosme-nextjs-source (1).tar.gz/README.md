# EcoSME — Digital Energy Efficiency & Green Finance Readiness Platform for SMEs

**EcoSME** adalah platform SaaS enterprise berbasis **Next.js (App Router) + TypeScript + Tailwind CSS** yang dirancang untuk membantu Industri Kecil dan Menengah (IKM) memantau konsumsi energi listrik tingkat mesin, mengidentifikasi inefisiensi operasional, memvalidasi penghematan energi, menghitung estimasi jejak karbon (Scope 2), menghasilkan **Provisional Green Score**, serta menyiapkan profil kesiapan pembiayaan hijau (*Green Financing Readiness*) bagi bank mitra secara berbasis persetujuan (*explicit consent*).

---

## 1. Posisi Bisnis & Alur Kerja Utama

**Alur Bisnis Inti:**
> `Measure Energy` → `Analyze Consumption` → `Identify Inefficiencies` → `Validate Savings` → `Generate Green Score` → `Prepare Green Financing Profile`

**Tiga Pemangku Kepentingan Utama:**
1. **IKM / Pemilik Pabrik (`IKM_OWNER`):** Memantau konsumsi listrik mesin, mengevaluasi peringatan anomali daya, menganalisis penghematan (`VERIFIED` vs `ESTIMATED`), mengunduh laporan PDF, serta mengelola persetujuan pembagian data (*data-sharing consent*).
2. **Platform EcoSME (`ECOSME_ADMIN`):** Mengelola perangkat IoT, memantau kualitas telemetri, mengatur metodologi bobot Green Score, serta mencatat *audit log* sistem.
3. **Bank Mitra / Lembaga Keuangan (`BANK_OFFICER`):** Meninjau profil IKM yang telah memberikan izin berbagi data secara eksplisit (`ACTIVE`), mengevaluasi laporan Green Score, dan memperbarui status tinjauan kredit.

> **Catatan Penting:** EcoSME menyediakan analitik kinerja energi dan informasi kesiapan pembiayaan (*financing-readiness*). EcoSME tidak menyetujui atau menolak pinjaman secara otomatis—keputusan kredit sepenuhnya berada pada bank mitra.

---

## 2. Struktur Rute Lengkap (30 Rute Aktif)

### A. Situs Publik
- `/` — Landing Page (10 Bagian Utama)
- `/solutions` — Solusi EcoSME (IKM, Bank Mitra, ESaaS)
- `/how-it-works` — Alur Kerja Platform & Standar Rekayasa Listrik
- `/pricing` — Paket Langganan B2B SaaS & Kalkulator ESaaS
- `/about` — Tentang EcoSME & Tata Kelola Data
- `/login` — Login & Pengalih Peran Demo Satu Klik
- `/register` — Registrasi Organisasi IKM

### B. Dashboard IKM (`/app/*`)
- `/app/overview` — Ringkasan Eksekutif (Filter Waktu: Hari Ini, 7 Hari, 30 Hari, Kustom)
- `/app/energy` — Pemantauan Energi (Tegangan V, Arus A, Faktor Daya PF, Daya Aktif kW, kWh, & Simulator Ingesti IoT)
- `/app/machines` — Manajemen Mesin (Tambah, Edit, Detail, Aktifkan/Nonaktifkan Mesin)
- `/app/alerts` — Deteksi Anomali & Pengaturan Ambang Batas (*Configurable Thresholds*)
- `/app/savings` — Analisis Penghematan Energi Ternormalisasi & Rincian Bagi Hasil ESaaS
- `/app/sustainability` — Dashboard Keberlanjutan & Estimasi Emisi Karbon Scope 2 (Faktor Emisi Grid Jamali ESDM)
- `/app/green-score` — Kartu Skor Hijau (*Provisional Green Score Card* 5 Dimensi)
- `/app/financing` — *Green Finance Gateway* & Manajemen Persetujuan Data (*Grant / Revoke Consent*)
- `/app/reports` — Pusat Unduhan 5 Laporan PDF Standar
- `/app/devices` — Manajemen Perangkat IoT, Provisioning Kredensial SHA-256, & Pemantau *Heartbeat*
- `/app/settings` — Pengaturan Tarif Listrik PLN & Periode Baseline

### C. Portal Bank Mitra (`/bank/*`)
- `/bank/overview` — Ringkasan Portofolio Hijau & Distribusi Green Score
- `/bank/pipeline` — Daftar Pipeline IKM yang Memberikan Consent Aktif
- `/bank/pipeline/[id]` — Halaman Evaluasi & Keputusan Underwriting IKM
- `/bank/reports` — Repositori Laporan PDF IKM Berizin
- `/bank/applications` — Antrean Aplikasi Pembiayaan Hijau

### D. Portal Administrator EcoSME (`/admin/*`)
- `/admin/overview` — Ringkasan Tata Kelola Platform
- `/admin/users` — Manajemen Pengguna & Organisasi
- `/admin/devices` — Pemantauan Armada Perangkat IoT Lintas Organisasi
- `/admin/data-quality` — Audit Kualitas Data & Kelengkapan Sensor
- `/admin/green-score` — Konfigurasi Metodologi & Bobot Green Score
- `/admin/audit-logs` — Catatan Audit Sistem (*Audit Logs*)

---

## 3. Cara Menjalankan Proyek Secara Lokal

```bash
# 1. Instal dependensi
npm install

# 2. Jalankan pengujian unit & integrasi RBAC/Consent (Vitest)
npx vitest run

# 3. Jalankan server pengembangan (http://localhost:3000)
npm run dev

# 4. (Opsional) Build untuk produksi
npm run build
npm run start
```
